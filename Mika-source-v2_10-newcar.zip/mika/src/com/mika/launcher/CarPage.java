package com.mika.launcher;

import android.content.Context;
import android.graphics.Outline;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/** Home-screen "Car" slide: the 3D car reacting to GPS speed, with a speed read-out on top. */
final class CarPage extends FrameLayout {
    private final Car3DView gl;
    private final TextView tvSpeed, tvUnit, tvState;
    private final int accent;
    private boolean moving = false;
    private boolean active = false;
    private boolean resumed = false;

    CarPage(Context c, Pal pal) {
        super(c);
        accent = pal.accent;
        gl = new Car3DView(c, pal.accent);
        addView(gl, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout sp = new LinearLayout(c);
        sp.setOrientation(LinearLayout.VERTICAL);
        tvSpeed = Ui.text(c, "0", 46, 0xFFFFFFFF);
        tvSpeed.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        tvSpeed.setIncludeFontPadding(false);
        tvUnit = Ui.text(c, "km/h", 14, 0xB3FFFFFF);
        sp.addView(tvSpeed);
        sp.addView(tvUnit);
        FrameLayout.LayoutParams spl = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.LEFT);
        spl.leftMargin = Ui.dp(c, 18);
        spl.topMargin = Ui.dp(c, 14);
        addView(sp, spl);

        tvState = Ui.text(c, "Parked", 13, 0xFFFFFFFF);
        tvState.setGravity(Gravity.CENTER);
        tvState.setPadding(Ui.dp(c, 14), Ui.dp(c, 7), Ui.dp(c, 14), Ui.dp(c, 7));
        FrameLayout.LayoutParams stl = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.RIGHT);
        stl.rightMargin = Ui.dp(c, 16);
        stl.topMargin = Ui.dp(c, 16);
        addView(tvState, stl);

        TextView name = Ui.text(c, gl.hasModel() ? "BAIC U5 Plus" : "3D model not found", 13, 0x99FFFFFF);
        FrameLayout.LayoutParams nl = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.LEFT);
        nl.leftMargin = Ui.dp(c, 18);
        nl.bottomMargin = Ui.dp(c, 16);
        addView(name, nl);

        paintState();
        final int rad = Ui.dp(c, 22);
        setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), rad);
            }
        });
        setClipToOutline(true);
    }

    private void paintState() {
        tvState.setText(moving ? "Driving" : "Parked");
        tvState.setBackground(Ui.pill(getContext(), moving ? accent : 0x33FFFFFF, 18));
    }

    /** speedMs: GPS speed in m/s (0 when there is no fix). */
    void setSpeed(float speedMs, boolean mph) {
        gl.setSpeed(speedMs);
        float shown = speedMs * (mph ? 2.23694f : 3.6f);
        boolean mv = speedMs >= 0.8f;
        tvSpeed.setText(String.valueOf(mv ? Math.round(shown) : 0));
        tvUnit.setText(mph ? "mph" : "km/h");
        if (mv != moving) {
            moving = mv;
            paintState();
        }
    }

    /** True while the Car page is the visible slide: only then does the GL view render continuously. */
    void setActive(boolean on) {
        active = on;
        gl.setActive(on && resumed);
    }

    void onHostResume() {
        resumed = true;
        gl.onResume();
        gl.setActive(active);
    }

    void onHostPause() {
        resumed = false;
        gl.setActive(false);
        gl.onPause();
    }
}
