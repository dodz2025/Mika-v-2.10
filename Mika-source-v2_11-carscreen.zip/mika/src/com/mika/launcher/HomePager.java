package com.mika.launcher;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.animation.DecelerateInterpolator;
import android.widget.FrameLayout;

import java.util.ArrayList;
import java.util.List;

/** Tiny horizontal pager for the home screen (no support library): swipe between pages, with dots. */
final class HomePager extends FrameLayout {
    interface Listener {
        void onPage(int index);
    }

    /** Lets a page keep its own horizontal drags (e.g. the map). */
    interface SwipeGuard {
        boolean blocksSwipe(float rawX, float rawY);
    }

    private final List<View> pages = new ArrayList<View>();
    private final Paint dot = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int slop;
    private final int minFling;
    private Listener listener;
    private SwipeGuard guard;
    private float pos = 0f;
    private int cur = 0;
    private ValueAnimator anim;
    private float downX, downY, basePos;
    private boolean blocked, dragging;
    private VelocityTracker vt;
    private int dotOn = 0xFFFFFFFF;

    HomePager(Context c) {
        super(c);
        ViewConfiguration vc = ViewConfiguration.get(c);
        slop = vc.getScaledTouchSlop();
        minFling = vc.getScaledMinimumFlingVelocity() * 4;
        setWillNotDraw(false);
    }

    void setListener(Listener l) {
        listener = l;
    }

    void setGuard(SwipeGuard g) {
        guard = g;
    }

    void setDotColor(int c) {
        dotOn = c;
    }

    void addPage(View v) {
        pages.add(v);
        addView(v, new FrameLayout.LayoutParams(-1, -1));
        apply();
    }

    int getPage() {
        return cur;
    }

    void setPage(int idx, boolean animate) {
        idx = Math.max(0, Math.min(pages.size() - 1, idx));
        boolean changed = idx != cur;
        cur = idx;
        if (anim != null) anim.cancel();
        if (!animate) {
            pos = idx;
            apply();
        } else {
            animateTo(idx);
        }
        if (changed && listener != null) listener.onPage(idx);
    }

    private void animateTo(final int idx) {
        anim = ValueAnimator.ofFloat(pos, idx);
        anim.setDuration(240);
        anim.setInterpolator(new DecelerateInterpolator(1.6f));
        anim.addUpdateListener(new ValueAnimator.AnimatorUpdateListener() {
            @Override
            public void onAnimationUpdate(ValueAnimator a) {
                pos = (Float) a.getAnimatedValue();
                apply();
            }
        });
        anim.addListener(new AnimatorListenerAdapter() {
            @Override
            public void onAnimationEnd(Animator a) {
                pos = idx;
                apply();
            }
        });
        anim.start();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        apply();
    }

    private void apply() {
        int w = getWidth();
        // SurfaceView (the 3D car) only follows translations on API 24+; older devices just switch pages.
        boolean slide = android.os.Build.VERSION.SDK_INT >= 24;
        for (int i = 0; i < pages.size(); i++) {
            View v = pages.get(i);
            float d = i - pos;
            if (slide) {
                v.setTranslationX(d * w);
                v.setVisibility(View.VISIBLE);
            } else {
                v.setTranslationX(0);
                v.setVisibility(i == Math.round(pos) ? View.VISIBLE : View.GONE);
            }
        }
        invalidate();
    }

    @Override
    public boolean onInterceptTouchEvent(MotionEvent e) {
        switch (e.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                downX = e.getX();
                downY = e.getY();
                dragging = false;
                int edge = Ui.dp(getContext(), 28);
                boolean onEdge = e.getRawX() < edge || e.getRawX() > getResources().getDisplayMetrics().widthPixels - edge;
                blocked = !onEdge && guard != null && guard.blocksSwipe(e.getRawX(), e.getRawY());
                break;
            case MotionEvent.ACTION_MOVE:
                if (blocked || pages.size() < 2) break;
                float dx = e.getX() - downX, dy = e.getY() - downY;
                if (Math.abs(dx) > slop && Math.abs(dx) > Math.abs(dy) * 1.3f) {
                    boolean ok = (dx < 0 && cur < pages.size() - 1) || (dx > 0 && cur > 0);
                    if (ok) {
                        startDrag(e);
                        return true;
                    }
                }
                break;
            default:
                break;
        }
        return false;
    }

    private void startDrag(MotionEvent e) {
        dragging = true;
        if (anim != null) anim.cancel();
        basePos = pos;
        downX = e.getX();
        vt = VelocityTracker.obtain();
        vt.addMovement(e);
        if (getParent() != null) getParent().requestDisallowInterceptTouchEvent(true);
    }

    @Override
    public boolean onTouchEvent(MotionEvent e) {
        int act = e.getActionMasked();
        if (act == MotionEvent.ACTION_DOWN) {
            // nobody below claimed the touch: stay the target so we can still start a drag
            return pages.size() > 1 && !blocked;
        }
        if (!dragging) {
            if (act == MotionEvent.ACTION_MOVE && !blocked && pages.size() > 1) {
                float dx = e.getX() - downX, dy = e.getY() - downY;
                boolean ok = (dx < 0 && cur < pages.size() - 1) || (dx > 0 && cur > 0);
                if (ok && Math.abs(dx) > slop && Math.abs(dx) > Math.abs(dy) * 1.3f) startDrag(e);
            }
            if (!dragging) return true;
        }
        if (vt != null) vt.addMovement(e);
        switch (act) {
            case MotionEvent.ACTION_MOVE: {
                float w = Math.max(1, getWidth());
                float p = basePos - (e.getX() - downX) / w;
                pos = Math.max(0f, Math.min(pages.size() - 1, p));
                apply();
                return true;
            }
            case MotionEvent.ACTION_UP:
            case MotionEvent.ACTION_CANCEL: {
                float vx = 0;
                if (vt != null) {
                    vt.computeCurrentVelocity(1000);
                    vx = vt.getXVelocity();
                    vt.recycle();
                    vt = null;
                }
                dragging = false;
                int target = Math.round(pos);
                if (act == MotionEvent.ACTION_UP && Math.abs(vx) > minFling * 2) {
                    target = vx < 0 ? (int) Math.ceil(basePos + 0.01f) : (int) Math.floor(basePos - 0.01f);
                }
                setPage(target, true);
                return true;
            }
            default:
                return true;
        }
    }

    @Override
    protected void dispatchDraw(Canvas c) {
        super.dispatchDraw(c);
        int n = pages.size();
        if (n < 2) return;
        float r = Ui.dp(getContext(), 3);
        float gap = Ui.dp(getContext(), 11);
        float cx = getWidth() / 2f - gap * (n - 1) / 2f;
        float cy = getHeight() - Ui.dp(getContext(), 4);
        for (int i = 0; i < n; i++) {
            float t = Math.max(0f, 1f - Math.abs(i - pos));
            dot.setColor(dotOn);
            dot.setAlpha((int) (70 + 185 * t));
            c.drawCircle(cx + gap * i, cy, r * (0.8f + 0.5f * t), dot);
        }
    }
}
