package com.mika.launcher;

import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/** Small helpers around SharedPreferences + the wallpaper file. */
final class Prefs {
    private Prefs() {
    }

    static SharedPreferences p(Context c) {
        return c.getSharedPreferences("mika", Context.MODE_PRIVATE);
    }

    static SharedPreferences counts(Context c) {
        return c.getSharedPreferences("mika_counts", Context.MODE_PRIVATE);
    }

    static SharedPreferences cache(Context c) {
        return c.getSharedPreferences("mika_cache", Context.MODE_PRIVATE);
    }

    static int i(Context c, String k, int d) {
        return p(c).getInt(k, d);
    }

    static boolean b(Context c, String k, boolean d) {
        return p(c).getBoolean(k, d);
    }

    static String s(Context c, String k, String d) {
        return p(c).getString(k, d);
    }

    static void putI(Context c, String k, int v) {
        p(c).edit().putInt(k, v).apply();
    }

    static void putB(Context c, String k, boolean v) {
        p(c).edit().putBoolean(k, v).apply();
    }

    static void putS(Context c, String k, String v) {
        p(c).edit().putString(k, v).apply();
    }

    static List<String> list(Context c, String k) {
        List<String> out = new ArrayList<String>();
        String raw = p(c).getString(k, "");
        if (raw.length() > 0) {
            for (String s : raw.split(",")) if (s.length() > 0) out.add(s);
        }
        return out;
    }

    static void saveList(Context c, String k, List<String> l) {
        StringBuilder sb = new StringBuilder();
        for (String s : l) {
            if (sb.length() > 0) sb.append(',');
            sb.append(s);
        }
        p(c).edit().putString(k, sb.toString()).apply();
    }

    static File wallpaperFile(Context c) {
        return new File(c.getFilesDir(), "wallpaper.jpg");
    }

    static Bitmap loadWallpaper(Context c) {
        File f = wallpaperFile(c);
        if (!f.exists()) return null;
        try {
            return BitmapFactory.decodeFile(f.getAbsolutePath());
        } catch (Throwable t) {
            return null;
        }
    }
}
