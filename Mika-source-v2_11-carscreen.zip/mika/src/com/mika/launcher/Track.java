package com.mika.launcher;

import android.content.ContentResolver;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.OpenableColumns;

/** A media item (song, video or photo). */
final class Track {
    long id;
    String title = "";
    String artist = "";
    String album = "";
    long albumId;
    long duration;
    Uri uri;

    /** Builds a Track for a single file opened from another app ("Open with Mika"). */
    static Track fromUri(Context c, Uri u) {
        Track t = new Track();
        t.uri = u;
        t.id = u.toString().hashCode();
        String name = null;
        try {
            if (ContentResolver.SCHEME_CONTENT.equals(u.getScheme())) {
                Cursor cur = c.getContentResolver().query(u, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
                if (cur != null) {
                    try {
                        if (cur.moveToFirst()) name = cur.getString(0);
                    } finally {
                        cur.close();
                    }
                }
            }
        } catch (Exception ignored) {
        }
        if (name == null) name = u.getLastPathSegment();
        if (name == null) name = "Media";
        int dot = name.lastIndexOf('.');
        t.title = dot > 0 ? name.substring(0, dot) : name;
        t.artist = "";
        return t;
    }

    static String fmt(long ms) {
        long s = Math.max(0, ms) / 1000;
        long h = s / 3600;
        long m = (s % 3600) / 60;
        long sec = s % 60;
        if (h > 0) return String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, sec);
        return String.format(java.util.Locale.US, "%d:%02d", m, sec);
    }
}
