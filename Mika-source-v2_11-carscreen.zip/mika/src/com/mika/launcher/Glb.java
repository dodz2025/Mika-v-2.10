package com.mika.launcher;

import org.json.JSONArray;
import org.json.JSONObject;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.List;

/**
 * Minimal binary-glTF (.glb) reader for the car model: positions + vertex colours, no textures.
 * Output is flat-shaded, un-indexed triangles (pos3, normal3, colour3 + emissive flag), split into
 * a body group and four wheel groups (so the wheels can spin). Model space: X forward, Y left, Z up.
 */
final class Glb {
    static final int STRIDE = 10;

    static final class Group {
        float[] v = new float[0];
        int count;            // number of vertices
        float px, py, pz;     // pivot (wheel centre)
    }

    Group body = new Group();
    Group[] wheels = new Group[4];
    float wheelRadius = 0.35f;
    float minX, maxX, minY, maxY, minZ, maxZ;

    private static final class Mesh {
        String name;
        float[] pos, col;
        int[] idx;
    }

    static Glb parse(byte[] data) throws Exception {
        ByteBuffer bb = ByteBuffer.wrap(data).order(ByteOrder.LITTLE_ENDIAN);
        if (bb.getInt(0) != 0x46546C67) throw new Exception("not a glb");
        int off = 12;
        JSONObject json = null;
        int binOff = -1;
        while (off + 8 <= data.length) {
            int len = bb.getInt(off);
            int type = bb.getInt(off + 4);
            if (type == 0x4E4F534A) json = new JSONObject(new String(data, off + 8, len, "UTF-8"));
            else if (type == 0x004E4942 && binOff < 0) binOff = off + 8;
            off += 8 + ((len + 3) & ~3);
        }
        if (json == null || binOff < 0) throw new Exception("bad glb");

        JSONArray accessors = json.getJSONArray("accessors");
        JSONArray views = json.getJSONArray("bufferViews");
        JSONArray nodes = json.getJSONArray("nodes");
        JSONArray meshes = json.getJSONArray("meshes");

        List<Mesh> list = new ArrayList<Mesh>();
        for (int i = 0; i < nodes.length(); i++) {
            JSONObject n = nodes.getJSONObject(i);
            if (!n.has("mesh")) continue;
            JSONObject m = meshes.getJSONObject(n.getInt("mesh"));
            JSONObject prim = m.getJSONArray("primitives").getJSONObject(0);
            if (prim.optInt("mode", 4) != 4) continue;
            JSONObject at = prim.getJSONObject("attributes");
            Mesh me = new Mesh();
            me.name = n.optString("name", "");
            me.pos = readFloats(bb, binOff, accessors, views, at.getInt("POSITION"), 3);
            me.col = at.has("COLOR_0") ? readFloats(bb, binOff, accessors, views, at.getInt("COLOR_0"), 4) : null;
            me.idx = prim.has("indices") ? readIndices(bb, binOff, accessors, views, prim.getInt("indices")) : null;
            list.add(me);
        }

        Glb g = new Glb();
        g.minX = g.minY = g.minZ = 1e9f;
        g.maxX = g.maxY = g.maxZ = -1e9f;
        List<float[]> bodyParts = new ArrayList<float[]>();
        List<List<float[]>> wheelParts = new ArrayList<List<float[]>>();
        float[][] wb = new float[4][]; // bbox of the largest mesh of each wheel (the tyre)
        for (int i = 0; i < 4; i++) wheelParts.add(new ArrayList<float[]>());

        for (Mesh me : list) {
            float[] bb6 = bbox(me.pos);
            String low = me.name.toLowerCase();
            boolean wheel = low.startsWith("part") || low.startsWith("wheel");
            float emis = low.contains("headlamp") ? 1f : (low.contains("tail lamp") || low.contains("rear light")) ? 2f : 0f;
            float[] tri = triangles(me, emis);
            if (!wheel) {
                bodyParts.add(tri);
                g.minX = Math.min(g.minX, bb6[0]);
                g.minY = Math.min(g.minY, bb6[1]);
                g.minZ = Math.min(g.minZ, bb6[2]);
                g.maxX = Math.max(g.maxX, bb6[3]);
                g.maxY = Math.max(g.maxY, bb6[4]);
                g.maxZ = Math.max(g.maxZ, bb6[5]);
            } else {
                float cx = (bb6[0] + bb6[3]) / 2, cy = (bb6[1] + bb6[4]) / 2;
                int w = (cx > 0 ? 2 : 0) + (cy > 0 ? 1 : 0);
                wheelParts.get(w).add(tri);
                float size = bb6[3] - bb6[0];
                if (wb[w] == null || size > wb[w][3] - wb[w][0]) wb[w] = bb6;
            }
        }
        g.body = pack(bodyParts);
        for (int w = 0; w < 4; w++) {
            g.wheels[w] = pack(wheelParts.get(w));
            if (wb[w] != null) {
                g.wheels[w].px = (wb[w][0] + wb[w][3]) / 2;
                g.wheels[w].py = (wb[w][1] + wb[w][4]) / 2;
                g.wheels[w].pz = (wb[w][2] + wb[w][5]) / 2;
                g.wheelRadius = (wb[w][3] - wb[w][0]) / 2;
                g.minZ = Math.min(g.minZ, wb[w][2]);
            }
        }
        return g;
    }

    private static Group pack(List<float[]> parts) {
        int n = 0;
        for (float[] p : parts) n += p.length;
        Group gr = new Group();
        gr.v = new float[n];
        int o = 0;
        for (float[] p : parts) {
            System.arraycopy(p, 0, gr.v, o, p.length);
            o += p.length;
        }
        gr.count = n / STRIDE;
        return gr;
    }

    private static float[] bbox(float[] p) {
        float[] b = {1e9f, 1e9f, 1e9f, -1e9f, -1e9f, -1e9f};
        for (int i = 0; i < p.length; i += 3) {
            for (int k = 0; k < 3; k++) {
                b[k] = Math.min(b[k], p[i + k]);
                b[k + 3] = Math.max(b[k + 3], p[i + k]);
            }
        }
        return b;
    }

    private static float[] triangles(Mesh m, float emis) {
        int nIdx = m.idx != null ? m.idx.length : m.pos.length / 3;
        int tris = nIdx / 3;
        float[] out = new float[tris * 3 * STRIDE];
        int o = 0;
        for (int t = 0; t < tris; t++) {
            int[] id = new int[3];
            for (int k = 0; k < 3; k++) id[k] = m.idx != null ? m.idx[t * 3 + k] : t * 3 + k;
            float ax = m.pos[id[0] * 3], ay = m.pos[id[0] * 3 + 1], az = m.pos[id[0] * 3 + 2];
            float bx = m.pos[id[1] * 3], by = m.pos[id[1] * 3 + 1], bz = m.pos[id[1] * 3 + 2];
            float cx = m.pos[id[2] * 3], cy = m.pos[id[2] * 3 + 1], cz = m.pos[id[2] * 3 + 2];
            float ux = bx - ax, uy = by - ay, uz = bz - az, vx = cx - ax, vy = cy - ay, vz = cz - az;
            float nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx;
            float l = (float) Math.sqrt(nx * nx + ny * ny + nz * nz);
            if (l < 1e-9f) continue;
            nx /= l;
            ny /= l;
            nz /= l;
            for (int k = 0; k < 3; k++) {
                int vi = id[k];
                out[o++] = m.pos[vi * 3];
                out[o++] = m.pos[vi * 3 + 1];
                out[o++] = m.pos[vi * 3 + 2];
                out[o++] = nx;
                out[o++] = ny;
                out[o++] = nz;
                if (m.col != null) {
                    out[o++] = m.col[vi * 4];
                    out[o++] = m.col[vi * 4 + 1];
                    out[o++] = m.col[vi * 4 + 2];
                } else {
                    out[o++] = 0.7f;
                    out[o++] = 0.7f;
                    out[o++] = 0.7f;
                }
                out[o++] = emis;
            }
        }
        if (o == out.length) return out;
        float[] r = new float[o];
        System.arraycopy(out, 0, r, 0, o);
        return r;
    }

    // ------------------------------------------------------------- accessors
    private static float[] readFloats(ByteBuffer bb, int binOff, JSONArray acc, JSONArray views, int ai, int want) throws Exception {
        JSONObject a = acc.getJSONObject(ai);
        JSONObject v = views.getJSONObject(a.getInt("bufferView"));
        int comps = a.getString("type").equals("VEC4") ? 4 : a.getString("type").equals("VEC3") ? 3 : 1;
        int ct = a.getInt("componentType");
        int count = a.getInt("count");
        int csize = (ct == 5126 || ct == 5125) ? 4 : (ct == 5123 || ct == 5122) ? 2 : 1;
        int stride = v.optInt("byteStride", comps * csize);
        int base = binOff + v.optInt("byteOffset", 0) + a.optInt("byteOffset", 0);
        boolean norm = a.optBoolean("normalized", false);
        float[] out = new float[count * want];
        for (int i = 0; i < count; i++) {
            for (int k = 0; k < want; k++) {
                float val;
                if (k >= comps) {
                    val = 1f;
                } else {
                    int p = base + i * stride + k * csize;
                    if (ct == 5126) val = bb.getFloat(p);
                    else if (ct == 5121) {
                        int x = bb.get(p) & 0xFF;
                        val = norm ? x / 255f : x;
                    } else if (ct == 5123) {
                        int x = bb.getShort(p) & 0xFFFF;
                        val = norm ? x / 65535f : x;
                    } else throw new Exception("unsupported component type " + ct);
                }
                out[i * want + k] = val;
            }
        }
        return out;
    }

    private static int[] readIndices(ByteBuffer bb, int binOff, JSONArray acc, JSONArray views, int ai) throws Exception {
        JSONObject a = acc.getJSONObject(ai);
        JSONObject v = views.getJSONObject(a.getInt("bufferView"));
        int ct = a.getInt("componentType");
        int count = a.getInt("count");
        int base = binOff + v.optInt("byteOffset", 0) + a.optInt("byteOffset", 0);
        int[] out = new int[count];
        for (int i = 0; i < count; i++) {
            if (ct == 5125) out[i] = bb.getInt(base + i * 4);
            else if (ct == 5123) out[i] = bb.getShort(base + i * 2) & 0xFFFF;
            else out[i] = bb.get(base + i) & 0xFF;
        }
        return out;
    }
}
