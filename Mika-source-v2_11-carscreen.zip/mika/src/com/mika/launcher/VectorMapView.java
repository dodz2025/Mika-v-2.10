package com.mika.launcher;

import android.annotation.SuppressLint;
import android.content.Context;
import android.location.Location;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;

import org.json.JSONArray;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Locale;

/**
 * Mapbox-style vector map (MapLibre GL JS, bundled in assets) with rotation, 3D tilt, 3D buildings,
 * satellite layer and a route line. Pages are served from https://mika.local/ by intercepting requests,
 * so no file:// restrictions apply. Tiles/styles come from OpenFreeMap / CARTO (no API key).
 */
public class VectorMapView extends FrameLayout implements MapSurface {

    interface Events {
        void onFail(String reason);

        void onPoi(String name, double lat, double lon);
    }

    private final WebView wv;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private MapView.Listener listener;
    private Events events;

    private boolean started = false, ready = false, camDirty = false, interactive = true;

    // state mirrored from Java so it can be pushed once the page is ready
    private double cLat = 48.8566, cLon = 2.3522;
    private float zoom = 5f; // raster scale; MapLibre zoom = zoom - 1
    private boolean night = false, sat = false, tilted = false, headingUp = false;
    private int accent = 0xFF2979FF;
    private boolean hasPin = false;
    private double pinLat, pinLon;
    private String savedJson = "[]";
    private Location me;
    private String routeJson = null;

    public VectorMapView(Context c) {
        super(c);
        wv = new WebView(c);
        init();
    }

    @SuppressLint({"SetJavaScriptEnabled", "ClickableViewAccessibility"})
    private void init() {
        setBackgroundColor(0xFF14171D);
        WebSettings s = wv.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        wv.setBackgroundColor(0xFF14171D);
        wv.setOverScrollMode(View.OVER_SCROLL_NEVER);
        wv.setVerticalScrollBarEnabled(false);
        wv.setHorizontalScrollBarEnabled(false);
        wv.setLongClickable(false);
        wv.setHapticFeedbackEnabled(false);
        wv.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                return true;
            }
        });
        wv.addJavascriptInterface(new Bridge(), "MikaMap");
        wv.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) {
                Uri u = r.getUrl();
                if ("https".equals(u.getScheme()) && "mika.local".equals(u.getHost())) {
                    String p = u.getPath();
                    if (p == null || p.length() <= 1) p = "/map.html";
                    try {
                        InputStream in = getContext().getAssets().open(p.substring(1));
                        return new WebResourceResponse(mime(p), "UTF-8", in);
                    } catch (IOException e) {
                        return new WebResourceResponse("text/plain", "UTF-8", 404, "Not found", null,
                                new ByteArrayInputStream(new byte[0]));
                    }
                }
                return null;
            }

            @Override
            public boolean onRenderProcessGone(WebView v, RenderProcessGoneDetail d) {
                fail("crash");
                return true;
            }
        });
        addView(wv, new FrameLayout.LayoutParams(-1, -1));
    }

    private static String mime(String p) {
        if (p.endsWith(".js")) return "application/javascript";
        if (p.endsWith(".css")) return "text/css";
        if (p.endsWith(".html")) return "text/html";
        if (p.endsWith(".json")) return "application/json";
        return "application/octet-stream";
    }

    // --------------------------------------------------------------- lifecycle
    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (started) return;
        started = true;
        String token = Prefs.s(getContext(), "mapboxToken", "").trim();
        String url = String.format(Locale.US,
                "https://mika.local/map.html?night=%d&sat=%d&lat=%f&lon=%f&z=%f&pitch=%d&accent=%06X",
                night ? 1 : 0, sat ? 1 : 0, cLat, cLon, zoom - 1f, tilted ? 60 : 0, accent & 0xFFFFFF);
        if (token.length() > 0) url += "&mb=" + Uri.encode(token);
        wv.loadUrl(url);
    }

    /** Non-interactive maps (home screen card) swallow touches so taps reach the view's own click listener. */
    public void setInteractive(boolean b) {
        interactive = b;
    }

    @Override
    public boolean onInterceptTouchEvent(android.view.MotionEvent ev) {
        return !interactive || super.onInterceptTouchEvent(ev);
    }

    void setEvents(Events e) {
        events = e;
    }

    void onHostPause() {
        wv.onPause();
    }

    void onHostResume() {
        wv.onResume();
    }

    void destroy() {
        try {
            removeView(wv);
            wv.removeJavascriptInterface("MikaMap");
            wv.destroy();
        } catch (Throwable ignored) {
        }
    }

    private void fail(final String reason) {
        ui.post(new Runnable() {
            @Override
            public void run() {
                if (events != null) events.onFail(reason);
            }
        });
    }

    // -------------------------------------------------------------- js bridge
    private void js(String code) {
        if (!ready) return;
        wv.evaluateJavascript(code, null);
    }

    private void pushAll() {
        js("setSaved(" + savedJson + ")");
        if (hasPin) js(String.format(Locale.US, "setPin(%f,%f)", pinLat, pinLon));
        if (me != null) pushMe();
        if (routeJson != null) js("setRoute(" + routeJson + ")");
        if (camDirty) {
            js(String.format(Locale.US, "jumpTo(%f,%f,%f)", cLat, cLon, zoom - 1f));
            camDirty = false;
        }
        js("setHeadingUp(" + headingUp + ")");
    }

    private void pushMe() {
        boolean moving = me.hasBearing() && me.hasSpeed() && me.getSpeed() > 1f;
        js(String.format(Locale.US, "setMe(%f,%f,%f,%f,%b)", me.getLatitude(), me.getLongitude(),
                me.hasBearing() ? me.getBearing() : 0f, me.hasAccuracy() ? me.getAccuracy() : 0f, moving));
    }

    private class Bridge {
        @JavascriptInterface
        public void onReady() {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    ready = true;
                    pushAll();
                }
            });
        }

        @JavascriptInterface
        public void onMove(double lat, double lon, double z) {
            cLat = lat;
            cLon = lon;
            zoom = (float) z + 1f;
        }

        @JavascriptInterface
        public void onTap() {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    if (listener != null) listener.onTap();
                }
            });
        }

        @JavascriptInterface
        public void onLongPress(final double lat, final double lon) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    if (listener != null) listener.onLongPress(lat, lon);
                }
            });
        }

        @JavascriptInterface
        public void onUserMoved() {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    if (listener != null) listener.onUserMoved();
                }
            });
        }

        @JavascriptInterface
        public void onPoi(final String name, final double lat, final double lon) {
            ui.post(new Runnable() {
                @Override
                public void run() {
                    if (events != null) events.onPoi(name, lat, lon);
                }
            });
        }

        @JavascriptInterface
        public void onFail(String reason) {
            fail(reason);
        }
    }

    // ------------------------------------------------------------- MapSurface
    @Override
    public void setListener(MapView.Listener l) {
        listener = l;
    }

    @Override
    public void setNight(boolean b) {
        if (night == b) return;
        night = b;
        js("setNight(" + b + ")");
    }

    @Override
    public void setAccent(int c) {
        accent = c;
        js(String.format(Locale.US, "setAccent('#%06X')", c & 0xFFFFFF));
    }

    @Override
    public void setMe(Location l) {
        me = l;
        if (l != null) pushMe();
    }

    @Override
    public void setPin(double lat, double lon) {
        hasPin = true;
        pinLat = lat;
        pinLon = lon;
        js(String.format(Locale.US, "setPin(%f,%f)", lat, lon));
    }

    @Override
    public void clearPin() {
        hasPin = false;
        js("clearPin()");
    }

    @Override
    public boolean hasPin() {
        return hasPin;
    }

    @Override
    public void setSaved(List<double[]> s) {
        JSONArray a = new JSONArray();
        if (s != null) {
            for (double[] p : s) {
                JSONArray o = new JSONArray();
                try {
                    o.put(p[0]);
                    o.put(p[1]);
                } catch (Exception ignored) {
                }
                a.put(o);
            }
        }
        savedJson = a.toString();
        js("setSaved(" + savedJson + ")");
    }

    @Override
    public void setCenter(double lat, double lon) {
        cLat = lat;
        cLon = lon;
        if (started && !ready) camDirty = true;
        js(String.format(Locale.US, "jumpTo(%f,%f,null)", lat, lon));
    }

    @Override
    public void setZoom(float z) {
        zoom = Math.max(2f, Math.min(20f, z));
        if (started && !ready) camDirty = true;
        js(String.format(Locale.US, "jumpTo(null,null,%f)", zoom - 1f));
    }

    @Override
    public float getZoom() {
        return zoom;
    }

    @Override
    public void zoomBy(float dz) {
        zoom = Math.max(2f, Math.min(20f, zoom + dz));
        js(String.format(Locale.US, "zoomBy(%f)", dz));
    }

    @Override
    public double centerLat() {
        return cLat;
    }

    @Override
    public double centerLon() {
        return cLon;
    }

    @Override
    public void flyTo(double lat, double lon, float z) {
        cLat = lat;
        cLon = lon;
        zoom = z;
        if (started && !ready) camDirty = true;
        js(String.format(Locale.US, "flyToPlace(%f,%f,%f)", lat, lon, z - 1f));
    }

    @Override
    public boolean isVector() {
        return true;
    }

    @Override
    public void followTo(double lat, double lon, float bearing, boolean moving) {
        cLat = lat;
        cLon = lon;
        js(String.format(Locale.US, "followTo(%f,%f,%f,%b)", lat, lon, bearing, moving));
    }

    @Override
    public void setTilt(boolean on) {
        tilted = on;
        js("setTilt(" + on + ")");
    }

    @Override
    public boolean isTilted() {
        return tilted;
    }

    @Override
    public void setHeadingUp(boolean on) {
        headingUp = on;
        js("setHeadingUp(" + on + ")");
    }

    @Override
    public void resetNorth() {
        js("resetNorth()");
    }

    @Override
    public void setSatellite(boolean on) {
        if (sat == on) return;
        sat = on;
        js("setSat(" + on + ")");
    }

    @Override
    public boolean isSatellite() {
        return sat;
    }

    @Override
    public void setRoute(List<double[]> latLon) {
        if (latLon == null || latLon.size() < 2) {
            clearRoute();
            return;
        }
        // GeoJSON order is [lon, lat]
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < latLon.size(); i++) {
            double[] p = latLon.get(i);
            if (i > 0) sb.append(',');
            sb.append(String.format(Locale.US, "[%.6f,%.6f]", p[1], p[0]));
        }
        sb.append(']');
        routeJson = sb.toString();
        js("setRoute(" + routeJson + ")");
    }

    @Override
    public void clearRoute() {
        routeJson = null;
        js("clearRoute()");
    }

    @Override
    public void fitRoute() {
        js("fitRoute()");
    }
}
