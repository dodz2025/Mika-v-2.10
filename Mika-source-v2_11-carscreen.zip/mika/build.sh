#!/bin/bash
# Rebuilds Mika-Launcher.apk. Needs: aapt, javac, dalvik-exchange, zipalign, apksigner, android.jar (API 23+)
set -e
AJ=${ANDROID_JAR:-/home/claude/android33.jar}
rm -rf build && mkdir -p build/gen build/classes
aapt package -f -m -J build/gen -M AndroidManifest.xml -S res -A assets -I "$AJ" -F build/res.apk
javac --release 8 -Xlint:-options -cp "$AJ" -d build/classes $(find src build/gen -name '*.java')
dalvik-exchange --dex --output=build/classes.dex build/classes
cp build/res.apk build/raw.apk
( cd build && aapt add raw.apk classes.dex >/dev/null )
zipalign -f -p 4 build/raw.apk build/aligned.apk
apksigner sign --ks ~/.android/debug.keystore --ks-pass pass:android --key-pass pass:android --ks-key-alias androiddebugkey --out build/Mika-Launcher.apk build/aligned.apk
echo "Built build/Mika-Launcher.apk"
