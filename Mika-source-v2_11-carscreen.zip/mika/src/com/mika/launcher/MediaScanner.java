package com.mika.launcher;

import android.Manifest;
import android.content.ContentUris;
import android.content.Context;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;

import java.util.ArrayList;
import java.util.List;

/** Reads audio, video and images from the device's MediaStore. */
final class MediaScanner {
    private MediaScanner() {
    }

    static String[] permissions() {
        if (Build.VERSION.SDK_INT >= 33) {
            return new String[]{"android.permission.READ_MEDIA_AUDIO", "android.permission.READ_MEDIA_VIDEO",
                    "android.permission.READ_MEDIA_IMAGES"};
        }
        return new String[]{Manifest.permission.READ_EXTERNAL_STORAGE};
    }

    static boolean hasPermission(Context c) {
        if (Build.VERSION.SDK_INT < 23) return true;
        for (String p : permissions()) {
            if (c.checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED) return true; // any is enough to show something
        }
        return false;
    }

    static List<Track> audio(Context c) {
        List<Track> out = new ArrayList<Track>();
        Cursor cur = null;
        try {
            cur = c.getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    new String[]{MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
                            MediaStore.Audio.Media.ARTIST, MediaStore.Audio.Media.ALBUM,
                            MediaStore.Audio.Media.ALBUM_ID, MediaStore.Audio.Media.DURATION},
                    MediaStore.Audio.Media.IS_MUSIC + " != 0", null,
                    MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC");
            while (cur != null && cur.moveToNext()) {
                Track t = new Track();
                t.id = cur.getLong(0);
                t.title = nz(cur.getString(1), "Unknown title");
                t.artist = clean(cur.getString(2), "Unknown artist");
                t.album = clean(cur.getString(3), "Unknown album");
                t.albumId = cur.getLong(4);
                t.duration = cur.getLong(5);
                t.uri = ContentUris.withAppendedId(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI, t.id);
                out.add(t);
            }
        } catch (Exception ignored) {
        } finally {
            if (cur != null) cur.close();
        }
        return out;
    }

    static List<Track> videos(Context c) {
        List<Track> out = new ArrayList<Track>();
        Cursor cur = null;
        try {
            cur = c.getContentResolver().query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                    new String[]{MediaStore.Video.Media._ID, MediaStore.Video.Media.DISPLAY_NAME,
                            MediaStore.Video.Media.DURATION},
                    null, null, MediaStore.Video.Media.DATE_ADDED + " DESC");
            while (cur != null && cur.moveToNext()) {
                Track t = new Track();
                t.id = cur.getLong(0);
                String n = nz(cur.getString(1), "Video");
                int dot = n.lastIndexOf('.');
                t.title = dot > 0 ? n.substring(0, dot) : n;
                t.duration = cur.getLong(2);
                t.uri = ContentUris.withAppendedId(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, t.id);
                out.add(t);
            }
        } catch (Exception ignored) {
        } finally {
            if (cur != null) cur.close();
        }
        return out;
    }

    static List<Track> images(Context c) {
        List<Track> out = new ArrayList<Track>();
        Cursor cur = null;
        try {
            cur = c.getContentResolver().query(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                    new String[]{MediaStore.Images.Media._ID, MediaStore.Images.Media.DISPLAY_NAME},
                    null, null, MediaStore.Images.Media.DATE_ADDED + " DESC");
            while (cur != null && cur.moveToNext()) {
                Track t = new Track();
                t.id = cur.getLong(0);
                t.title = nz(cur.getString(1), "Photo");
                t.uri = ContentUris.withAppendedId(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, t.id);
                out.add(t);
            }
        } catch (Exception ignored) {
        } finally {
            if (cur != null) cur.close();
        }
        return out;
    }

    private static String nz(String s, String d) {
        return s == null || s.length() == 0 ? d : s;
    }

    private static String clean(String s, String d) {
        if (s == null || s.length() == 0 || s.equals("<unknown>")) return d;
        return s;
    }
}
