package com.mika.launcher;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/** Weather + city search using the free Open-Meteo API (no API key needed). */
final class WeatherClient {
    private WeatherClient() {
    }

    static class Day {
        String label;
        int code, hi, lo;
    }

    static class Weather {
        int temp, feels, code, wind;
        boolean day;
        List<Day> days = new ArrayList<Day>();
    }

    static class Place {
        String name, region, country;
        double lat, lon;

        String label() {
            StringBuilder sb = new StringBuilder(name);
            if (region != null && region.length() > 0 && !region.equals(name)) sb.append(", ").append(region);
            if (country != null && country.length() > 0) sb.append(", ").append(country);
            return sb.toString();
        }
    }

    static String http(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(8000);
        try {
            InputStream in = c.getInputStream();
            BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            r.close();
            return sb.toString();
        } finally {
            c.disconnect();
        }
    }

    static String forecastUrl(double lat, double lon, boolean fahrenheit) {
        return String.format(Locale.US,
                "https://api.open-meteo.com/v1/forecast?latitude=%.4f&longitude=%.4f"
                        + "&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m,is_day"
                        + "&daily=weather_code,temperature_2m_max,temperature_2m_min"
                        + "&timezone=auto&forecast_days=4&temperature_unit=%s&wind_speed_unit=%s",
                lat, lon, fahrenheit ? "fahrenheit" : "celsius", fahrenheit ? "mph" : "kmh");
    }

    static Weather parse(String json) throws Exception {
        JSONObject root = new JSONObject(json);
        JSONObject cur = root.getJSONObject("current");
        Weather w = new Weather();
        w.temp = (int) Math.round(cur.getDouble("temperature_2m"));
        w.feels = (int) Math.round(cur.getDouble("apparent_temperature"));
        w.code = cur.getInt("weather_code");
        w.wind = (int) Math.round(cur.getDouble("wind_speed_10m"));
        w.day = cur.optInt("is_day", 1) == 1;
        JSONObject d = root.getJSONObject("daily");
        JSONArray time = d.getJSONArray("time");
        JSONArray code = d.getJSONArray("weather_code");
        JSONArray hi = d.getJSONArray("temperature_2m_max");
        JSONArray lo = d.getJSONArray("temperature_2m_min");
        SimpleDateFormat in = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
        SimpleDateFormat out = new SimpleDateFormat("EEE", Locale.getDefault());
        for (int i = 1; i < time.length() && w.days.size() < 3; i++) {
            Day day = new Day();
            Date dt = in.parse(time.getString(i));
            day.label = dt == null ? "" : out.format(dt);
            day.code = code.getInt(i);
            day.hi = (int) Math.round(hi.getDouble(i));
            day.lo = (int) Math.round(lo.getDouble(i));
            w.days.add(day);
        }
        return w;
    }

    static List<Place> search(String q) throws Exception {
        String url = "https://geocoding-api.open-meteo.com/v1/search?count=6&language=en&format=json&name="
                + URLEncoder.encode(q, "UTF-8");
        JSONObject root = new JSONObject(http(url));
        List<Place> out = new ArrayList<Place>();
        JSONArray res = root.optJSONArray("results");
        if (res == null) return out;
        for (int i = 0; i < res.length(); i++) {
            JSONObject o = res.getJSONObject(i);
            Place p = new Place();
            p.name = o.optString("name");
            p.region = o.optString("admin1");
            p.country = o.optString("country");
            p.lat = o.getDouble("latitude");
            p.lon = o.getDouble("longitude");
            out.add(p);
        }
        return out;
    }

    static String describe(int c) {
        if (c == 0) return "Clear sky";
        if (c == 1) return "Mainly clear";
        if (c == 2) return "Partly cloudy";
        if (c == 3) return "Overcast";
        if (c == 45 || c == 48) return "Fog";
        if (c >= 51 && c <= 57) return "Drizzle";
        if (c >= 61 && c <= 67) return "Rain";
        if (c >= 71 && c <= 77) return "Snow";
        if (c >= 80 && c <= 82) return "Rain showers";
        if (c == 85 || c == 86) return "Snow showers";
        if (c >= 95) return "Thunderstorm";
        return "Unknown";
    }

    static String emoji(int c, boolean day) {
        if (c == 0) return day ? "\u2600\uFE0F" : "\uD83C\uDF19";
        if (c == 1) return day ? "\uD83C\uDF24\uFE0F" : "\uD83C\uDF19";
        if (c == 2) return "\u26C5";
        if (c == 3) return "\u2601\uFE0F";
        if (c == 45 || c == 48) return "\uD83C\uDF2B\uFE0F";
        if (c >= 51 && c <= 57) return "\uD83C\uDF26\uFE0F";
        if (c >= 61 && c <= 67) return "\uD83C\uDF27\uFE0F";
        if (c >= 71 && c <= 77) return "\u2744\uFE0F";
        if (c >= 80 && c <= 82) return "\uD83C\uDF27\uFE0F";
        if (c == 85 || c == 86) return "\uD83C\uDF28\uFE0F";
        if (c >= 95) return "\u26C8\uFE0F";
        return "\u2753";
    }
}
