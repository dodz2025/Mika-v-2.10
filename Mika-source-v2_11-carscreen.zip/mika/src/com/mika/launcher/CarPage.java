package com.mika.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Outline;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

/**
 * Home-screen "Car" slide: the 3D car reacting to GPS speed, full screen. The scene's edges melt into the page
 * background (blurred cover of the song that is playing, or a plain dark colour), the speed sits on top and the
 * current song shows big at the bottom.
 */
final class CarPage extends FrameLayout {
    private static final int BASE = 0xFF121721;

    private static final class Bar extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        float frac = 0f;

        Bar(Context c) {
            super(c);
        }

        @Override
        protected void onDraw(Canvas cv) {
            float w = getWidth(), h = getHeight(), rad = h / 2f;
            p.setColor(0x44FFFFFF);
            r.set(0, 0, w, h);
            cv.drawRoundRect(r, rad, rad, p);
            float fw = Math.max(0f, Math.min(1f, frac)) * w;
            if (fw > 0f) {
                p.setColor(0xFFFFFFFF);
                r.set(0, 0, Math.max(fw, h), h);
                cv.drawRoundRect(r, rad, rad, p);
            }
        }
    }

    private final Car3DView gl;
    private final EdgeFade fade;
    private final TextView tvSpeed, tvUnit, tvState, tvTitle, tvArtist;
    private final LinearLayout np;
    private final Bar bar;
    private final int accent;
    private final int radius;
    private boolean moving = false;
    private boolean active = false;
    private boolean resumed = false;
    private boolean full = false;
    private Bitmap artSrc, placeholder;
    private String placeholderFor;
    private Runnable onNow, onHome;

    CarPage(Context c, Pal pal) {
        super(c);
        accent = pal.accent;
        gl = new Car3DView(c, pal.accent);
        addView(gl, new FrameLayout.LayoutParams(-1, -1));

        fade = new EdgeFade(c);
        fade.setSource(null, BASE, 0);
        addView(fade, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout sp = new LinearLayout(c);
        sp.setOrientation(LinearLayout.VERTICAL);
        tvSpeed = Ui.text(c, "0", 46, 0xFFFFFFFF);
        tvSpeed.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        tvSpeed.setIncludeFontPadding(false);
        tvUnit = Ui.text(c, "km/h", 14, 0xB3FFFFFF);
        sp.addView(tvSpeed);
        sp.addView(tvUnit);
        FrameLayout.LayoutParams spl = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.LEFT);
        spl.leftMargin = Ui.dp(c, 24);
        spl.topMargin = Ui.dp(c, 20);
        addView(sp, spl);

        tvState = Ui.text(c, "Parked", 13, 0xFFFFFFFF);
        tvState.setGravity(Gravity.CENTER);
        tvState.setPadding(Ui.dp(c, 14), Ui.dp(c, 7), Ui.dp(c, 14), Ui.dp(c, 7));
        FrameLayout.LayoutParams stl = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.RIGHT);
        stl.rightMargin = Ui.dp(c, 22);
        stl.topMargin = Ui.dp(c, 22);
        addView(tvState, stl);

        if (!gl.hasModel()) {
            TextView miss = Ui.text(c, "3D model not found", 13, 0x99FFFFFF);
            FrameLayout.LayoutParams ml = new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER);
            addView(miss, ml);
        }

        np = new LinearLayout(c);
        np.setOrientation(LinearLayout.VERTICAL);
        tvTitle = Ui.text(c, "", 26, 0xFFFFFFFF);
        tvTitle.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        tvTitle.setSingleLine(true);
        tvTitle.setEllipsize(TextUtils.TruncateAt.END);
        tvArtist = Ui.text(c, "", 15, 0xCCFFFFFF);
        tvArtist.setSingleLine(true);
        tvArtist.setEllipsize(TextUtils.TruncateAt.END);
        bar = new Bar(c);
        np.addView(tvTitle);
        np.addView(tvArtist);
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, Ui.dp(c, 3));
        bl.topMargin = Ui.dp(c, 12);
        np.addView(bar, bl);
        FrameLayout.LayoutParams npl = new FrameLayout.LayoutParams(-1, -2, Gravity.BOTTOM | Gravity.LEFT);
        npl.leftMargin = Ui.dp(c, 24);
        npl.rightMargin = Ui.dp(c, 96);
        npl.bottomMargin = Ui.dp(c, 24);
        np.setVisibility(View.GONE);
        np.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onNow != null) onNow.run();
            }
        });
        addView(np, npl);

        View home = Ui.iconButton(c, Icons.HOME, 48, 26, 0x33FFFFFF, 0xFFFFFFFF);
        FrameLayout.LayoutParams hl = new FrameLayout.LayoutParams(Ui.dp(c, 48), Ui.dp(c, 48), Gravity.BOTTOM | Gravity.RIGHT);
        hl.rightMargin = Ui.dp(c, 22);
        hl.bottomMargin = Ui.dp(c, 22);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (onHome != null) onHome.run();
            }
        });
        addView(home, hl);

        paintState();
        radius = Ui.dp(c, 22);
        setOutlineProvider(new ViewOutlineProvider() {
            @Override
            public void getOutline(View v, Outline o) {
                o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), full ? 0 : radius);
            }
        });
        setClipToOutline(true);
    }

    void setOnNowPlaying(Runnable r) {
        onNow = r;
    }

    void setOnHome(Runnable r) {
        onHome = r;
    }

    /** Full screen: no margin and square corners (the dock is hidden by the host). */
    void setFull(boolean on) {
        full = on;
        ViewGroup.LayoutParams lp = getLayoutParams();
        if (lp instanceof ViewGroup.MarginLayoutParams) {
            int m = on ? 0 : Ui.dp(getContext(), 5);
            ((ViewGroup.MarginLayoutParams) lp).setMargins(m, m, m, m);
            requestLayout();
        }
        invalidateOutline();
    }

    /** The song that is playing (has == false hides the song block and uses the plain background). */
    void setMedia(boolean has, String title, String artist, Bitmap art) {
        if (!has) {
            np.setVisibility(View.GONE);
            if (artSrc != null) {
                artSrc = null;
                fade.setSource(null, BASE, 0);
            }
            return;
        }
        Bitmap a = art;
        if (a == null && title != null && title.length() > 0) {
            if (placeholder == null || !title.equals(placeholderFor)) {
                placeholder = Thumbs.placeholder(title, accent, 400);
                placeholderFor = title;
            }
            a = placeholder;
        }
        if (a != artSrc) {
            artSrc = a;
            Bitmap bl = a == null ? null : Thumbs.blur(a, 3);
            fade.setSource(bl, BASE, 0x8C000000);
        }
        tvTitle.setText(title == null ? "" : title);
        tvArtist.setText(artist == null ? "" : artist);
        np.setVisibility(View.VISIBLE);
    }

    void setProgress(float frac) {
        bar.frac = frac;
        bar.invalidate();
    }

    private void paintState() {
        tvState.setText(moving ? "Driving" : "Parked");
        tvState.setBackground(Ui.pill(getContext(), moving ? accent : 0x33FFFFFF, 18));
    }

    /** speedMs: GPS speed in m/s (0 when there is no fix). */
    void setSpeed(float speedMs, boolean mph) {
        gl.setSpeed(speedMs);
        float shown = speedMs * (mph ? 2.23694f : 3.6f);
        boolean mv = speedMs >= 0.8f;
        tvSpeed.setText(String.valueOf(mv ? Math.round(shown) : 0));
        tvUnit.setText(mph ? "mph" : "km/h");
        if (mv != moving) {
            moving = mv;
            paintState();
        }
    }

    /** True while the Car page is the visible slide: only then does the GL view render continuously. */
    void setActive(boolean on) {
        active = on;
        gl.setActive(on && resumed);
    }

    void onHostResume() {
        resumed = true;
        gl.onResume();
        gl.setActive(active);
    }

    void onHostPause() {
        resumed = false;
        gl.setActive(false);
        gl.onPause();
    }
}
