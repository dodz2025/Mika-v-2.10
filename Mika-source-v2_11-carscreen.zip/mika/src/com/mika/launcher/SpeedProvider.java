package com.mika.launcher;

import android.content.Context;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.os.Bundle;
import android.os.SystemClock;

/** GPS speed + heading for the speedometer card. */
class SpeedProvider implements LocationListener {
    interface Listener {
        void onSpeed();
    }

    private final Context ctx;
    private final Listener listener;
    private LocationManager lm;
    boolean hasFix = false;
    Location last;
    float speedMs = 0f;
    float bearing = 0f;
    boolean hasBearing = false;
    private long lastFix = 0;
    private boolean running = false;

    SpeedProvider(Context c, Listener l) {
        ctx = c;
        listener = l;
    }

    void start() {
        if (running) return;
        try {
            lm = (LocationManager) ctx.getSystemService(Context.LOCATION_SERVICE);
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000, 0, this);
                running = true;
            }
        } catch (SecurityException e) {
            running = false;
        } catch (Exception e) {
            running = false;
        }
    }

    void stop() {
        if (lm != null && running) {
            try {
                lm.removeUpdates(this);
            } catch (Exception ignored) {
            }
        }
        running = false;
    }

    /** True when a fix was received in the last few seconds. */
    boolean fresh() {
        return hasFix && SystemClock.elapsedRealtime() - lastFix < 6000;
    }

    @Override
    public void onLocationChanged(Location l) {
        hasFix = true;
        last = l;
        lastFix = SystemClock.elapsedRealtime();
        speedMs = l.hasSpeed() ? l.getSpeed() : 0f;
        hasBearing = l.hasBearing();
        if (hasBearing) bearing = l.getBearing();
        listener.onSpeed();
    }

    @Override
    public void onStatusChanged(String provider, int status, Bundle extras) {
    }

    @Override
    public void onProviderEnabled(String provider) {
    }

    @Override
    public void onProviderDisabled(String provider) {
    }
}
