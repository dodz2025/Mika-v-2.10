package com.mika.launcher;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffXfermode;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.Shader;
import android.view.View;

/**
 * Overlay for the Car page: paints the page background (blurred album cover, or a plain colour) around the
 * screen edges and fades it smoothly to transparent towards the middle, so the 3D street/sky scene underneath
 * melts into the background instead of ending in a hard edge.
 */
final class EdgeFade extends View {
    private Bitmap bmp;
    private int base = 0xFF121721;
    private int scrim = 0;
    private final Paint pBmp = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint pErase = new Paint();
    private final Rect src = new Rect();
    private final RectF dst = new RectF();
    private Shader top, bottom, left, right;
    private float fade;

    private static final int[] A_IN = {0x00000000, 0x28000000, 0x80000000, 0xD7000000, 0xFF000000};
    private static final int[] A_OUT = {0xFF000000, 0xD7000000, 0x80000000, 0x28000000, 0x00000000};
    private static final float[] POS = {0f, 0.25f, 0.5f, 0.75f, 1f};

    EdgeFade(Context c) {
        super(c);
        pErase.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.DST_OUT));
    }

    /** blurred == null draws the plain base colour. scrim is an ARGB colour laid over the cover. */
    void setSource(Bitmap blurred, int baseColor, int scrimColor) {
        bmp = blurred;
        base = baseColor;
        scrim = scrimColor;
        invalidate();
    }

    @Override
    protected void onSizeChanged(int w, int h, int ow, int oh) {
        super.onSizeChanged(w, h, ow, oh);
        fade = Math.min(w, h) * 0.30f;
        top = new LinearGradient(0, 0, 0, fade, A_IN, POS, Shader.TileMode.CLAMP);
        bottom = new LinearGradient(0, h - fade, 0, h, A_OUT, POS, Shader.TileMode.CLAMP);
        left = new LinearGradient(0, 0, fade, 0, A_IN, POS, Shader.TileMode.CLAMP);
        right = new LinearGradient(w - fade, 0, w, 0, A_OUT, POS, Shader.TileMode.CLAMP);
    }

    @Override
    protected void onDraw(Canvas c) {
        int w = getWidth(), h = getHeight();
        if (w <= 0 || h <= 0 || top == null) return;
        int sc = c.saveLayer(0, 0, w, h, null);
        if (bmp != null) {
            float bw = bmp.getWidth(), bh = bmp.getHeight();
            float s = Math.max(w / bw, h / bh);
            int sw = Math.round(w / s), sh = Math.round(h / s);
            int sx = Math.max(0, (int) ((bw - sw) / 2f)), sy = Math.max(0, (int) ((bh - sh) / 2f));
            src.set(sx, sy, Math.min((int) bw, sx + sw), Math.min((int) bh, sy + sh));
            dst.set(0, 0, w, h);
            c.drawBitmap(bmp, src, dst, pBmp);
            if ((scrim >>> 24) != 0) c.drawColor(scrim);
        } else {
            c.drawColor(base);
        }
        pErase.setShader(null);
        pErase.setColor(0xFF000000);
        c.drawRect(fade, fade, w - fade, h - fade, pErase);
        pErase.setShader(top);
        c.drawRect(0, 0, w, fade, pErase);
        pErase.setShader(bottom);
        c.drawRect(0, h - fade, w, h, pErase);
        pErase.setShader(left);
        c.drawRect(0, 0, fade, h, pErase);
        pErase.setShader(right);
        c.drawRect(w - fade, 0, w, h, pErase);
        pErase.setShader(null);
        c.restoreToCount(sc);
    }
}
