package com.mika.launcher;

import android.content.Context;
import android.location.Location;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * The active drive-to-destination session. Shared by the Map screen and the home-screen map card, so the route,
 * next turn and ETA are the same everywhere. Routes come from Valhalla (OpenStreetMap servers, free), with the OSRM demo server as fallback.
 */
final class NavState {
    private NavState() {
    }

    static class Step {
        double lat, lon, dist;
        String type = "", mod = "", text = "";
    }

    private static final Handler MAIN = new Handler(Looper.getMainLooper());

    static boolean active = false;
    static List<double[]> pts;
    static List<Step> steps;
    static int idx = 1;
    static double dist, dur;
    static String destName = "";
    static double destLat, destLon;

    // live values, refreshed by update()
    static double nextDist, remaining, eta;
    static String nextText = "", nextArrow = "\u2191";
    private static int offRoute = 0;
    private static long lastReroute = 0;

    static void stop() {
        active = false;
        pts = null;
        steps = null;
    }

    // ------------------------------------------------------------ progress
    static double meters(double lat1, double lon1, double lat2, double lon2) {
        double r = 6371000, dLat = Math.toRadians(lat2 - lat1), dLon = Math.toRadians(lon2 - lon1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) + Math.cos(Math.toRadians(lat1))
                * Math.cos(Math.toRadians(lat2)) * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        return 2 * r * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    }

    /** Updates next turn, remaining distance and ETA from the current position. Returns true on arrival. */
    static boolean update(Location l) {
        if (!active || steps == null || steps.isEmpty() || l == null) return false;
        double la = l.getLatitude(), lo = l.getLongitude();
        while (idx < steps.size() - 1 && meters(la, lo, steps.get(idx).lat, steps.get(idx).lon) < 35) idx++;
        Step s = steps.get(idx);
        nextDist = meters(la, lo, s.lat, s.lon);
        if (idx == steps.size() - 1 && nextDist < 30) return true;
        nextText = s.text;
        nextArrow = arrow(s);
        remaining = nextDist;
        for (int k = idx; k < steps.size() - 1; k++) remaining += steps.get(k).dist;
        eta = dist > 0 ? dur * Math.min(1.0, remaining / dist) : dur;

        double best = Double.MAX_VALUE;
        for (double[] p : pts) {
            double m = meters(la, lo, p[0], p[1]);
            if (m < best) best = m;
            if (best < 40) break;
        }
        offRoute = best > 120 ? offRoute + 1 : 0;
        return false;
    }

    /** True when the car has been off the route for a few fixes (throttled). */
    static boolean shouldReroute() {
        if (!active || offRoute < 4 || System.currentTimeMillis() - lastReroute < 20000) return false;
        lastReroute = System.currentTimeMillis();
        offRoute = 0;
        return true;
    }

    // ------------------------------------------------------------ routing
    private static final String VALHALLA = "https://valhalla1.openstreetmap.de/route?json=";

    private static class Route {
        double d, t;
        final List<double[]> p = new ArrayList<double[]>();
        final List<Step> st = new ArrayList<Step>();
    }

    static void fetch(final Context ctx, final double fromLat, final double fromLon, final double toLat, final double toLon,
                      final String name, final boolean silent, final Runnable ok, final Runnable fail) {
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String token = Prefs.s(ctx, "mapboxToken", "").trim();
                    Route r;
                    if (token.length() > 0) {
                        // Mapbox Directions with live traffic
                        r = parseOsrm(get(String.format(Locale.US,
                                "https://api.mapbox.com/directions/v5/mapbox/driving-traffic/%f,%f;%f,%f?overview=full&geometries=geojson&steps=true&access_token=%s",
                                fromLon, fromLat, toLon, toLat, token)));
                    } else {
                        try {
                            // free: Valhalla on the OpenStreetMap servers
                            r = parseValhalla(get(valhallaUrl(fromLat, fromLon, toLat, toLon)));
                        } catch (Exception ve) {
                            // fallback: OSRM demo server
                            r = parseOsrm(get(String.format(Locale.US,
                                    "https://router.project-osrm.org/route/v1/driving/%f,%f;%f,%f?overview=full&geometries=geojson&steps=true",
                                    fromLon, fromLat, toLon, toLat)));
                        }
                    }
                    final Route fr = r;
                    MAIN.post(new Runnable() {
                        @Override
                        public void run() {
                            pts = fr.p;
                            steps = fr.st;
                            dist = fr.d;
                            dur = fr.t;
                            idx = fr.st.size() > 1 ? 1 : 0;
                            offRoute = 0;
                            lastReroute = System.currentTimeMillis();
                            destName = name == null ? "" : name;
                            destLat = toLat;
                            destLon = toLon;
                            active = true;
                            if (ok != null) ok.run();
                        }
                    });
                } catch (Exception e) {
                    if (!silent && fail != null) MAIN.post(fail);
                }
            }
        }).start();
    }

    private static String valhallaUrl(double fromLat, double fromLon, double toLat, double toLon) throws Exception {
        JSONObject req = new JSONObject();
        JSONArray locs = new JSONArray();
        locs.put(new JSONObject().put("lat", fromLat).put("lon", fromLon));
        locs.put(new JSONObject().put("lat", toLat).put("lon", toLon));
        req.put("locations", locs);
        req.put("costing", "auto");
        req.put("directions_options", new JSONObject().put("units", "kilometers").put("language", "en-US"));
        return VALHALLA + java.net.URLEncoder.encode(req.toString(), "UTF-8");
    }

    /** OSRM / Mapbox Directions response (geojson geometry, steps). */
    private static Route parseOsrm(String json) throws Exception {
        JSONObject r = new JSONObject(json).getJSONArray("routes").getJSONObject(0);
        Route out = new Route();
        out.d = r.getDouble("distance");
        out.t = r.getDouble("duration");
        JSONArray co = r.getJSONObject("geometry").getJSONArray("coordinates");
        for (int i = 0; i < co.length(); i++) {
            JSONArray c = co.getJSONArray(i);
            out.p.add(new double[]{c.getDouble(1), c.getDouble(0)});
        }
        JSONArray legs = r.getJSONArray("legs");
        for (int li = 0; li < legs.length(); li++) {
            JSONArray js = legs.getJSONObject(li).getJSONArray("steps");
            for (int k = 0; k < js.length(); k++) {
                JSONObject o = js.getJSONObject(k), m = o.getJSONObject("maneuver");
                JSONArray loc = m.getJSONArray("location");
                Step rs = new Step();
                rs.lon = loc.getDouble(0);
                rs.lat = loc.getDouble(1);
                rs.type = m.optString("type", "");
                rs.mod = m.optString("modifier", "");
                rs.dist = o.optDouble("distance", 0);
                rs.text = m.optString("instruction", "");
                if (rs.text.length() == 0) rs.text = stepText(rs.type, rs.mod, o.optString("name", ""));
                out.st.add(rs);
            }
        }
        if (out.p.size() < 2 || out.st.isEmpty()) throw new Exception("empty route");
        return out;
    }

    /** Valhalla /route response: polyline6 shape per leg, maneuvers indexed into that shape. */
    private static Route parseValhalla(String json) throws Exception {
        JSONObject trip = new JSONObject(json).getJSONObject("trip");
        if (trip.optInt("status", 0) != 0) throw new Exception("valhalla status");
        JSONObject sum = trip.getJSONObject("summary");
        Route out = new Route();
        out.d = sum.getDouble("length") * 1000.0; // km -> m
        out.t = sum.getDouble("time");
        JSONArray legs = trip.getJSONArray("legs");
        for (int li = 0; li < legs.length(); li++) {
            JSONObject leg = legs.getJSONObject(li);
            List<double[]> shape = decode6(leg.getString("shape"));
            if (shape.isEmpty()) continue;
            for (int i = li > 0 ? 1 : 0; i < shape.size(); i++) out.p.add(shape.get(i));
            JSONArray ms = leg.getJSONArray("maneuvers");
            for (int k = 0; k < ms.length(); k++) {
                JSONObject m = ms.getJSONObject(k);
                int bi = Math.max(0, Math.min(m.optInt("begin_shape_index", 0), shape.size() - 1));
                Step rs = new Step();
                rs.lat = shape.get(bi)[0];
                rs.lon = shape.get(bi)[1];
                rs.dist = m.optDouble("length", 0) * 1000.0;
                mapValhallaType(m.optInt("type", 0), rs);
                String ins = m.optString("instruction", "").trim();
                while (ins.endsWith(".")) ins = ins.substring(0, ins.length() - 1);
                if (ins.length() == 0) {
                    JSONArray sn = m.optJSONArray("street_names");
                    ins = stepText(rs.type, rs.mod, sn != null && sn.length() > 0 ? sn.optString(0, "") : "");
                }
                rs.text = ins;
                out.st.add(rs);
            }
        }
        if (out.p.size() < 2 || out.st.isEmpty()) throw new Exception("empty route");
        return out;
    }

    /** Translates Valhalla maneuver types into the OSRM-style type/modifier used by arrow() and stepText(). */
    private static void mapValhallaType(int t, Step s) {
        switch (t) {
            case 1: case 2: case 3: s.type = "depart"; s.mod = ""; break;
            case 4: case 5: case 6: s.type = "arrive"; s.mod = ""; break;
            case 9: s.type = "turn"; s.mod = "slight right"; break;
            case 10: s.type = "turn"; s.mod = "right"; break;
            case 11: s.type = "turn"; s.mod = "sharp right"; break;
            case 12: case 13: s.type = "turn"; s.mod = "uturn"; break;
            case 14: s.type = "turn"; s.mod = "sharp left"; break;
            case 15: s.type = "turn"; s.mod = "left"; break;
            case 16: s.type = "turn"; s.mod = "slight left"; break;
            case 17: s.type = "on ramp"; s.mod = "straight"; break;
            case 18: s.type = "on ramp"; s.mod = "slight right"; break;
            case 19: s.type = "on ramp"; s.mod = "slight left"; break;
            case 20: s.type = "off ramp"; s.mod = "slight right"; break;
            case 21: s.type = "off ramp"; s.mod = "slight left"; break;
            case 23: s.type = "fork"; s.mod = "slight right"; break;
            case 24: s.type = "fork"; s.mod = "slight left"; break;
            case 25: case 37: case 38: s.type = "merge"; s.mod = "straight"; break;
            case 26: case 27: s.type = "roundabout"; s.mod = ""; break;
            default: s.type = "continue"; s.mod = "straight"; break; // 0, 7, 8, 22 and anything else
        }
    }

    /** Decodes a Google-style encoded polyline with 6 digits of precision into {lat, lon} pairs. */
    static List<double[]> decode6(String s) {
        List<double[]> out = new ArrayList<double[]>();
        int i = 0, n = s.length(), lat = 0, lon = 0;
        while (i < n) {
            int b, shift = 0, res = 0;
            do {
                b = s.charAt(i++) - 63;
                res |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20 && i < n);
            lat += (res & 1) != 0 ? ~(res >> 1) : (res >> 1);
            shift = 0;
            res = 0;
            do {
                b = s.charAt(i++) - 63;
                res |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20 && i < n);
            lon += (res & 1) != 0 ? ~(res >> 1) : (res >> 1);
            out.add(new double[]{lat / 1e6, lon / 1e6});
        }
        return out;
    }

    private static String get(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(8000);
        c.setReadTimeout(12000);
        c.setRequestProperty("User-Agent", "MikaLauncher/2.8");
        BufferedReader br = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = br.readLine()) != null) sb.append(line);
        br.close();
        return sb.toString();
    }

    // ---------------------------------------------------------- formatting
    static String fmtDist(Context c, double m) {
        if (Prefs.b(c, "speedMph", false)) {
            double ft = m * 3.28084;
            if (ft < 800) return Math.max(10, Math.round(ft / 10) * 10) + " ft";
            return String.format(Locale.US, "%.1f mi", m / 1609.344);
        }
        if (m < 950) return Math.max(10, Math.round(m / 10) * 10) + " m";
        return String.format(Locale.US, "%.1f km", m / 1000.0);
    }

    static String fmtTime(double sec) {
        int min = (int) Math.round(sec / 60.0);
        if (min < 60) return Math.max(1, min) + " min";
        return (min / 60) + " h " + String.format(Locale.US, "%02d", min % 60) + " min";
    }

    static String stepText(String type, String mod, String name) {
        String road = name != null && name.length() > 0 ? " onto " + name : "";
        if ("depart".equals(type)) return "Start" + (name != null && name.length() > 0 ? " on " + name : "");
        if ("arrive".equals(type)) return "You have arrived";
        if (type.startsWith("roundabout") || "rotary".equals(type)) return "At the roundabout, take the exit" + road;
        String dir;
        if ("left".equals(mod)) dir = "Turn left";
        else if ("right".equals(mod)) dir = "Turn right";
        else if ("slight left".equals(mod)) dir = "Keep left";
        else if ("slight right".equals(mod)) dir = "Keep right";
        else if ("sharp left".equals(mod)) dir = "Sharp left";
        else if ("sharp right".equals(mod)) dir = "Sharp right";
        else if ("uturn".equals(mod)) dir = "Make a U-turn";
        else dir = "Continue straight";
        if ("merge".equals(type)) return "Merge" + road;
        if ("fork".equals(type)) return dir.replace("Turn", "Keep") + " at the fork" + road;
        if ("on ramp".equals(type) || "off ramp".equals(type)) return "Take the ramp" + road;
        if ("end of road".equals(type)) return "At the end of the road, " + dir.toLowerCase(Locale.US) + road;
        return dir + road;
    }

    static String arrow(Step s) {
        if ("arrive".equals(s.type)) return "\u2691";
        if (s.type.startsWith("roundabout") || "rotary".equals(s.type)) return "\u21BB";
        String m = s.mod;
        if ("left".equals(m)) return "\u2190";
        if ("right".equals(m)) return "\u2192";
        if ("slight left".equals(m)) return "\u2196";
        if ("slight right".equals(m)) return "\u2197";
        if ("sharp left".equals(m)) return "\u2199";
        if ("sharp right".equals(m)) return "\u2198";
        if ("uturn".equals(m)) return "\u21B6";
        return "\u2191";
    }
}
