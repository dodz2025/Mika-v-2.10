Mika launcher 2.1 - source
Build: needs aapt (v1), JDK 17+, dalvik-exchange (dx), zipalign, apksigner and an android.jar (API 33).
  ANDROID_JAR=/path/to/android.jar ./build.sh
Output: build/Mika-Launcher.apk (debug-signed; create ~/.android/debug.keystore first, or edit build.sh).
Source layout: src/com/mika/launcher/*.java, res/, AndroidManifest.xml

v2.5 changes
- Map: vector 3D map (MapLibre GL JS bundled in assets/, tiles from OpenFreeMap / CARTO, no API key), pan/zoom/rotate/tilt,
  3D buildings, satellite layer, tap places of interest, search anywhere, in-app routing (OSRM demo server) with
  turn-by-turn banner and re-routing. Falls back to the classic raster map when WebGL/WebView isn't available.
  Settings > Map to pick the engine or use the Google Maps app.
- Mirroring: window now draws behind the notch/rounded corners (Settings > Screen & mirroring), optional edge padding.
- Player: works with any media app, always shows a cover (embedded, MediaStore thumbnail, folder.jpg, URI art,
  or a generated one) over a blurred full-screen background. Home widget uses the blurred cover as its background.

v2.6: drive-to-destination now also shows on the home-screen map card (route line, next turn, distance, ETA, end button).
  Shared route state in NavState.java; "Where to?" and Home/Work shortcuts search, pick the best match and start driving.

v2.7
- Fixed: Settings crashed on open (Map engine option used the wrong preference type).
- Home-screen map is now the same vector map as the Map screen (VectorMapView), with the drive-to route on it.
- Optional Mapbox: Settings > Map > Mapbox access token. With a token the map uses Mapbox GL JS (mapbox-gl 2.15, bundled),
  Mapbox navigation day/night styles with traffic, Mapbox Directions (driving-traffic) and Mapbox search.
  Without a token it uses MapLibre + OpenFreeMap / CARTO + OSRM.

v2.8 (routing)
- Free routing now uses Valhalla (valhalla1.openstreetmap.de) instead of the OSRM demo server; OSRM stays as an automatic fallback
  if the Valhalla server is unreachable. A Mapbox token still takes priority when set.

v2.9
- Icons: whole set redrawn in a modern rounded style (soft corners, thicker round pause bars, rounded play/prev/next,
  proper gear, outline home, etc). New icons: volume up/down, car, back, shuffle, repeat(1), replay/forward 10, star, compass, layers, slideshow.
  The emoji/text glyphs in Player, Media library, Video player, Photo viewer, Map and Settings were replaced with these vector icons.
- Volume card: new volume-down / volume-up buttons around the slider; the mute icon follows the volume.
- Home screen: new second slide with your 3D car (assets/car.glb = BAIC U5 Plus). Swipe left/right (or use the car button in the dock;
  swipes starting on the map keep panning the map, edge swipes always switch). The wheels spin, the road scrolls and the body settles with the
  GPS speed, and everything eases to a stop when the car stops. Settings > "Car page" turns the slide off.
