package com.mika.launcher;

import android.content.Context;
import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;
import android.os.SystemClock;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.FloatBuffer;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

/**
 * OpenGL ES 2.0 view of the user's car (assets/car.glb). Speed-driven: the wheels spin, the road
 * scrolls and the body settles with the GPS speed, and everything eases to a halt when the car stops.
 */
class Car3DView extends GLSurfaceView implements GLSurfaceView.Renderer {
    private static final String CAR_VS =
            "uniform mat4 uVP; uniform mat4 uM;\n"
                    + "attribute vec3 aPos; attribute vec3 aNrm; attribute vec4 aCol;\n"
                    + "varying vec3 vN; varying vec3 vP; varying vec4 vC;\n"
                    + "void main(){ vec4 w = uM*vec4(aPos,1.0); vP = w.xyz; vN = (uM*vec4(aNrm,0.0)).xyz; vC = aCol;\n"
                    + "  gl_Position = uVP*w; }\n";
    private static final String CAR_FS =
            "precision mediump float;\n"
                    + "uniform vec3 uEye; uniform vec3 uAccent; uniform float uGlow;\n"
                    + "varying vec3 vN; varying vec3 vP; varying vec4 vC;\n"
                    + "void main(){\n"
                    + "  vec3 n = normalize(vN); vec3 v = normalize(uEye - vP);\n"
                    + "  if (dot(n, v) < 0.0) n = -n;\n"
                    + "  vec3 l = normalize(vec3(0.45, 0.85, 0.35));\n"
                    + "  float d = max(dot(n, l), 0.0);\n"
                    + "  float fill = max(dot(n, normalize(vec3(-0.7, 0.25, -0.6))), 0.0) * 0.22;\n"
                    + "  float hemi = 0.34 + 0.16 * n.y;\n"
                    + "  vec3 h = normalize(l + v);\n"
                    + "  float sp = pow(max(dot(n, h), 0.0), 40.0);\n"
                    + "  float lum = dot(vC.rgb, vec3(0.3, 0.59, 0.11));\n"
                    + "  float gloss = 0.25 + 0.5 * (1.0 - lum);\n"
                    + "  float rim = pow(1.0 - max(dot(n, v), 0.0), 3.0);\n"
                    + "  vec3 col = vC.rgb * (hemi + d * 0.85 + fill) + vec3(sp * gloss) + uAccent * rim * 0.28;\n"
                    + "  if (vC.a > 0.5) col += vC.rgb * uGlow * (vC.a > 1.5 ? 1.0 : 1.6);\n"
                    + "  gl_FragColor = vec4(col, 1.0);\n"
                    + "}\n";
    private static final String GND_VS =
            "uniform mat4 uVP; attribute vec3 aPos; varying vec3 vP;\n"
                    + "void main(){ vP = aPos; gl_Position = uVP*vec4(aPos,1.0); }\n";
    private static final String GND_FS =
            "#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n"
                    + "uniform float uScroll; uniform vec3 uEye; uniform vec3 uAccent; uniform vec3 uFog; uniform vec3 uAsphalt;\n"
                    + "varying vec3 vP;\n"
                    + "void main(){\n"
                    + "  vec2 p = vP.xz; float az = abs(p.y);\n"
                    + "  float road = 1.0 - smoothstep(5.3, 5.7, az);\n"
                    + "  vec3 col = mix(uAsphalt * 0.55, uAsphalt, road);\n"
                    + "  float band = 0.5 + 0.5 * sin((p.x + uScroll) * 2.0943951);\n"
                    + "  col *= 0.96 + 0.04 * band * road;\n"
                    + "  float dash = step(mod(p.x + uScroll, 6.0), 3.0);\n"
                    + "  float ll = (1.0 - smoothstep(0.06, 0.11, abs(az - 2.75))) * dash;\n"
                    + "  col = mix(col, vec3(0.86), ll * 0.85);\n"
                    + "  float e = abs(az - 5.15);\n"
                    + "  col += uAccent * 0.30 * exp(-e * 4.0) * (1.0 - smoothstep(5.15, 5.5, az) * 0.0);\n"
                    + "  col = mix(col, uAccent, (1.0 - smoothstep(0.05, 0.13, e)) * 0.95);\n"
                    + "  float d = length(vec2(p.x / 2.9, p.y / 1.25));\n"
                    + "  col *= mix(0.25, 1.0, smoothstep(0.7, 1.3, d));\n"
                    + "  float dist = length(vP - uEye);\n"
                    + "  col = mix(col, uFog, smoothstep(14.0, 70.0, dist));\n"
                    + "  gl_FragColor = vec4(col, 1.0);\n"
                    + "}\n";
    private static final String SKY_VS =
            "attribute vec2 aPos; void main(){ gl_Position = vec4(aPos, 0.999, 1.0); }\n";
    private static final String SKY_FS =
            "precision mediump float;\n"
                    + "uniform vec2 uRes; uniform vec3 uTop; uniform vec3 uFog;\n"
                    + "void main(){ float v = gl_FragCoord.y / uRes.y;\n"
                    + "  gl_FragColor = vec4(mix(uFog, uTop, smoothstep(0.55, 1.0, v)), 1.0); }\n";

    private final float[] accent = new float[3];
    private Glb model;

    // GL state (render thread)
    private int carProg, gndProg, skyProg;
    private FloatBuffer[] carBuf = new FloatBuffer[5];
    private int[] carCount = new int[5];
    private FloatBuffer gndBuf, skyBuf;
    private final float[] proj = new float[16], view = new float[16], vp = new float[16];
    private final float[] swap = new float[16], bodyM = new float[16], wheelM = new float[16];
    private float aspect = 1.6f;
    private int vw = 1, vh = 1;
    private long lastNs = 0;
    private float speed = 0f, prevSpeed = 0f, scroll = 0f, wheelAng = 0f, time = 0f;

    // written from the UI thread
    private volatile float targetSpeed = 0f;
    private volatile long speedAt = 0L;

    Car3DView(Context c, int accentColor) {
        super(c);
        accent[0] = ((accentColor >> 16) & 0xFF) / 255f;
        accent[1] = ((accentColor >> 8) & 0xFF) / 255f;
        accent[2] = (accentColor & 0xFF) / 255f;
        try {
            InputStream in = c.getAssets().open("car.glb");
            ByteArrayOutputStream bo = new ByteArrayOutputStream();
            byte[] b = new byte[16384];
            int n;
            while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            in.close();
            model = Glb.parse(bo.toByteArray());
        } catch (Throwable t) {
            model = null;
        }
        // model space (X fwd, Y left, Z up) -> world (X fwd, Y up, Z right-handed)
        Matrix.setIdentityM(swap, 0);
        swap[0] = 1; swap[1] = 0; swap[2] = 0;
        swap[4] = 0; swap[5] = 0; swap[6] = -1;
        swap[8] = 0; swap[9] = 1; swap[10] = 0;
        setEGLContextClientVersion(2);
        setEGLConfigChooser(8, 8, 8, 0, 16, 0);
        setRenderer(this);
        setRenderMode(RENDERMODE_WHEN_DIRTY);
    }

    boolean hasModel() {
        return model != null;
    }

    /** Feed the latest GPS speed (m/s). Anything below ~3 km/h counts as standing still. */
    void setSpeed(float ms) {
        targetSpeed = ms < 0.8f ? 0f : ms;
        speedAt = SystemClock.elapsedRealtime();
    }

    /** Render continuously only while the page is on screen. */
    void setActive(boolean on) {
        setRenderMode(on ? RENDERMODE_CONTINUOUSLY : RENDERMODE_WHEN_DIRTY);
        if (on) {
            lastNs = 0;
            requestRender();
        }
    }

    // ------------------------------------------------------------------ GL
    private static int shader(int type, String src) {
        int s = GLES20.glCreateShader(type);
        GLES20.glShaderSource(s, src);
        GLES20.glCompileShader(s);
        return s;
    }

    private static int program(String vs, String fs) {
        int p = GLES20.glCreateProgram();
        GLES20.glAttachShader(p, shader(GLES20.GL_VERTEX_SHADER, vs));
        GLES20.glAttachShader(p, shader(GLES20.GL_FRAGMENT_SHADER, fs));
        GLES20.glLinkProgram(p);
        return p;
    }

    private static FloatBuffer buf(float[] a) {
        FloatBuffer f = ByteBuffer.allocateDirect(a.length * 4).order(ByteOrder.nativeOrder()).asFloatBuffer();
        f.put(a).position(0);
        return f;
    }

    @Override
    public void onSurfaceCreated(GL10 gl, EGLConfig config) {
        carProg = program(CAR_VS, CAR_FS);
        gndProg = program(GND_VS, GND_FS);
        skyProg = program(SKY_VS, SKY_FS);
        if (model != null) {
            carBuf[0] = buf(model.body.v);
            carCount[0] = model.body.count;
            for (int i = 0; i < 4; i++) {
                carBuf[i + 1] = buf(model.wheels[i].v);
                carCount[i + 1] = model.wheels[i].count;
            }
        }
        float g = 300f;
        gndBuf = buf(new float[]{-g, 0, -g, g, 0, -g, -g, 0, g, g, 0, -g, g, 0, g, -g, 0, g});
        skyBuf = buf(new float[]{-1, -1, 1, -1, -1, 1, 1, -1, 1, 1, -1, 1});
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);
        GLES20.glDisable(GLES20.GL_CULL_FACE);
        lastNs = 0;
    }

    @Override
    public void onSurfaceChanged(GL10 gl, int w, int h) {
        vw = Math.max(1, w);
        vh = Math.max(1, h);
        GLES20.glViewport(0, 0, vw, vh);
        aspect = (float) vw / vh;
        Matrix.perspectiveM(proj, 0, FOV, aspect, 0.5f, 400f);
    }

    private static final float FOV = 36f;

    @Override
    public void onDrawFrame(GL10 gl) {
        long now = System.nanoTime();
        float dt = lastNs == 0 ? 0.016f : Math.min(0.05f, (now - lastNs) / 1e9f);
        lastNs = now;
        time += dt;

        // ---- speed easing: speeds up / slows down smoothly, stops fully when the car stops
        float tgt = SystemClock.elapsedRealtime() - speedAt > 5000 ? 0f : targetSpeed;
        prevSpeed = speed;
        speed += (tgt - speed) * (1f - (float) Math.exp(-dt / 0.7f));
        if (tgt == 0f && speed < 0.05f) speed = 0f;
        float vis = 11f * (1f - (float) Math.exp(-speed / 9f)); // saturating visual speed (m/s)
        float accel = dt > 0 ? (speed - prevSpeed) / dt : 0f;
        scroll = (scroll + vis * dt) % 6f;
        wheelAng += vis * dt / (model != null ? model.wheelRadius : 0.35f);
        wheelAng %= (float) (Math.PI * 2);
        float moving = Math.min(1f, speed / 6f);

        // ---- camera
        float yaw = (float) Math.toRadians(38f + 5f * Math.sin(time * 0.35f));
        float el = (float) Math.toRadians(14f + 1.5f * Math.sin(time * 0.23f));
        float tv = (float) Math.tan(Math.toRadians(FOV / 2));
        float dist = Math.max(2.25f / tv, 3.2f / (tv * aspect)) * 1.04f;
        float tx = 0f, ty = 0.7f, tz = 0f;
        float ex = tx + dist * (float) (Math.cos(el) * Math.cos(yaw));
        float ey = ty + dist * (float) Math.sin(el);
        float ez = tz + dist * (float) (Math.cos(el) * Math.sin(yaw));
        Matrix.setLookAtM(view, 0, ex, ey, ez, tx, ty, tz, 0, 1, 0);
        Matrix.multiplyMM(vp, 0, proj, 0, view, 0);

        GLES20.glClearColor(0.07f, 0.09f, 0.13f, 1f);
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);

        // ---- sky
        GLES20.glDisable(GLES20.GL_DEPTH_TEST);
        GLES20.glUseProgram(skyProg);
        GLES20.glUniform2f(GLES20.glGetUniformLocation(skyProg, "uRes"), vw, vh);
        GLES20.glUniform3f(GLES20.glGetUniformLocation(skyProg, "uTop"), 0.02f, 0.03f, 0.06f);
        GLES20.glUniform3f(GLES20.glGetUniformLocation(skyProg, "uFog"), 0.07f, 0.09f, 0.13f);
        int sa = GLES20.glGetAttribLocation(skyProg, "aPos");
        GLES20.glEnableVertexAttribArray(sa);
        GLES20.glVertexAttribPointer(sa, 2, GLES20.GL_FLOAT, false, 8, skyBuf);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 6);
        GLES20.glDisableVertexAttribArray(sa);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);

        // ---- road
        GLES20.glUseProgram(gndProg);
        GLES20.glUniformMatrix4fv(GLES20.glGetUniformLocation(gndProg, "uVP"), 1, false, vp, 0);
        GLES20.glUniform1f(GLES20.glGetUniformLocation(gndProg, "uScroll"), scroll);
        GLES20.glUniform3f(GLES20.glGetUniformLocation(gndProg, "uEye"), ex, ey, ez);
        GLES20.glUniform3f(GLES20.glGetUniformLocation(gndProg, "uAccent"), accent[0], accent[1], accent[2]);
        GLES20.glUniform3f(GLES20.glGetUniformLocation(gndProg, "uFog"), 0.07f, 0.09f, 0.13f);
        GLES20.glUniform3f(GLES20.glGetUniformLocation(gndProg, "uAsphalt"), 0.11f, 0.12f, 0.145f);
        int ga = GLES20.glGetAttribLocation(gndProg, "aPos");
        GLES20.glEnableVertexAttribArray(ga);
        GLES20.glVertexAttribPointer(ga, 3, GLES20.GL_FLOAT, false, 12, gndBuf);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, 6);
        GLES20.glDisableVertexAttribArray(ga);

        // ---- car
        if (model == null) return;
        float bob = 0.012f * moving * (float) Math.sin(time * 17f) + 0.003f * (float) Math.sin(time * 41f);
        float pitch = Math.max(-1.6f, Math.min(1.6f, accel * 0.35f)); // degrees: nose up when accelerating
        Matrix.setIdentityM(wheelM, 0);
        Matrix.translateM(wheelM, 0, 0, bob, 0);
        Matrix.rotateM(wheelM, 0, pitch, 0, 0, 1);
        Matrix.multiplyMM(bodyM, 0, wheelM, 0, swap, 0);

        GLES20.glUseProgram(carProg);
        int uVP = GLES20.glGetUniformLocation(carProg, "uVP");
        int uM = GLES20.glGetUniformLocation(carProg, "uM");
        GLES20.glUniformMatrix4fv(uVP, 1, false, vp, 0);
        GLES20.glUniform3f(GLES20.glGetUniformLocation(carProg, "uEye"), ex, ey, ez);
        GLES20.glUniform3f(GLES20.glGetUniformLocation(carProg, "uAccent"), accent[0], accent[1], accent[2]);
        GLES20.glUniform1f(GLES20.glGetUniformLocation(carProg, "uGlow"), 0.30f + 0.55f * moving);
        int aPos = GLES20.glGetAttribLocation(carProg, "aPos");
        int aNrm = GLES20.glGetAttribLocation(carProg, "aNrm");
        int aCol = GLES20.glGetAttribLocation(carProg, "aCol");
        GLES20.glEnableVertexAttribArray(aPos);
        GLES20.glEnableVertexAttribArray(aNrm);
        GLES20.glEnableVertexAttribArray(aCol);

        drawGroup(0, bodyM, uM, aPos, aNrm, aCol);
        float deg = (float) Math.toDegrees(wheelAng);
        for (int i = 0; i < 4; i++) {
            Glb.Group w = model.wheels[i];
            System.arraycopy(bodyM, 0, wheelM, 0, 16);
            Matrix.translateM(wheelM, 0, w.px, w.py, w.pz);
            Matrix.rotateM(wheelM, 0, deg, 0, 1, 0);
            Matrix.translateM(wheelM, 0, -w.px, -w.py, -w.pz);
            drawGroup(i + 1, wheelM, uM, aPos, aNrm, aCol);
        }
        GLES20.glDisableVertexAttribArray(aPos);
        GLES20.glDisableVertexAttribArray(aNrm);
        GLES20.glDisableVertexAttribArray(aCol);
    }

    private void drawGroup(int i, float[] m, int uM, int aPos, int aNrm, int aCol) {
        FloatBuffer b = carBuf[i];
        if (b == null || carCount[i] == 0) return;
        GLES20.glUniformMatrix4fv(uM, 1, false, m, 0);
        int stride = Glb.STRIDE * 4;
        b.position(0);
        GLES20.glVertexAttribPointer(aPos, 3, GLES20.GL_FLOAT, false, stride, b);
        b.position(3);
        GLES20.glVertexAttribPointer(aNrm, 3, GLES20.GL_FLOAT, false, stride, b);
        b.position(6);
        GLES20.glVertexAttribPointer(aCol, 4, GLES20.GL_FLOAT, false, stride, b);
        GLES20.glDrawArrays(GLES20.GL_TRIANGLES, 0, carCount[i]);
        b.position(0);
    }
}
