package com.mika.launcher;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.ColorStateList;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.location.Location;
import android.location.LocationManager;
import android.media.AudioManager;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.GestureDetector;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextClock;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/**
 * Mika - a free, full-featured car-style home-screen launcher.
 * Dashboard: clock, weather, now-playing, GPS speed, volume, frequent apps, dock + app drawer.
 */
public class MainActivity extends Activity implements MediaTracker.Listener, SpeedProvider.Listener {

    static final int MAX_DOCK = 6;
    private static final int REQ_LOC = 11;
    private static final String[] COMPASS = {"N", "NE", "E", "SE", "S", "SW", "W", "NW"};

    // state
    private Pal pal;
    private boolean landscape;
    private String lastKey = "";
    private String lastSig = "";
    private boolean drawerOpen = false;
    private int tick = 0;
    private final Handler handler = new Handler();
    private GestureDetector gestures;
    private MediaTracker media;
    private SpeedProvider speedProvider;
    private BroadcastReceiver pkgReceiver, batteryReceiver;
    private AudioManager audio;
    private boolean askedPermissionThisSession = false;
    private boolean weatherLoading = false;

    // apps
    private final List<AppEntry> allApps = new ArrayList<AppEntry>();
    private final List<AppEntry> shown = new ArrayList<AppEntry>();

    // views
    private FrameLayout root;
    private LinearLayout drawerView, dockView, frequentRow, wxForecast, musicBody, musicNotice;
    private GridView grid;
    private EditText search;
    private AppAdapter adapter;
    private TextView tvBattery, tvNet;
    private TextView tvWxIcon, tvWxTemp, tvWxDesc, tvWxExtra, tvWxPlace;
    private TextView tvTitle, tvArtist, tvPos, tvDur;
    private android.widget.ImageView btnPlay;
    private ImageView ivArt;
    private LinearLayout musicCard;
    private android.graphics.drawable.Drawable musicDefaultBg;
    private Bitmap bgSource, placeholderArt;
    private String placeholderFor = "";
    private ProgressBar mediaProgress;
    private TextView tvSpeed, tvSpeedUnit, tvHeading, tvGps;
    private SeekBar volBar;
    private View volMute;
    private HomePager pager;
    private CarPage carPage;
    private View dockCarBtn;
    private int homePage = 0;
    private boolean hostResumed = false;
    private MapSurface miniMap;
    private View miniMapView;
    private static boolean homeRaster = false;
    private LinearLayout homeNav;
    private TextView hnArrow, hnDist, hnText, hnEta;
    private List<double[]> homeRouteShown;
    private boolean homeNavZoomed = false;
    private final Runnable playerListener = new Runnable() {
        @Override
        public void run() {
            updateMediaUi();
        }
    };
    private boolean volTouching = false;
    private int lastVolBeforeMute = 5;

    static class AppEntry {
        String label, pkg, cls;
        Drawable icon;
        long installTime;

        String key() {
            return pkg + "/" + cls;
        }
    }

    // =========================================================== lifecycle
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        audio = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        media = new MediaTracker(this, this);
        speedProvider = new SpeedProvider(this, this);

        gestures = new GestureDetector(this, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onFling(MotionEvent e1, MotionEvent e2, float vx, float vy) {
                if (e1 == null || e2 == null || drawerOpen) return false;
                if (!Prefs.b(MainActivity.this, "swipeUp", true)) return false;
                float dy = e2.getY() - e1.getY();
                float dx = e2.getX() - e1.getX();
                if (dy < -Ui.dp(MainActivity.this, 90) && Math.abs(dy) > Math.abs(dx) * 1.5f && vy < -500) {
                    openDrawer();
                }
                return false;
            }
        });

        buildUi();
        loadApps();

        pkgReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) {
                loadApps();
            }
        };
        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_PACKAGE_ADDED);
        f.addAction(Intent.ACTION_PACKAGE_REMOVED);
        f.addAction(Intent.ACTION_PACKAGE_CHANGED);
        f.addDataScheme("package");
        registerReceiver(pkgReceiver, f);

        batteryReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context c, Intent i) {
                updateBattery(i);
            }
        };
        Intent sticky = registerReceiver(batteryReceiver, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        updateBattery(sticky);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (miniMap instanceof VectorMapView) ((VectorMapView) miniMap).destroy();
        try {
            unregisterReceiver(pkgReceiver);
            unregisterReceiver(batteryReceiver);
        } catch (Exception ignored) {
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        hostResumed = true;
        if (carPage != null) carPage.onHostResume();
        hideSystemBars();
        if (miniMap instanceof VectorMapView) ((VectorMapView) miniMap).onHostResume();
        String sig = Prefs.p(this).getAll().toString();
        if (!sig.equals(lastSig) && lastSig.length() > 0) {
            rebuild();
        }
        lastSig = Prefs.p(this).getAll().toString();
        media.start();
        PlayerService.LISTENERS.add(playerListener);
        maybeRequestLocation();
        startSpeedIfNeeded();
        updateHomeNav();
        refreshWeather(false);
        updateNetwork();
        updateMediaUi();
        updateMiniMap();
        syncVolume();
        handler.removeCallbacks(ticker);
        handler.post(ticker);
    }

    @Override
    protected void onPause() {
        super.onPause();
        hostResumed = false;
        if (carPage != null) carPage.onHostPause();
        if (miniMap instanceof VectorMapView) ((VectorMapView) miniMap).onHostPause();
        media.stop();
        PlayerService.LISTENERS.remove(playerListener);
        speedProvider.stop();
        handler.removeCallbacks(ticker);
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        if (Intent.ACTION_MAIN.equals(intent.getAction())) closeDrawer();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        rebuild();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) hideSystemBars();
    }

    @Override
    public void onBackPressed() {
        if (drawerOpen) closeDrawer();
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        gestures.onTouchEvent(ev);
        return super.dispatchTouchEvent(ev);
    }

    private void applyEdgePadding(View content) {
        int e = Prefs.i(this, "edge", -1);
        if (e >= 0) content.setPadding(dp(e), dp(e), dp(e), dp(e));
    }

    private void hideSystemBars() {
        Ui.immersive(this);
    }

    private final Runnable ticker = new Runnable() {
        @Override
        public void run() {
            tick++;
            updateMediaProgress();
            syncVolume();
            if (tick % 5 == 0) {
                updateNetwork();
                updateSpeedUi();
                updateMiniMap();
            }
            if (tick % 60 == 0) {
                refreshWeather(false);
                if (!Pal.key(MainActivity.this).equals(lastKey)) {
                    rebuild();
                }
            }
            handler.postDelayed(this, 1000);
        }
    };

    // ============================================================ building
    private int dp(int v) {
        return Ui.dp(this, v);
    }

    private void rebuild() {
        boolean wasOpen = drawerOpen;
        buildUi();
        refreshShown("");
        refreshDock();
        refreshFrequent();
        refreshWeather(false);
        updateMediaUi();
        updateNetwork();
        updateSpeedUi();
        updateMiniMap();
        syncVolume();
        if (wasOpen) openDrawer();
    }

    private void clearRefs() {
        dockView = null;
        frequentRow = null;
        wxForecast = null;
        musicBody = null;
        musicNotice = null;
        tvBattery = null;
        tvNet = null;
        tvWxIcon = null;
        tvWxTemp = null;
        tvWxDesc = null;
        tvWxExtra = null;
        tvWxPlace = null;
        tvTitle = null;
        tvArtist = null;
        btnPlay = null;
        tvPos = null;
        tvDur = null;
        ivArt = null;
        mediaProgress = null;
        tvSpeed = null;
        tvSpeedUnit = null;
        tvHeading = null;
        tvGps = null;
        volBar = null;
        volMute = null;
        if (carPage != null) carPage.onHostPause();
        carPage = null;
        pager = null;
        dockCarBtn = null;
        if (miniMap instanceof VectorMapView) ((VectorMapView) miniMap).destroy();
        miniMap = null;
        miniMapView = null;
        homeNav = null;
        homeRouteShown = null;
        homeNavZoomed = false;
    }

    private void buildUi() {
        clearRefs();
        pal = Pal.of(this);
        lastKey = Pal.key(this);
        landscape = getResources().getDisplayMetrics().widthPixels
                > getResources().getDisplayMetrics().heightPixels;

        root = new FrameLayout(this);
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM,
                new int[]{pal.bgTop, pal.bgBottom}));

        Bitmap wp = Prefs.loadWallpaper(this);
        if (wp != null) {
            ImageView iv = new ImageView(this);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            iv.setImageBitmap(wp);
            root.addView(iv, new FrameLayout.LayoutParams(-1, -1));
            View dim = new View(this);
            int alpha = Prefs.i(this, "dim", 40) * 255 / 100;
            dim.setBackgroundColor(Color.argb(alpha, 0, 0, 0));
            root.addView(dim, new FrameLayout.LayoutParams(-1, -1));
        }

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setPadding(dp(18), dp(12), dp(18), dp(14));
        if (carLayout()) {
            content.setPadding(dp(12), dp(10), dp(12), dp(10));
            content.addView(wrapPager(buildCarBody()), new LinearLayout.LayoutParams(-1, 0, 1f));
            content.addView(buildCarDock(), new LinearLayout.LayoutParams(-1, -2));
        } else {
            content.addView(buildTopBar(), new LinearLayout.LayoutParams(-1, -2));
            content.addView(wrapPager(buildBody()), new LinearLayout.LayoutParams(-1, 0, 1f));
            content.addView(buildBottomBar(), new LinearLayout.LayoutParams(-1, -2));
        }
        applyEdgePadding(content);
        root.addView(content, new FrameLayout.LayoutParams(-1, -1));

        drawerView = buildDrawer();
        drawerView.setVisibility(View.GONE);
        root.addView(drawerView, new FrameLayout.LayoutParams(-1, -1));

        setContentView(root);
        drawerOpen = false;
    }

    private View buildTopBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(0, 0, 0, dp(8));

        tvNet = Ui.text(this, "", 15, pal.sub);
        tvBattery = Ui.text(this, "", 15, pal.sub);
        bar.addView(tvNet);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.leftMargin = dp(18);
        bar.addView(tvBattery, lp);

        View spacer = new View(this);
        bar.addView(spacer, new LinearLayout.LayoutParams(0, 0, 1f));

        View lay = Ui.iconButton(this, Icons.LAYOUT, 44, 22, pal.card, pal.text);
        lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layoutDialog();
            }
        });
        LinearLayout.LayoutParams lyl = new LinearLayout.LayoutParams(dp(44), dp(44));
        lyl.rightMargin = dp(10);
        bar.addView(lay, lyl);
        View gear = Ui.iconButton(this, Icons.GEAR, 44, 22, pal.card, pal.text);
        gear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            }
        });
        bar.addView(gear);
        return bar;
    }

    private LinearLayout card(String title) {
        LinearLayout c = new LinearLayout(this);
        c.setOrientation(LinearLayout.VERTICAL);
        c.setGravity(Gravity.CENTER);
        c.setBackground(Ui.glass(this, pal.card, pal.dark ? 0x2EFFFFFF : 0x1F000000, 28));
        c.setPadding(dp(18), dp(16), dp(18), dp(16));
        if (title != null) {
            TextView t = Ui.text(this, title.toUpperCase(Locale.getDefault()), 11, pal.sub);
            t.setLetterSpacing(0.12f);
            t.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.bottomMargin = dp(6);
            c.addView(t, lp);
        }
        return c;
    }

    private View buildBody() {
        boolean sw = Prefs.b(this, "showWeather", true);
        boolean sm = Prefs.b(this, "showMusic", true);
        boolean ss = Prefs.b(this, "showSpeed", true);
        boolean sf = Prefs.b(this, "showFrequent", true);
        boolean sv = Prefs.b(this, "showVolume", true);
        boolean smap = Prefs.b(this, "showMap", true);

        List<View> c1 = new ArrayList<View>();
        List<View> c2 = new ArrayList<View>();
        List<View> c3 = new ArrayList<View>();
        c1.add(buildClockCard());
        if (sw) c1.add(buildWeatherCard());
        if (sf) c1.add(buildFrequentCard());
        if (sm) c2.add(buildMusicCard());
        if (smap) c2.add(buildMapCard());
        if (ss) c3.add(buildSpeedCard());
        if (sv) c3.add(buildVolumeCard());
        c3.add(buildQuickCard());

        if (landscape) {
            LinearLayout cols = new LinearLayout(this);
            cols.setOrientation(LinearLayout.HORIZONTAL);
            addColumn(cols, c1, 1.0f);
            addColumn(cols, c2, 1.15f);
            addColumn(cols, c3, 0.9f);
            return cols;
        }
        ScrollView sc = new ScrollView(this);
        sc.setFillViewport(true);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        List<View> all = new ArrayList<View>();
        all.addAll(c1);
        all.addAll(c2);
        all.addAll(c3);
        for (View v : all) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
            lp.bottomMargin = dp(10);
            col.addView(v, lp);
        }
        sc.addView(col, new ViewGroup.LayoutParams(-1, -2));
        return sc;
    }

    private void addColumn(LinearLayout parent, List<View> views, float weight) {
        if (views.isEmpty()) return;
        ScrollView sc = new ScrollView(this);
        sc.setFillViewport(true);
        sc.setVerticalScrollBarEnabled(false);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        for (View v : views) {
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2, 1f);
            lp.topMargin = dp(5);
            lp.bottomMargin = dp(5);
            col.addView(v, lp);
        }
        sc.addView(col, new ViewGroup.LayoutParams(-1, -2));
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(0, -1, weight);
        cp.leftMargin = dp(6);
        cp.rightMargin = dp(6);
        parent.addView(sc, cp);
    }


    // =============================================================== car layout
    private float mapZoom = 14f;

    static final String[] LAYOUT_NAMES = {"Cockpit", "Mirror", "Map focus", "Media focus",
            "Wide dash", "Duo", "Navigator", "Classic"};
    private float musicFrac = 1f;

    private int layoutId() {
        if (Prefs.p(this).contains("layoutId")) {
            return Math.max(0, Math.min(LAYOUT_NAMES.length - 1, Prefs.i(this, "layoutId", 0)));
        }
        return Prefs.b(this, "carLayout", true) ? 0 : 7;
    }

    private boolean carLayout() {
        return layoutId() != 7;
    }

    private int pref(String k, int def, int lo, int hi) {
        return Math.max(lo, Math.min(hi, Prefs.i(this, k, def)));
    }

    private int artDp() {
        if (!carLayout()) return landscape ? 120 : 140;
        float hDp = getResources().getDisplayMetrics().heightPixels / getResources().getDisplayMetrics().density;
        float h = (hDp - 150f) * musicFrac;
        float art = h - 200f;
        if (art < 48f) return 0;
        return (int) Math.min(170f, art);
    }

    private View buildCarDefault() {
        boolean smap = Prefs.b(this, "showMap", true);
        boolean sm = Prefs.b(this, "showMusic", true);
        if (!landscape) {
            LinearLayout v = new LinearLayout(this);
            v.setOrientation(LinearLayout.VERTICAL);
            int hMapP = pref("hMap", 50, 30, 80);
            int mapW = smap ? hMapP * 36 / 100 : 0;
            if (smap) addTo(v, carMapCard(), Math.max(20, mapW));
            addTo(v, carInfoCard(), 20);
            if (sm) addTo(v, buildMusicCard(), 46);
            else if (Prefs.b(this, "showVolume", true)) addTo(v, buildVolumeCard(), 30);
            return v;
        }
        LinearLayout cols = new LinearLayout(this);
        cols.setOrientation(LinearLayout.HORIZONTAL);
        int wl = pref("wLeft", 50, 30, 70);
        int hMap = pref("hMap", 50, 30, 80);
        int hMusic = pref("hMusic", 100, 50, 100);

        LinearLayout left = new LinearLayout(this);
        left.setOrientation(LinearLayout.VERTICAL);
        View info = carInfoCard();
        if (smap) {
            addTo(left, carMapCard(), hMap);
            addTo(left, info, 100 - hMap);
        } else {
            addTo(left, info, 100);
        }
        LinearLayout right = new LinearLayout(this);
        right.setOrientation(LinearLayout.VERTICAL);
        if (sm) {
            addTo(right, buildMusicCard(), hMusic);
            if (hMusic < 95) {
                LinearLayout strip = new LinearLayout(this);
                strip.setOrientation(LinearLayout.VERTICAL);
                if (!smap) addTo(strip, buildSpeedCard(), 50);
                if (Prefs.b(this, "showVolume", true)) addTo(strip, buildVolumeCard(), 50);
                addTo(right, strip, 100 - hMusic);
            }
        } else if (Prefs.b(this, "showVolume", true)) {
            addTo(right, buildVolumeCard(), 100);
        }
        cols.addView(left, new LinearLayout.LayoutParams(0, -1, wl));
        cols.addView(right, new LinearLayout.LayoutParams(0, -1, 100 - wl));
        return cols;
    }

    private void addTo(LinearLayout col, View v, int weight) {
        LinearLayout.LayoutParams lp = col.getOrientation() == LinearLayout.HORIZONTAL
                ? new LinearLayout.LayoutParams(0, -1, weight) : new LinearLayout.LayoutParams(-1, 0, weight);
        lp.setMargins(dp(5), dp(5), dp(5), dp(5));
        col.addView(v, lp);
        v.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View x) {
                resizeDialog();
                return true;
            }
        });
    }

    private View carMapCard() {
        FrameLayout f = new FrameLayout(this);
        f.setBackground(Ui.glass(this, pal.card, pal.dark ? 0x2EFFFFFF : 0x1F000000, 28));
        f.setClipToOutline(true);
        mapZoom = 14f;
        newMiniMap();
        miniMap.setZoom(mapZoom);
        try {
            miniMap.setCenter(Double.parseDouble(Prefs.s(this, "mapLat", "48.8566")),
                    Double.parseDouble(Prefs.s(this, "mapLon", "2.3522")));
        } catch (Exception ignored) {
        }
        miniMapView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMaps(null);
            }
        });
        f.addView(miniMapView, new FrameLayout.LayoutParams(-1, -1));
        FrameLayout.LayoutParams hnp = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        hnp.setMargins(dp(10), dp(10), dp(10), 0);
        f.addView(buildHomeNavStrip(), hnp);

        // speed bubble + navigate (bottom-left)
        LinearLayout lb = new LinearLayout(this);
        lb.setOrientation(LinearLayout.VERTICAL);
        lb.setGravity(Gravity.CENTER_HORIZONTAL);
        LinearLayout sp = new LinearLayout(this);
        sp.setOrientation(LinearLayout.VERTICAL);
        sp.setGravity(Gravity.CENTER);
        sp.setBackground(Ui.pill(this, pal.panel, 30));
        tvSpeed = Ui.text(this, "--", 17, pal.text);
        tvSpeed.setTypeface(Typeface.DEFAULT_BOLD);
        tvSpeedUnit = Ui.text(this, "km/h", 9, pal.sub);
        tvHeading = Ui.text(this, "", 10, pal.accent);
        tvGps = Ui.text(this, "", 10, pal.sub);
        sp.addView(tvSpeed);
        sp.addView(tvSpeedUnit);
        lb.addView(sp, new LinearLayout.LayoutParams(dp(54), dp(54)));
        View nav = Ui.iconButton(this, Icons.NAV, 46, 22, pal.panel, pal.accent);
        nav.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askDestination();
            }
        });
        LinearLayout.LayoutParams nl = new LinearLayout.LayoutParams(dp(46), dp(46));
        nl.topMargin = dp(8);
        lb.addView(nav, nl);
        FrameLayout.LayoutParams lbp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.LEFT);
        lbp.setMargins(dp(12), 0, 0, dp(12));
        f.addView(lb, lbp);

        // zoom pill (right)
        LinearLayout z = new LinearLayout(this);
        z.setOrientation(LinearLayout.VERTICAL);
        z.setBackground(Ui.pill(this, pal.panel, 20));
        z.addView(zoomBtn(Icons.PLUS, 1f), new LinearLayout.LayoutParams(dp(44), dp(44)));
        z.addView(zoomBtn(Icons.MINUS, -1f), new LinearLayout.LayoutParams(dp(44), dp(44)));
        FrameLayout.LayoutParams zp = new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_VERTICAL | Gravity.RIGHT);
        zp.rightMargin = dp(10);
        f.addView(z, zp);
        return f;
    }

    private View zoomBtn(int icon, final float delta) {
        FrameLayout b = new FrameLayout(this);
        b.addView(Icons.view(this, icon, 20, pal.text), new FrameLayout.LayoutParams(dp(20), dp(20), Gravity.CENTER));
        b.setClickable(true);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                mapZoom = Math.max(3f, Math.min(19f, mapZoom + delta));
                if (miniMap != null) miniMap.setZoom(mapZoom);
            }
        });
        return b;
    }

    private View placeCircle(int icon, final String label, final String key) {
        View b = Ui.iconButton(this, icon, 42, 20, pal.card, pal.text);
        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String addr = Prefs.s(MainActivity.this, key, "");
                if (addr.length() == 0) editPlace(label, key);
                else openMaps(addr);
            }
        });
        b.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                editPlace(label, key);
                return true;
            }
        });
        return b;
    }

    private View carInfoCard() {
        LinearLayout c = card(null);
        c.setPadding(dp(14), dp(10), dp(14), dp(10));
        c.setGravity(Gravity.CENTER_VERTICAL);

        LinearLayout r1 = new LinearLayout(this);
        r1.setGravity(Gravity.CENTER_VERTICAL);
        View mic = Ui.iconButton(this, Icons.MIC, 42, 20, pal.card, pal.text);
        mic.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    startActivity(new Intent(Intent.ACTION_VOICE_COMMAND).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                } catch (Exception e) {
                    try {
                        startActivity(new Intent("android.intent.action.VOICE_ASSIST").addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                    } catch (Exception e2) {
                        Toast.makeText(MainActivity.this, "No voice assistant available", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
        int cs = dp(42);
        LinearLayout.LayoutParams cp = new LinearLayout.LayoutParams(cs, cs);
        cp.rightMargin = dp(8);
        r1.addView(mic, cp);
        LinearLayout.LayoutParams cp2 = new LinearLayout.LayoutParams(cs, cs);
        cp2.rightMargin = dp(8);
        r1.addView(placeCircle(Icons.HOME, "Home", "homeAddr"), cp2);
        LinearLayout.LayoutParams cp3 = new LinearLayout.LayoutParams(cs, cs);
        cp3.rightMargin = dp(8);
        r1.addView(placeCircle(Icons.WORK, "Work", "workAddr"), cp3);
        LinearLayout pillS = new LinearLayout(this);
        pillS.setGravity(Gravity.CENTER_VERTICAL);
        pillS.setBackground(Ui.pill(this, pal.card, 24));
        pillS.setPadding(dp(14), dp(0), dp(14), dp(0));
        pillS.addView(Icons.view(this, Icons.SEARCH, 18, pal.sub));
        TextView sh = Ui.text(this, "Search", 14, pal.sub);
        LinearLayout.LayoutParams shl = new LinearLayout.LayoutParams(-2, -2);
        shl.leftMargin = dp(8);
        pillS.addView(sh, shl);
        pillS.setClickable(true);
        pillS.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askDestination();
            }
        });
        r1.addView(pillS, new LinearLayout.LayoutParams(0, cs, 1f));
        c.addView(r1, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout r2 = new LinearLayout(this);
        r2.setGravity(Gravity.CENTER_VERTICAL);
        TextClock dow = new TextClock(this);
        dow.setFormat24Hour("EEE");
        dow.setFormat12Hour("EEE");
        dow.setTextSize(20);
        dow.setTextColor(pal.text);
        dow.setTypeface(Typeface.DEFAULT_BOLD);
        r2.addView(dow);
        LinearLayout dm = new LinearLayout(this);
        dm.setOrientation(LinearLayout.VERTICAL);
        dm.setGravity(Gravity.CENTER);
        TextClock dd = new TextClock(this);
        dd.setFormat24Hour("d");
        dd.setFormat12Hour("d");
        dd.setTextSize(18);
        dd.setTextColor(pal.text);
        dd.setTypeface(Typeface.DEFAULT_BOLD);
        TextClock mm = new TextClock(this);
        mm.setFormat24Hour("MMM");
        mm.setFormat12Hour("MMM");
        mm.setTextSize(11);
        mm.setTextColor(pal.sub);
        dm.addView(dd);
        dm.addView(mm);
        LinearLayout.LayoutParams dml = new LinearLayout.LayoutParams(-2, -2);
        dml.leftMargin = dp(12);
        r2.addView(dm, dml);
        View div = new View(this);
        div.setBackgroundColor(pal.dark ? 0x33FFFFFF : 0x22000000);
        LinearLayout.LayoutParams dvl = new LinearLayout.LayoutParams(dp(1), dp(32));
        dvl.leftMargin = dp(14);
        dvl.rightMargin = dp(14);
        r2.addView(div, dvl);

        tvWxIcon = Ui.text(this, "\u2026", 26, pal.text);
        tvWxTemp = Ui.text(this, "--\u00B0", 22, pal.text);
        tvWxTemp.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        tvWxDesc = Ui.text(this, "Weather", 14, pal.text);
        tvWxDesc.setSingleLine(true);
        tvWxDesc.setEllipsize(TextUtils.TruncateAt.END);
        tvWxExtra = Ui.text(this, "", 11, pal.sub);
        tvWxExtra.setSingleLine(true);
        tvWxExtra.setEllipsize(TextUtils.TruncateAt.END);
        tvWxPlace = Ui.text(this, "", 10, pal.sub);
        wxForecast = new LinearLayout(this);
        r2.addView(tvWxIcon);
        LinearLayout wt = new LinearLayout(this);
        wt.setOrientation(LinearLayout.VERTICAL);
        wt.addView(tvWxDesc);
        wt.addView(tvWxExtra);
        LinearLayout.LayoutParams wtl = new LinearLayout.LayoutParams(0, -2, 1f);
        wtl.leftMargin = dp(8);
        r2.addView(wt, wtl);
        r2.addView(tvWxTemp);
        r2.setClickable(true);
        r2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                refreshWeather(true);
            }
        });
        LinearLayout.LayoutParams r2l = new LinearLayout.LayoutParams(-1, -2);
        r2l.topMargin = dp(10);
        c.addView(r2, r2l);
        return c;
    }

    private View buildCarDock() {
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(5), dp(6), dp(5), 0);

        View apps = Ui.iconButton(this, Icons.APPS, 58, 28, pal.accent, 0xFFFFFFFF);
        apps.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDrawer();
            }
        });
        LinearLayout.LayoutParams al = new LinearLayout.LayoutParams(dp(58), dp(58));
        al.rightMargin = dp(10);
        bar.addView(apps, al);

        dockView = new LinearLayout(this);
        dockView.setGravity(Gravity.CENTER_VERTICAL);
        dockView.setPadding(dp(10), dp(4), dp(10), dp(4));
        dockView.setBackground(Ui.glass(this, pal.card, pal.dark ? 0x2EFFFFFF : 0x1F000000, 32));
        bar.addView(dockView, new LinearLayout.LayoutParams(0, -2, 1f));

        LinearLayout cl = new LinearLayout(this);
        cl.setGravity(Gravity.CENTER_VERTICAL);
        cl.setPadding(dp(14), dp(4), dp(8), dp(4));
        cl.setBackground(Ui.glass(this, pal.card, pal.dark ? 0x2EFFFFFF : 0x1F000000, 32));
        LinearLayout tcol = new LinearLayout(this);
        tcol.setOrientation(LinearLayout.VERTICAL);
        TextClock clock = new TextClock(this);
        String fmt = Prefs.b(this, "h24", true) ? "HH:mm" : "h:mm a";
        clock.setFormat24Hour(fmt);
        clock.setFormat12Hour(fmt);
        clock.setTextSize(20);
        clock.setTextColor(pal.text);
        clock.setTypeface(Typeface.DEFAULT_BOLD);
        tcol.addView(clock);
        LinearLayout st = new LinearLayout(this);
        st.setGravity(Gravity.CENTER_VERTICAL);
        tvNet = Ui.text(this, "", 10, pal.sub);
        tvBattery = Ui.text(this, "", 10, pal.sub);
        st.addView(tvNet);
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-2, -2);
        bl.leftMargin = dp(8);
        st.addView(tvBattery, bl);
        tcol.addView(st);
        cl.addView(tcol);
        if (carPageEnabled()) {
            dockCarBtn = Ui.iconButton(this, Icons.CAR, 40, 22, pal.card, pal.text);
            dockCarBtn.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (pager != null) pager.setPage(pager.getPage() == 0 ? 1 : 0, true);
                }
            });
            LinearLayout.LayoutParams cbl = new LinearLayout.LayoutParams(dp(40), dp(40));
            cbl.leftMargin = dp(10);
            cl.addView(dockCarBtn, cbl);
            tintCarBtn();
        }
        View music = Ui.iconButton(this, Icons.MUSIC, 40, 20, pal.card, pal.text);
        music.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, LibraryActivity.class));
            }
        });
        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(dp(40), dp(40));
        ml.leftMargin = dp(dockCarBtn != null ? 6 : 10);
        cl.addView(music, ml);
        View lay = Ui.iconButton(this, Icons.LAYOUT, 40, 20, pal.card, pal.text);
        lay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layoutDialog();
            }
        });
        lay.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                resizeDialog();
                return true;
            }
        });
        LinearLayout.LayoutParams lyl = new LinearLayout.LayoutParams(dp(40), dp(40));
        lyl.leftMargin = dp(6);
        cl.addView(lay, lyl);
        View gear = Ui.iconButton(this, Icons.GEAR, 40, 20, pal.card, pal.text);
        gear.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, SettingsActivity.class));
            }
        });
        gear.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                resizeDialog();
                return true;
            }
        });
        LinearLayout.LayoutParams gl = new LinearLayout.LayoutParams(dp(40), dp(40));
        gl.leftMargin = dp(6);
        cl.addView(gear, gl);
        if (!landscape) {
            LinearLayout wrap = new LinearLayout(this);
            wrap.setOrientation(LinearLayout.VERTICAL);
            wrap.addView(bar, new LinearLayout.LayoutParams(-1, -2));
            LinearLayout.LayoutParams cwl = new LinearLayout.LayoutParams(-1, -2);
            cwl.topMargin = dp(8);
            cl.setGravity(Gravity.CENTER_VERTICAL);
            wrap.addView(cl, cwl);
            tcol.setLayoutParams(new LinearLayout.LayoutParams(0, -2, 1f));
            return wrap;
        }
        LinearLayout.LayoutParams cll = new LinearLayout.LayoutParams(-2, -2);
        cll.leftMargin = dp(10);
        bar.addView(cl, cll);
        return bar;
    }


    // ------------------------------------------------------------- layouts
    private LinearLayout box(boolean vertical) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(vertical ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
        return l;
    }

    private void add(LinearLayout parent, View v, int w) {
        parent.addView(v, parent.getOrientation() == LinearLayout.HORIZONTAL
                ? new LinearLayout.LayoutParams(0, -1, w) : new LinearLayout.LayoutParams(-1, 0, w));
    }

    private View musicCol(int hMusic) {
        LinearLayout r = box(true);
        musicFrac = hMusic / 100f;
        addTo(r, buildMusicCard(), hMusic);
        if (hMusic < 95 && Prefs.b(this, "showVolume", true)) {
            LinearLayout strip = box(true);
            addTo(strip, buildVolumeCard(), 100);
            add(r, strip, 100 - hMusic);
        }
        return r;
    }

    // ===================================================== home pager (page 2: the 3D car)
    private boolean carPageEnabled() {
        return Prefs.b(this, "showCarPage", true);
    }

    private View wrapPager(View main) {
        if (!carPageEnabled()) {
            homePage = 0;
            return main;
        }
        pager = new HomePager(this);
        pager.setDotColor(pal.text);
        pager.addPage(main);
        carPage = new CarPage(this, pal);
        FrameLayout.LayoutParams cp = new FrameLayout.LayoutParams(-1, -1);
        cp.setMargins(dp(5), dp(5), dp(5), dp(5));
        pager.addPage(carPage);
        carPage.setLayoutParams(cp);
        pager.setGuard(new HomePager.SwipeGuard() {
            @Override
            public boolean blocksSwipe(float rawX, float rawY) {
                if (pager == null || pager.getPage() != 0 || miniMapView == null) return false;
                android.graphics.Rect r = new android.graphics.Rect();
                return miniMapView.getGlobalVisibleRect(r) && r.contains((int) rawX, (int) rawY);
            }
        });
        pager.setListener(new HomePager.Listener() {
            @Override
            public void onPage(int index) {
                homePage = index;
                if (carPage != null) carPage.setActive(index == 1);
                tintCarBtn();
            }
        });
        pager.setPage(homePage, false);
        carPage.setActive(homePage == 1);
        if (hostResumed) carPage.onHostResume();
        updateSpeedUi();
        return pager;
    }

    private void tintCarBtn() {
        if (dockCarBtn == null) return;
        boolean on = homePage == 1;
        Ui.tintIcon(dockCarBtn, Icons.CAR, on ? pal.accent : pal.card, on ? 0xFFFFFFFF : pal.text);
    }

    private View buildCarBody() {
        boolean smap = Prefs.b(this, "showMap", true);
        boolean sm = Prefs.b(this, "showMusic", true);
        int id = layoutId();
        if (!(smap && sm)) return buildCarDefault();
        int wl = pref("wLeft", 50, 30, 70);
        int hMap = pref("hMap", 50, 30, 80);
        int hMusic = pref("hMusic", 100, 50, 100);

        if (!landscape) {
            LinearLayout v = box(true);
            switch (id) {
                case 1:
                    musicFrac = .46f; addTo(v, buildMusicCard(), 46);
                    addTo(v, carMapCard(), 36); addTo(v, carInfoCard(), 18);
                    break;
                case 2:
                    addTo(v, carMapCard(), 52); addTo(v, carInfoCard(), 16);
                    musicFrac = .32f; addTo(v, buildMusicCard(), 32);
                    break;
                case 3:
                    musicFrac = .56f; addTo(v, buildMusicCard(), 56);
                    addTo(v, carInfoCard(), 16); addTo(v, carMapCard(), 28);
                    break;
                case 4:
                    addTo(v, carInfoCard(), 16); addTo(v, carMapCard(), 34);
                    musicFrac = .5f; addTo(v, buildMusicCard(), 50);
                    break;
                case 5:
                    addTo(v, carMapCard(), 50);
                    musicFrac = .5f; addTo(v, buildMusicCard(), 50);
                    break;
                case 6:
                    addTo(v, carMapCard(), 80); addTo(v, carInfoCard(), 20);
                    break;
                default:
                    addTo(v, carMapCard(), 32); addTo(v, carInfoCard(), 18);
                    musicFrac = .5f; addTo(v, buildMusicCard(), 50);
                    break;
            }
            return v;
        }

        LinearLayout root;
        switch (id) {
            case 1: { // Mirror: music left, map + info right
                root = box(false);
                add(root, musicCol(hMusic), 100 - wl);
                LinearLayout r = box(true);
                addTo(r, carMapCard(), hMap);
                addTo(r, carInfoCard(), 100 - hMap);
                add(root, r, wl);
                break;
            }
            case 2: { // Map focus: big map, music + info on the right
                int w2 = Math.min(80, wl + 15);
                root = box(false);
                addTo(root, carMapCard(), w2);
                LinearLayout r = box(true);
                musicFrac = hMap / 100f;
                addTo(r, buildMusicCard(), hMap);
                addTo(r, carInfoCard(), 100 - hMap);
                add(root, r, 100 - w2);
                break;
            }
            case 3: { // Media focus: big music
                int w2 = Math.max(20, wl - 15);
                root = box(false);
                LinearLayout l = box(true);
                addTo(l, carMapCard(), hMap);
                addTo(l, carInfoCard(), 100 - hMap);
                add(root, l, w2);
                add(root, musicCol(hMusic), 100 - w2);
                break;
            }
            case 4: { // Wide dash: map + music on top, full-width info bar below
                int top = Math.max(55, Math.min(85, hMap + 20));
                root = box(true);
                LinearLayout t = box(false);
                addTo(t, carMapCard(), wl);
                musicFrac = top / 100f;
                addTo(t, buildMusicCard(), 100 - wl);
                add(root, t, top);
                addTo(root, carInfoCard(), 100 - top);
                break;
            }
            case 5: { // Duo: map and music only
                root = box(false);
                addTo(root, carMapCard(), wl);
                musicFrac = 1f;
                addTo(root, buildMusicCard(), 100 - wl);
                break;
            }
            case 6: { // Navigator: map + info bar, no music card
                int top = Math.max(60, Math.min(88, hMap + 25));
                root = box(true);
                addTo(root, carMapCard(), top);
                addTo(root, carInfoCard(), 100 - top);
                break;
            }
            default:
                return buildCarDefault();
        }
        return root;
    }

    /** Tiny schematic preview of a layout, drawn with rounded rectangles. */
    private static final class Thumb extends View {
        private final int id;
        private final boolean land;
        private final int cMap, cMusic, cInfo;
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        // {kind(0 map,1 info,2 music), l, t, r, b}
        private static final float[][][] LAND = {
                {{0, 0, 0, .5f, .5f}, {1, 0, .5f, .5f, 1}, {2, .5f, 0, 1, 1}},
                {{2, 0, 0, .5f, 1}, {0, .5f, 0, 1, .5f}, {1, .5f, .5f, 1, 1}},
                {{0, 0, 0, .65f, 1}, {2, .65f, 0, 1, .55f}, {1, .65f, .55f, 1, 1}},
                {{0, 0, 0, .35f, .5f}, {1, 0, .5f, .35f, 1}, {2, .35f, 0, 1, 1}},
                {{0, 0, 0, .5f, .7f}, {2, .5f, 0, 1, .7f}, {1, 0, .7f, 1, 1}},
                {{0, 0, 0, .5f, 1}, {2, .5f, 0, 1, 1}},
                {{0, 0, 0, 1, .75f}, {1, 0, .75f, 1, 1}},
                {{1, 0, 0, .32f, .48f}, {2, .34f, 0, .66f, 1}, {0, .68f, 0, 1, .48f}, {1, 0, .52f, .32f, 1}, {1, .68f, .52f, 1, 1}},
        };
        private static final float[][][] PORT = {
                {{0, 0, 0, 1, .32f}, {1, 0, .32f, 1, .5f}, {2, 0, .5f, 1, 1}},
                {{2, 0, 0, 1, .46f}, {0, 0, .46f, 1, .82f}, {1, 0, .82f, 1, 1}},
                {{0, 0, 0, 1, .52f}, {1, 0, .52f, 1, .68f}, {2, 0, .68f, 1, 1}},
                {{2, 0, 0, 1, .56f}, {1, 0, .56f, 1, .72f}, {0, 0, .72f, 1, 1}},
                {{1, 0, 0, 1, .16f}, {0, 0, .16f, 1, .5f}, {2, 0, .5f, 1, 1}},
                {{0, 0, 0, 1, .5f}, {2, 0, .5f, 1, 1}},
                {{0, 0, 0, 1, .8f}, {1, 0, .8f, 1, 1}},
                {{1, 0, 0, 1, .3f}, {2, 0, .33f, 1, .66f}, {0, 0, .7f, 1, 1}},
        };

        Thumb(Context c, int id, boolean land, int accent, int card) {
            super(c);
            this.id = id;
            this.land = land;
            this.cMap = accent & 0x00FFFFFF | 0xAA000000;
            this.cMusic = 0xCCB05CFF;
            this.cInfo = card | 0xFF000000;
        }

        @Override
        protected void onDraw(Canvas cv) {
            float W = getWidth(), H = getHeight(), g = 3f;
            for (float[] r : (land ? LAND : PORT)[id]) {
                p.setColor(r[0] == 0 ? cMap : r[0] == 2 ? cMusic : 0xFF8A93A8);
                cv.drawRoundRect(new RectF(r[1] * W + g, r[2] * H + g, r[3] * W - g, r[4] * H - g), 8f, 8f, p);
            }
        }
    }

    private void layoutDialog() {
        final AlertDialog.Builder b = new AlertDialog.Builder(this).setTitle("Choose layout");
        ScrollView scroll = new ScrollView(this);
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(10), dp(6), dp(10), dp(6));
        scroll.addView(col);
        b.setView(scroll);
        final AlertDialog dlg = b.create();
        int cur = layoutId();
        LinearLayout row = null;
        for (int i = 0; i < LAYOUT_NAMES.length; i++) {
            if (i % 2 == 0) {
                row = new LinearLayout(this);
                col.addView(row, new LinearLayout.LayoutParams(-1, -2));
            }
            final int idx = i;
            LinearLayout tile = new LinearLayout(this);
            tile.setOrientation(LinearLayout.VERTICAL);
            tile.setGravity(Gravity.CENTER);
            tile.setPadding(dp(8), dp(8), dp(8), dp(8));
            android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
            g.setColor(0x22888888);
            g.setCornerRadius(dp(14));
            if (i == cur) g.setStroke(dp(3), pal.accent);
            else g.setStroke(dp(1), 0x33888888);
            tile.setBackground(g);
            tile.addView(new Thumb(this, i, landscape, pal.accent, pal.card & 0x00FFFFFF),
                    new LinearLayout.LayoutParams(-1, dp(landscape ? 70 : 110)));
            TextView n = Ui.text(this, LAYOUT_NAMES[i], 14, 0xFF888888);
            n.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams nl = new LinearLayout.LayoutParams(-2, -2);
            nl.topMargin = dp(6);
            tile.addView(n, nl);
            tile.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    Prefs.putI(MainActivity.this, "layoutId", idx);
                    dlg.dismiss();
                    applyLayoutChange();
                }
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
            lp.setMargins(dp(5), dp(5), dp(5), dp(5));
            row.addView(tile, lp);
        }
        dlg.show();
    }

    // ------------------------------------------------------ widget sizing
    private View sizeRow(LinearLayout parent, String label, final String key, final int def, final int lo, final int hi) {
        TextView t = Ui.text(this, label, 14, 0xFF888888);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-2, -2);
        tl.topMargin = dp(12);
        parent.addView(t, tl);
        SeekBar sb = new SeekBar(this);
        sb.setMax(hi - lo);
        sb.setProgress(pref(key, def, lo, hi) - lo);
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean u) {
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                Prefs.putI(MainActivity.this, key, s.getProgress() + lo);
                applyLayoutChange();
            }
        });
        parent.addView(sb, new LinearLayout.LayoutParams(-1, -2));
        return sb;
    }

    private void applyLayoutChange() {
        rebuild();
        lastSig = Prefs.p(this).getAll().toString();
    }

    private void resizeDialog() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(22), dp(8), dp(22), dp(4));
        TextView lb = Ui.button(this, "Change layout\u2026", 15, pal.accent, 0xFFFFFFFF);
        lb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                layoutDialog();
            }
        });
        col.addView(lb, new LinearLayout.LayoutParams(-1, -2));
        if (landscape) sizeRow(col, "Left / right width", "wLeft", 50, 30, 70);
        sizeRow(col, "Map height (vs. search & weather)", "hMap", 50, 30, 80);
        if (landscape) sizeRow(col, "Music height (rest shows volume)", "hMusic", 100, 50, 100);
        sizeRow(col, "Dock icon size", "dockIcon", 54, 36, 76);
        new AlertDialog.Builder(this)
                .setTitle("Widget sizes")
                .setView(col)
                .setPositiveButton("Done", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                    }
                })
                .setNeutralButton("Reset", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        Prefs.p(MainActivity.this).edit().remove("wLeft").remove("hMap").remove("hMusic")
                                .remove("dockIcon").remove("carLayout").remove("layoutId").apply();
                        applyLayoutChange();
                    }
                })
                .show();
    }

    // ---------------------------------------------------------- clock card
    private View buildClockCard() {
        LinearLayout c = card(null);
        TextClock clock = new TextClock(this);
        String fmt = Prefs.b(this, "h24", true) ? "HH:mm" : "h:mm a";
        clock.setFormat24Hour(fmt);
        clock.setFormat12Hour(fmt);
        clock.setTextSize(landscape ? 72 : 64);
        clock.setTextColor(pal.text);
        clock.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        clock.setGravity(Gravity.CENTER);
        c.addView(clock, new LinearLayout.LayoutParams(-2, -2));
        TextClock date = new TextClock(this);
        date.setFormat24Hour("EEEE, d MMMM");
        date.setFormat12Hour("EEEE, d MMMM");
        date.setTextSize(18);
        date.setTextColor(pal.sub);
        date.setGravity(Gravity.CENTER);
        c.addView(date, new LinearLayout.LayoutParams(-2, -2));
        return c;
    }

    // -------------------------------------------------------- weather card
    private View buildWeatherCard() {
        final LinearLayout c = card("Weather");
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER);
        tvWxIcon = Ui.text(this, "\u2026", 40, pal.text);
        tvWxTemp = Ui.text(this, "--\u00B0", 40, pal.text);
        tvWxTemp.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        top.addView(tvWxIcon);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-2, -2);
        tl.leftMargin = dp(10);
        top.addView(tvWxTemp, tl);
        c.addView(top, new LinearLayout.LayoutParams(-2, -2));

        tvWxDesc = Ui.text(this, "Loading weather\u2026", 16, pal.text);
        tvWxDesc.setGravity(Gravity.CENTER);
        c.addView(tvWxDesc, new LinearLayout.LayoutParams(-2, -2));
        tvWxExtra = Ui.text(this, "", 13, pal.sub);
        tvWxExtra.setGravity(Gravity.CENTER);
        c.addView(tvWxExtra, new LinearLayout.LayoutParams(-2, -2));

        wxForecast = new LinearLayout(this);
        wxForecast.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams fl = new LinearLayout.LayoutParams(-2, -2);
        fl.topMargin = dp(8);
        c.addView(wxForecast, fl);

        tvWxPlace = Ui.text(this, "", 12, pal.sub);
        tvWxPlace.setGravity(Gravity.CENTER);
        c.addView(tvWxPlace, new LinearLayout.LayoutParams(-2, -2));

        c.setClickable(true);
        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                refreshWeather(true);
                Toast.makeText(MainActivity.this, "Refreshing weather\u2026", Toast.LENGTH_SHORT).show();
            }
        });
        return c;
    }

    // ---------------------------------------------------------- music card
    private View buildMusicCard() {
        LinearLayout c = card(carLayout() ? null : "Now playing");
        {
            android.graphics.drawable.GradientDrawable mg = new android.graphics.drawable.GradientDrawable(
                    android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
                    new int[]{pal.accent & 0x00FFFFFF | 0x66000000, pal.card & 0x00FFFFFF | 0x33000000, pal.accent & 0x00FFFFFF | 0x33000000});
            mg.setCornerRadius(dp(28));
            mg.setStroke(dp(1), pal.dark ? 0x40FFFFFF : 0x22000000);
            c.setBackground(mg);
            musicCard = c;
            musicDefaultBg = mg;
            bgSource = null;
        }

        musicNotice = new LinearLayout(this);
        musicNotice.setOrientation(LinearLayout.VERTICAL);
        musicNotice.setGravity(Gravity.CENTER);
        TextView msg = Ui.text(this, "Allow notification access so Mika can show what's playing.", 14, pal.sub);
        msg.setGravity(Gravity.CENTER);
        musicNotice.addView(msg, new LinearLayout.LayoutParams(-2, -2));
        TextView en = Ui.button(this, "Enable", 15, pal.accent, 0xFFFFFFFF);
        en.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openNotificationAccess();
            }
        });
        LinearLayout.LayoutParams el = new LinearLayout.LayoutParams(-2, -2);
        el.topMargin = dp(10);
        musicNotice.addView(en, el);
        TextView lib = Ui.button(this, "Play music from this device", 15, pal.card, pal.text);
        lib.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, LibraryActivity.class));
            }
        });
        LinearLayout.LayoutParams ll2 = new LinearLayout.LayoutParams(-2, -2);
        ll2.topMargin = dp(8);
        musicNotice.addView(lib, ll2);
        c.addView(musicNotice, new LinearLayout.LayoutParams(-1, -2));

        musicBody = new LinearLayout(this);
        musicBody.setOrientation(LinearLayout.VERTICAL);
        musicBody.setGravity(Gravity.CENTER);

        ivArt = new ImageView(this);
        ivArt.setScaleType(ImageView.ScaleType.CENTER_CROP);
        ivArt.setBackground(Ui.pill(this, pal.card, 22));
        ivArt.setClipToOutline(true);
        LinearLayout.LayoutParams al = new LinearLayout.LayoutParams(dp(artDp()), dp(artDp()));
        musicBody.addView(ivArt, al);
        if (artDp() == 0) ivArt.setVisibility(View.GONE);

        tvTitle = Ui.text(this, "Nothing playing", 19, pal.text);
        tvTitle.setTypeface(Typeface.DEFAULT_BOLD);
        tvTitle.setSingleLine(true);
        tvTitle.setEllipsize(TextUtils.TruncateAt.MARQUEE);
        tvTitle.setSelected(true);
        tvTitle.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-1, -2);
        tl.topMargin = dp(10);
        musicBody.addView(tvTitle, tl);

        tvArtist = Ui.text(this, "", 15, pal.sub);
        tvArtist.setSingleLine(true);
        tvArtist.setEllipsize(TextUtils.TruncateAt.END);
        tvArtist.setGravity(Gravity.CENTER);
        musicBody.addView(tvArtist, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout prog = new LinearLayout(this);
        prog.setGravity(Gravity.CENTER_VERTICAL);
        tvPos = Ui.text(this, "0:00", 11, pal.sub);
        tvDur = Ui.text(this, "0:00", 11, pal.sub);
        mediaProgress = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        mediaProgress.setMax(1000);
        mediaProgress.setProgressTintList(ColorStateList.valueOf(pal.accent));
        mediaProgress.setProgressBackgroundTintList(ColorStateList.valueOf(pal.card));
        prog.addView(tvPos);
        LinearLayout.LayoutParams pl = new LinearLayout.LayoutParams(0, dp(10), 1f);
        pl.leftMargin = dp(8);
        pl.rightMargin = dp(8);
        prog.addView(mediaProgress, pl);
        prog.addView(tvDur);
        LinearLayout.LayoutParams ppl = new LinearLayout.LayoutParams(-1, -2);
        ppl.topMargin = dp(8);
        musicBody.addView(prog, ppl);

        LinearLayout ctrl = new LinearLayout(this);
        ctrl.setGravity(Gravity.CENTER);
        ctrl.addView(ctrlBtn(Icons.PREV, 52, 24, false, 0));
        View playBtn = ctrlBtn(Icons.PLAY, 66, 32, true, 1);
        btnPlay = (android.widget.ImageView) playBtn.getTag();
        ctrl.addView(playBtn);
        ctrl.addView(ctrlBtn(Icons.NEXT, 52, 24, false, 2));
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-2, -2);
        cl.topMargin = dp(8);
        musicBody.addView(ctrl, cl);

        c.addView(musicBody, new LinearLayout.LayoutParams(-1, -2));
        c.setClickable(true);
        c.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (useOwn() || (media.controller != null && media.title.length() > 0)) {
                    startActivity(new Intent(MainActivity.this, PlayerActivity.class));
                } else {
                    startActivity(new Intent(MainActivity.this, LibraryActivity.class));
                }
            }
        });
        return c;
    }

    private View ctrlBtn(int icon, int sizeDp, int iconDp, boolean primary, final int action) {
        View t = Ui.iconButton(this, icon, sizeDp, iconDp, primary ? pal.accent : pal.card, primary ? 0xFFFFFFFF : pal.text);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp));
        lp.leftMargin = dp(8);
        lp.rightMargin = dp(8);
        t.setLayoutParams(lp);
        t.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (useOwn()) {
                    PlayerService.send(MainActivity.this, action == 0 ? PlayerService.ACTION_PREV
                            : action == 1 ? PlayerService.ACTION_TOGGLE : PlayerService.ACTION_NEXT);
                } else if (action == 0) media.prev();
                else if (action == 1) media.playPause();
                else media.next();
            }
        });
        return t;
    }

    // ----------------------------------------------------------- map card
    private View buildMapCard() {
        LinearLayout c = card(null);
        c.setPadding(dp(10), dp(10), dp(10), dp(10));
        c.setGravity(Gravity.NO_GRAVITY);

        newMiniMap();
        miniMap.setZoom(14f);
        miniMapView.setClipToOutline(true);
        miniMapView.setBackground(Ui.pill(this, pal.card, 22));
        try {
            miniMap.setCenter(Double.parseDouble(Prefs.s(this, "mapLat", "48.8566")),
                    Double.parseDouble(Prefs.s(this, "mapLon", "2.3522")));
        } catch (Exception ignored) {
        }
        miniMapView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openMaps(null);
            }
        });
        c.addView(miniMapView, new LinearLayout.LayoutParams(-1, dp(landscape ? 130 : 190)));
        LinearLayout.LayoutParams hnl = new LinearLayout.LayoutParams(-1, -2);
        hnl.topMargin = dp(8);
        c.addView(buildHomeNavStrip(), hnl);

        // search / destination bar -> Google Maps navigation
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackground(Ui.pill(this, pal.card, 26));
        bar.setPadding(dp(14), dp(10), dp(14), dp(10));
        bar.addView(Icons.view(this, Icons.SEARCH, 20, pal.sub));
        TextView hint = Ui.text(this, "Where to?", 15, pal.sub);
        LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(0, -2, 1f);
        hl.leftMargin = dp(10);
        bar.addView(hint, hl);
        bar.addView(Icons.view(this, Icons.NAV, 20, pal.accent));
        bar.setClickable(true);
        bar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                askDestination();
            }
        });
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-1, -2);
        bl.topMargin = dp(10);
        c.addView(bar, bl);

        // Home / Work shortcuts (long-press to set the address)
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        row.addView(placeChip(Icons.HOME, "Home", "homeAddr"), new LinearLayout.LayoutParams(0, -2, 1f));
        row.addView(placeChip(Icons.WORK, "Work", "workAddr"), new LinearLayout.LayoutParams(0, -2, 1f));
        LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(-1, -2);
        rl.topMargin = dp(8);
        c.addView(row, rl);
        return c;
    }

    private View placeChip(int icon, final String label, final String key) {
        LinearLayout l = new LinearLayout(this);
        l.setGravity(Gravity.CENTER);
        l.setPadding(dp(8), dp(10), dp(8), dp(10));
        l.addView(Icons.view(this, icon, 20, pal.accent));
        TextView t = Ui.text(this, label, 15, pal.text);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.leftMargin = dp(8);
        l.addView(t, lp);
        l.setClickable(true);
        l.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String addr = Prefs.s(MainActivity.this, key, "");
                if (addr.length() == 0) editPlace(label, key);
                else openMaps(addr);
            }
        });
        l.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                editPlace(label, key);
                return true;
            }
        });
        return l;
    }

    private void editPlace(final String label, final String key) {
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setText(Prefs.s(this, key, ""));
        et.setHint("Address");
        new AlertDialog.Builder(this)
                .setTitle(label + " address")
                .setView(et)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        Prefs.putS(MainActivity.this, key, et.getText().toString().trim());
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void askDestination() {
        final EditText et = new EditText(this);
        et.setSingleLine(true);
        et.setHint("Address or place");
        new AlertDialog.Builder(this)
                .setTitle("Where to?")
                .setView(et)
                .setPositiveButton("Go", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        openMaps(et.getText().toString().trim());
                    }
                })
                .setNeutralButton("Open map", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        openMaps(null);
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void statusIcon(TextView tv, int icon) {
        android.graphics.drawable.Drawable d = Icons.get(icon, pal.sub);
        int px = dp(16);
        d.setBounds(0, 0, px, px);
        tv.setCompoundDrawables(d, null, null, null);
        tv.setGravity(Gravity.CENTER_VERTICAL);
    }

    private LinearLayout pillWithIcon(int icon, String label, int bg, int fg) {
        LinearLayout l = new LinearLayout(this);
        l.setGravity(Gravity.CENTER);
        l.setBackground(Ui.pill(this, bg, 26));
        l.setPadding(dp(18), dp(12), dp(20), dp(12));
        l.setClickable(true);
        l.addView(Icons.view(this, icon, 22, fg));
        TextView t = Ui.text(this, label, 17, fg);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.leftMargin = dp(8);
        l.addView(t, lp);
        return l;
    }

    /** Opens Google Maps (navigation if a destination is given), falling back to any maps app, then to the built-in map. */
    private Intent mapsIntent(String destination) {
        if (!Prefs.b(this, "extMaps", false)) {
            Intent m = new Intent(this, MapActivity.class);
            if (destination != null && destination.length() > 0) {
                m.putExtra("q", destination);
                m.putExtra("go", true);
            }
            return m;
        }
        Intent i;
        if (destination != null && destination.length() > 0) {
            i = new Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(destination)));
        } else {
            Location l = bestLastLocation();
            String geo = l != null ? "geo:" + l.getLatitude() + "," + l.getLongitude() + "?z=15" : "geo:0,0?z=3";
            i = new Intent(Intent.ACTION_VIEW, Uri.parse(geo));
        }
        i.setPackage("com.google.android.apps.maps");
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        if (i.resolveActivity(getPackageManager()) == null) {
            i.setPackage(null);
            if (i.resolveActivity(getPackageManager()) == null) {
                i = new Intent(this, MapActivity.class);
            }
        }
        return i;
    }

    private void openMaps(String destination) {
        try {
            startActivity(mapsIntent(destination));
        } catch (Exception e) {
            startActivity(new Intent(this, MapActivity.class));
        }
    }

    private Location bestLastLocation() {
        if (!hasLocationPermission()) return null;
        try {
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            Location best = null;
            for (String p : lm.getProviders(true)) {
                Location l = lm.getLastKnownLocation(p);
                if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
            }
            return best;
        } catch (SecurityException e) {
            return null;
        }
    }

    /** Compact "drive to" strip shown on the home map while a route is active. */
    private LinearLayout buildHomeNavStrip() {
        LinearLayout n = new LinearLayout(this);
        n.setGravity(Gravity.CENTER_VERTICAL);
        n.setBackground(Ui.pill(this, pal.panel, 22));
        n.setPadding(dp(12), dp(8), dp(8), dp(8));
        hnArrow = Ui.text(this, "\u2191", 28, pal.accent);
        hnArrow.setTypeface(Typeface.DEFAULT_BOLD);
        n.addView(hnArrow, new LinearLayout.LayoutParams(dp(38), -2));
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        hnDist = Ui.text(this, "", 17, pal.text);
        hnDist.setTypeface(Typeface.DEFAULT_BOLD);
        hnDist.setSingleLine(true);
        hnText = Ui.text(this, "", 12, pal.sub);
        hnText.setSingleLine(true);
        hnText.setEllipsize(TextUtils.TruncateAt.END);
        col.addView(hnDist);
        col.addView(hnText);
        n.addView(col, new LinearLayout.LayoutParams(0, -2, 1f));
        hnEta = Ui.text(this, "", 13, pal.text);
        hnEta.setTypeface(Typeface.DEFAULT_BOLD);
        hnEta.setGravity(Gravity.RIGHT);
        LinearLayout.LayoutParams el = new LinearLayout.LayoutParams(-2, -2);
        el.leftMargin = dp(8);
        el.rightMargin = dp(6);
        n.addView(hnEta, el);
        View x = Ui.iconButton(this, Icons.CLOSE, 38, 18, pal.card, pal.text);
        x.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                NavState.stop();
                updateHomeNav();
            }
        });
        n.addView(x);
        n.setClickable(true);
        n.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, MapActivity.class));
            }
        });
        n.setVisibility(View.GONE);
        homeNav = n;
        return n;
    }

    /** Shows / refreshes the active drive on the home map: route line, next turn, distance and ETA. */
    private void updateHomeNav() {
        if (homeNav == null || miniMap == null) return;
        if (!NavState.active || NavState.pts == null) {
            if (homeNav.getVisibility() != View.GONE) homeNav.setVisibility(View.GONE);
            if (homeRouteShown != null) {
                miniMap.clearRoute();
                homeRouteShown = null;
            }
            homeNavZoomed = false;
            return;
        }
        Location l = speedProvider != null && speedProvider.fresh() && speedProvider.last != null
                ? speedProvider.last : bestLastLocation();
        if (l != null) {
            if (NavState.update(l)) {
                Toast.makeText(this, "You have arrived", Toast.LENGTH_LONG).show();
                NavState.stop();
                updateHomeNav();
                return;
            }
            if (NavState.shouldReroute()) {
                NavState.fetch(getApplicationContext(), l.getLatitude(), l.getLongitude(), NavState.destLat, NavState.destLon,
                        NavState.destName, true, new Runnable() {
                            @Override
                            public void run() {
                                updateHomeNav();
                            }
                        }, null);
            }
            miniMap.setMe(l);
            miniMap.followTo(l.getLatitude(), l.getLongitude(), 0f, false);
        }
        if (homeRouteShown != NavState.pts) {
            miniMap.setRoute(NavState.pts);
            homeRouteShown = NavState.pts;
        }
        if (!homeNavZoomed) {
            mapZoom = 15f;
            miniMap.setZoom(15f);
            homeNavZoomed = true;
        }
        hnArrow.setText(NavState.nextArrow);
        hnDist.setText(NavState.fmtDist(this, NavState.nextDist));
        hnText.setText(NavState.nextText);
        hnEta.setText(NavState.fmtTime(NavState.eta) + "\n" + NavState.fmtDist(this, NavState.remaining));
        homeNav.setVisibility(View.VISIBLE);
    }

    /** Home-screen map: the same vector (Mapbox-style) map as the Map screen; classic raster only as a fallback. */
    private void newMiniMap() {
        if (miniMap instanceof VectorMapView) ((VectorMapView) miniMap).destroy();
        if (Prefs.i(this, "mapEngine", 0) == 0 && !homeRaster) {
            VectorMapView v = new VectorMapView(this);
            v.setEvents(new VectorMapView.Events() {
                @Override
                public void onFail(String reason) {
                    homeRaster = true; // no WebGL / offline: use the classic map from now on
                    handler.post(new Runnable() {
                        @Override
                        public void run() {
                            rebuild();
                        }
                    });
                }

                @Override
                public void onPoi(String name, double lat, double lon) {
                }
            });
            miniMap = v;
        } else {
            miniMap = new MapView(this);
        }
        miniMapView = (View) miniMap;
        miniMap.setInteractive(false);
        miniMap.setNight(pal.dark);
        miniMap.setAccent(pal.accent);
    }

    private void updateMiniMap() {
        if (miniMap == null) return;
        Location l = bestLastLocation();
        if (l != null) {
            miniMap.setMe(l);
            miniMap.followTo(l.getLatitude(), l.getLongitude(), 0f, false);
        }
        updateHomeNav();
    }

    // ------------------------------------------------------- frequent card
    private View buildFrequentCard() {
        LinearLayout c = card("Frequent apps");
        frequentRow = new LinearLayout(this);
        frequentRow.setGravity(Gravity.CENTER);
        c.addView(frequentRow, new LinearLayout.LayoutParams(-2, -2));
        return c;
    }

    // --------------------------------------------------------- speed card
    private View buildSpeedCard() {
        LinearLayout c = card("Speed");
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER | Gravity.BOTTOM);
        tvSpeed = Ui.text(this, "--", 52, pal.text);
        tvSpeed.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL));
        tvSpeedUnit = Ui.text(this, "km/h", 16, pal.sub);
        row.addView(tvSpeed);
        LinearLayout.LayoutParams ul = new LinearLayout.LayoutParams(-2, -2);
        ul.leftMargin = dp(8);
        ul.bottomMargin = dp(10);
        row.addView(tvSpeedUnit, ul);
        c.addView(row, new LinearLayout.LayoutParams(-2, -2));
        tvHeading = Ui.text(this, "", 15, pal.accent);
        tvHeading.setTypeface(Typeface.DEFAULT_BOLD);
        c.addView(tvHeading, new LinearLayout.LayoutParams(-2, -2));
        tvGps = Ui.text(this, "", 12, pal.sub);
        tvGps.setGravity(Gravity.CENTER);
        c.addView(tvGps, new LinearLayout.LayoutParams(-2, -2));
        return c;
    }

    // -------------------------------------------------------- volume card
    private View buildVolumeCard() {
        LinearLayout c = card("Volume");
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER_VERTICAL);
        View mute = Ui.iconButton(this, Icons.VOLUME, 44, 22, pal.card, pal.text);
        volMute = mute;
        mute.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int cur = audio.getStreamVolume(AudioManager.STREAM_MUSIC);
                if (cur > 0) {
                    lastVolBeforeMute = cur;
                    audio.setStreamVolume(AudioManager.STREAM_MUSIC, 0, 0);
                } else {
                    audio.setStreamVolume(AudioManager.STREAM_MUSIC, Math.max(1, lastVolBeforeMute), 0);
                }
                syncVolume();
            }
        });
        row.addView(mute);
        View down = Ui.iconButton(this, Icons.VOL_DOWN, 44, 22, pal.card, pal.text);
        down.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_LOWER, 0);
                syncVolume();
            }
        });
        LinearLayout.LayoutParams dnl = new LinearLayout.LayoutParams(-2, -2);
        dnl.leftMargin = dp(8);
        row.addView(down, dnl);
        volBar = new SeekBar(this);
        volBar.setMax(audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC));
        volBar.setProgressTintList(ColorStateList.valueOf(pal.accent));
        volBar.setThumbTintList(ColorStateList.valueOf(pal.accent));
        volBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (fromUser) audio.setStreamVolume(AudioManager.STREAM_MUSIC, p, 0);
            }

            @Override
            public void onStartTrackingTouch(SeekBar s) {
                volTouching = true;
            }

            @Override
            public void onStopTrackingTouch(SeekBar s) {
                volTouching = false;
            }
        });
        LinearLayout.LayoutParams vl = new LinearLayout.LayoutParams(0, -2, 1f);
        vl.leftMargin = dp(8);
        row.addView(volBar, vl);
        View up = Ui.iconButton(this, Icons.VOL_UP, 44, 22, pal.accent, 0xFFFFFFFF);
        up.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC, AudioManager.ADJUST_RAISE, 0);
                syncVolume();
            }
        });
        LinearLayout.LayoutParams upl = new LinearLayout.LayoutParams(-2, -2);
        upl.leftMargin = dp(8);
        row.addView(up, upl);
        c.addView(row, new LinearLayout.LayoutParams(-1, -2));
        return c;
    }

    // ------------------------------------------------------- quick actions
    private View buildQuickCard() {
        LinearLayout c = card("Quick actions");
        LinearLayout row = new LinearLayout(this);
        row.setGravity(Gravity.CENTER);
        row.addView(quick(Icons.MAP, "Maps", 0));
        row.addView(quick(Icons.PHONE, "Phone", 1));
        row.addView(quick(Icons.WIFI, "Wi-Fi", 2));
        row.addView(quick(Icons.BT, "Bluetooth", 3));
        c.addView(row, new LinearLayout.LayoutParams(-2, -2));
        return c;
    }

    private View quick(int icon, String label, final int which) {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setGravity(Gravity.CENTER);
        col.setPadding(dp(8), dp(4), dp(8), dp(4));
        View g = Ui.iconButton(this, icon, 52, 24, pal.accent & 0x00FFFFFF | 0x33000000, pal.accent);
        col.addView(g, new LinearLayout.LayoutParams(dp(52), dp(52)));
        TextView l = Ui.text(this, label, 11, pal.sub);
        l.setGravity(Gravity.CENTER);
        col.addView(l);
        col.setClickable(true);
        col.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    Intent i;
                    if (which == 0) i = mapsIntent(null);
                    else if (which == 1) i = new Intent(Intent.ACTION_DIAL);
                    else if (which == 2) i = new Intent(Settings.ACTION_WIFI_SETTINGS);
                    else i = new Intent(Settings.ACTION_BLUETOOTH_SETTINGS);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "No app available for this action", Toast.LENGTH_SHORT).show();
                }
            }
        });
        return col;
    }

    // ------------------------------------------------------------ bottom bar
    private View buildBottomBar() {
        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(0, dp(8), 0, 0);

        dockView = new LinearLayout(this);
        dockView.setGravity(Gravity.CENTER);
        dockView.setPadding(dp(10), dp(6), dp(10), dp(6));
        dockView.setBackground(Ui.glass(this, pal.card, pal.dark ? 0x2EFFFFFF : 0x1F000000, 32));
        LinearLayout.LayoutParams dl = new LinearLayout.LayoutParams(0, -2, 1f);
        bar.addView(dockView, dl);

        LinearLayout media2 = pillWithIcon(Icons.MUSIC, "Media", pal.card, pal.text);
        media2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this, LibraryActivity.class));
            }
        });
        LinearLayout.LayoutParams ml = new LinearLayout.LayoutParams(-2, -2);
        ml.leftMargin = dp(12);
        bar.addView(media2, ml);

        LinearLayout all = pillWithIcon(Icons.APPS, "Apps", pal.accent, 0xFFFFFFFF);
        all.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                openDrawer();
            }
        });
        LinearLayout.LayoutParams al = new LinearLayout.LayoutParams(-2, -2);
        al.leftMargin = dp(12);
        bar.addView(all, al);
        return bar;
    }

    // ================================================================ drawer
    private LinearLayout buildDrawer() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(20), dp(20), dp(12), dp(12));
        col.setBackgroundColor(pal.panel);

        LinearLayout bar = new LinearLayout(this);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        search = new EditText(this);
        search.setHint("Search apps");
        search.setSingleLine(true);
        search.setTextColor(pal.text);
        search.setHintTextColor(pal.sub);
        search.setTextSize(18);
        search.setBackground(Ui.pill(this, pal.card, 18));
        search.setPadding(dp(18), dp(10), dp(18), dp(10));
        search.addTextChangedListener(new TextWatcher() {
            public void beforeTextChanged(CharSequence s, int a, int b, int c) {
            }

            public void onTextChanged(CharSequence s, int a, int b, int c) {
            }

            public void afterTextChanged(Editable e) {
                refreshShown(e.toString());
            }
        });
        bar.addView(search, new LinearLayout.LayoutParams(0, -2, 1f));
        View close = Ui.iconButton(this, Icons.CLOSE, 44, 20, pal.card, pal.text);
        close.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                closeDrawer();
            }
        });
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-2, -2);
        cl.leftMargin = dp(12);
        cl.rightMargin = dp(8);
        bar.addView(close, cl);
        col.addView(bar, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout body = new LinearLayout(this);
        grid = new GridView(this);
        grid.setNumColumns(Prefs.i(this, "cols", landscape ? 6 : 4));
        grid.setVerticalSpacing(dp(10));
        grid.setHorizontalSpacing(dp(6));
        grid.setSelector(new ColorDrawable(Color.TRANSPARENT));
        grid.setClipToPadding(false);
        grid.setPadding(0, dp(14), 0, 0);
        grid.setVerticalScrollBarEnabled(false);
        adapter = new AppAdapter();
        grid.setAdapter(adapter);
        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> p, View v, int pos, long id) {
                launch(shown.get(pos));
            }
        });
        grid.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> p, View v, int pos, long id) {
                showAppMenu(shown.get(pos));
                return true;
            }
        });
        body.addView(grid, new LinearLayout.LayoutParams(0, -1, 1f));
        if (Prefs.i(this, "sort", 0) == 0) body.addView(buildIndex(), new LinearLayout.LayoutParams(dp(26), -1));
        col.addView(body, new LinearLayout.LayoutParams(-1, 0, 1f));
        return col;
    }

    private View buildIndex() {
        final String letters = "#ABCDEFGHIJKLMNOPQRSTUVWXYZ";
        final LinearLayout idx = new LinearLayout(this);
        idx.setOrientation(LinearLayout.VERTICAL);
        idx.setGravity(Gravity.CENTER);
        for (int i = 0; i < letters.length(); i++) {
            TextView t = Ui.text(this, String.valueOf(letters.charAt(i)), 11, pal.accent);
            t.setGravity(Gravity.CENTER);
            idx.addView(t, new LinearLayout.LayoutParams(-1, 0, 1f));
        }
        idx.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent e) {
                float frac = e.getY() / Math.max(1, v.getHeight());
                int i = (int) (frac * letters.length());
                if (i < 0) i = 0;
                if (i >= letters.length()) i = letters.length() - 1;
                char target = letters.charAt(i);
                for (int k = 0; k < shown.size(); k++) {
                    char ch = Character.toUpperCase(shown.get(k).label.length() > 0 ? shown.get(k).label.charAt(0) : '#');
                    if (!(ch >= 'A' && ch <= 'Z')) ch = '#';
                    if (ch >= target) {
                        grid.setSelection(k);
                        break;
                    }
                }
                return true;
            }
        });
        return idx;
    }

    private void openDrawer() {
        drawerOpen = true;
        drawerView.setVisibility(View.VISIBLE);
        drawerView.setAlpha(0f);
        drawerView.animate().alpha(1f).setDuration(160).start();
    }

    private void closeDrawer() {
        drawerOpen = false;
        if (search != null) search.setText("");
        if (drawerView != null) drawerView.setVisibility(View.GONE);
        if (grid != null) grid.setSelection(0);
    }

    // ================================================================== apps
    private void loadApps() {
        final PackageManager pm = getPackageManager();
        new Thread(new Runnable() {
            @Override
            public void run() {
                Intent main = new Intent(Intent.ACTION_MAIN, null);
                main.addCategory(Intent.CATEGORY_LAUNCHER);
                List<ResolveInfo> list = pm.queryIntentActivities(main, 0);
                final List<AppEntry> out = new ArrayList<AppEntry>();
                for (ResolveInfo ri : list) {
                    if (ri.activityInfo.packageName.equals(getPackageName())) continue;
                    AppEntry e = new AppEntry();
                    e.label = String.valueOf(ri.loadLabel(pm));
                    e.pkg = ri.activityInfo.packageName;
                    e.cls = ri.activityInfo.name;
                    e.icon = ri.loadIcon(pm);
                    try {
                        e.installTime = pm.getPackageInfo(e.pkg, 0).firstInstallTime;
                    } catch (Exception ex) {
                        e.installTime = 0;
                    }
                    out.add(e);
                }
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        allApps.clear();
                        allApps.addAll(out);
                        refreshShown(search == null ? "" : search.getText().toString());
                        refreshDock();
                        refreshFrequent();
                    }
                });
            }
        }).start();
    }

    private int countOf(AppEntry e) {
        return Prefs.counts(this).getInt(e.key(), 0);
    }

    private void refreshShown(String q) {
        shown.clear();
        List<String> hidden = Prefs.list(this, "hidden");
        String needle = q.trim().toLowerCase(Locale.getDefault());
        for (AppEntry e : allApps) {
            if (hidden.contains(e.key())) continue;
            if (needle.length() == 0 || e.label.toLowerCase(Locale.getDefault()).contains(needle)) shown.add(e);
        }
        final int sort = Prefs.i(this, "sort", 0);
        Collections.sort(shown, new Comparator<AppEntry>() {
            @Override
            public int compare(AppEntry a, AppEntry b) {
                if (sort == 1) {
                    int d = countOf(b) - countOf(a);
                    if (d != 0) return d;
                } else if (sort == 2) {
                    if (a.installTime != b.installTime) return a.installTime < b.installTime ? 1 : -1;
                }
                return a.label.compareToIgnoreCase(b.label);
            }
        });
        if (adapter != null) adapter.notifyDataSetChanged();
    }

    private void launch(AppEntry e) {
        try {
            Intent i = new Intent(Intent.ACTION_MAIN);
            i.addCategory(Intent.CATEGORY_LAUNCHER);
            i.setComponent(new ComponentName(e.pkg, e.cls));
            i.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            startActivity(i);
            Prefs.counts(this).edit().putInt(e.key(), countOf(e) + 1).apply();
            if (drawerOpen) closeDrawer();
            refreshFrequent();
        } catch (Exception ex) {
            Toast.makeText(this, "Can't open " + e.label, Toast.LENGTH_SHORT).show();
        }
    }

    private void showAppMenu(final AppEntry e) {
        final boolean pinned = Prefs.list(this, "dock").contains(e.key());
        String[] items = {pinned ? "Unpin from dock" : "Pin to dock", "Hide app", "App info", "Uninstall"};
        new AlertDialog.Builder(this).setTitle(e.label)
                .setItems(items, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        if (which == 0) {
                            togglePin(e);
                        } else if (which == 1) {
                            List<String> h = Prefs.list(MainActivity.this, "hidden");
                            h.add(e.key());
                            Prefs.saveList(MainActivity.this, "hidden", h);
                            refreshShown(search.getText().toString());
                            Toast.makeText(MainActivity.this,
                                    "Hidden. Restore it in Settings \u203A Hidden apps", Toast.LENGTH_LONG).show();
                        } else if (which == 2) {
                            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                    Uri.parse("package:" + e.pkg));
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            startActivity(i);
                        } else {
                            Intent i = new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + e.pkg));
                            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                            try {
                                startActivity(i);
                            } catch (Exception ex) {
                                Toast.makeText(MainActivity.this, "Can't uninstall this app",
                                        Toast.LENGTH_SHORT).show();
                            }
                        }
                    }
                }).show();
    }

    private void togglePin(AppEntry e) {
        List<String> keys = Prefs.list(this, "dock");
        if (keys.contains(e.key())) {
            keys.remove(e.key());
        } else {
            if (keys.size() >= MAX_DOCK) {
                Toast.makeText(this, "Dock is full (" + MAX_DOCK + ")", Toast.LENGTH_SHORT).show();
                return;
            }
            keys.add(e.key());
        }
        Prefs.saveList(this, "dock", keys);
        refreshDock();
    }

    private AppEntry find(String key) {
        for (AppEntry e : allApps) if (e.key().equals(key)) return e;
        return null;
    }

    private void refreshDock() {
        if (dockView == null) return;
        dockView.removeAllViews();
        int added = 0;
        for (String k : Prefs.list(this, "dock")) {
            AppEntry e = find(k);
            if (e == null) continue;
            dockView.addView(iconCell(e, carLayout() ? Prefs.i(this, "dockIcon", 54) : 54, false, true));
            added++;
        }
        if (added == 0) {
            TextView hint = Ui.text(this, "Long-press an app in Apps to pin it here", 14, pal.sub);
            hint.setPadding(dp(10), dp(14), dp(10), dp(14));
            dockView.addView(hint);
        }
    }

    private void refreshFrequent() {
        if (frequentRow == null) return;
        frequentRow.removeAllViews();
        List<AppEntry> list = new ArrayList<AppEntry>();
        List<String> hidden = Prefs.list(this, "hidden");
        for (AppEntry e : allApps) if (countOf(e) > 0 && !hidden.contains(e.key())) list.add(e);
        Collections.sort(list, new Comparator<AppEntry>() {
            @Override
            public int compare(AppEntry a, AppEntry b) {
                return countOf(b) - countOf(a);
            }
        });
        int n = 0;
        for (AppEntry e : list) {
            if (n++ >= 5) break;
            frequentRow.addView(iconCell(e, 46, false, true));
        }
        if (n == 0) {
            frequentRow.addView(Ui.text(this, "Apps you use most will appear here", 13, pal.sub));
        }
    }

    private View iconCell(final AppEntry e, int sizeDp, boolean showLabel, boolean clickable) {
        LinearLayout cell = new LinearLayout(this);
        cell.setOrientation(LinearLayout.VERTICAL);
        cell.setGravity(Gravity.CENTER_HORIZONTAL);
        cell.setPadding(dp(8), dp(4), dp(8), dp(4));
        ImageView iv = new ImageView(this);
        iv.setImageDrawable(e.icon);
        cell.addView(iv, new LinearLayout.LayoutParams(dp(sizeDp), dp(sizeDp)));
        if (showLabel) {
            TextView tv = Ui.text(this, e.label, 13, pal.text);
            tv.setSingleLine(true);
            tv.setEllipsize(TextUtils.TruncateAt.END);
            tv.setGravity(Gravity.CENTER);
            cell.addView(tv, new LinearLayout.LayoutParams(-1, -2));
        }
        if (clickable) {
            cell.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    launch(e);
                }
            });
            cell.setOnLongClickListener(new View.OnLongClickListener() {
                @Override
                public boolean onLongClick(View v) {
                    showAppMenu(e);
                    return true;
                }
            });
        }
        return cell;
    }

    private class AppAdapter extends BaseAdapter {
        @Override
        public int getCount() {
            return shown.size();
        }

        @Override
        public Object getItem(int i) {
            return shown.get(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int pos, View convert, ViewGroup parent) {
            return iconCell(shown.get(pos), Prefs.i(MainActivity.this, "iconSize", 56), true, false);
        }
    }

    // ============================================================== status
    private void updateBattery(Intent i) {
        if (i == null || tvBattery == null) return;
        int level = i.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = i.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        int status = i.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        boolean charging = status == BatteryManager.BATTERY_STATUS_CHARGING
                || status == BatteryManager.BATTERY_STATUS_FULL;
        int pct = level < 0 ? 0 : level * 100 / Math.max(1, scale);
        tvBattery.setText(" " + pct + "%");
        statusIcon(tvBattery, charging ? Icons.BOLT : Icons.BATTERY);
    }

    private void updateNetwork() {
        if (tvNet == null) return;
        String s = " Offline";
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            NetworkInfo ni = cm.getActiveNetworkInfo();
            if (ni != null && ni.isConnected()) {
                s = " " + (ni.getType() == ConnectivityManager.TYPE_WIFI ? "Wi-Fi" : "Mobile");
            }
        } catch (Exception ignored) {
        }
        tvNet.setText(s);
        statusIcon(tvNet, Icons.WIFI);
    }

    // ============================================================== volume
    private void syncVolume() {
        if (volBar == null || volTouching) return;
        volBar.setProgress(audio.getStreamVolume(AudioManager.STREAM_MUSIC));
        if (volMute != null) Ui.setIcon(volMute, volBar.getProgress() == 0 ? Icons.MUTE : Icons.VOLUME, pal.text);
    }

    // =============================================================== media
    @Override
    public void onMediaChanged() {
        updateMediaUi();
    }

    private static String fmt(long ms) {
        long s = ms / 1000;
        return String.format(Locale.US, "%d:%02d", s / 60, s % 60);
    }

    private boolean useOwn() {
        return PlayerService.active() && (!MediaTracker.hasAccess(this) || media.controller == null);
    }

    private void updateMediaUi() {
        if (musicBody == null || musicNotice == null) return;
        boolean access = MediaTracker.hasAccess(this);
        boolean own = PlayerService.active();
        boolean showBody = access || own;
        musicNotice.setVisibility(showBody ? View.GONE : View.VISIBLE);
        musicBody.setVisibility(showBody ? View.VISIBLE : View.GONE);
        if (!showBody) return;
        if (useOwn()) {
            Track t = PlayerService.current();
            tvTitle.setText(t.title);
            tvArtist.setText(t.artist);
            showArt(PlayerService.art(), t.title);
            Icons.set(btnPlay, PlayerService.isPlaying() ? Icons.PAUSE : Icons.PLAY, 0xFFFFFFFF);
            updateMediaProgress();
            return;
        }
        if (media.controller == null || media.title.length() == 0) {
            tvTitle.setText("Nothing playing");
            tvArtist.setText("Tap to open your media library");
            showArt(null, null);
        } else {
            tvTitle.setText(media.title);
            tvArtist.setText(media.artist);
            showArt(media.art, media.title);
        }
        Icons.set(btnPlay, media.playing ? Icons.PAUSE : Icons.PLAY, 0xFFFFFFFF);
        updateMediaProgress();
    }

    /** Shows the cover in the widget and uses it (blurred) as the card background. */
    private void showArt(Bitmap art, String title) {
        if (art == null && title != null && title.length() > 0) {
            if (placeholderArt == null || !title.equals(placeholderFor)) {
                placeholderArt = Thumbs.placeholder(title, pal.accent, 400);
                placeholderFor = title;
            }
            art = placeholderArt;
        }
        if (art == null) {
            ivArt.setImageDrawable(null);
        } else {
            ivArt.setImageBitmap(art);
        }
        if (musicCard == null || art == bgSource) return;
        bgSource = art;
        if (art == null) {
            musicCard.setBackground(musicDefaultBg);
            return;
        }
        Bitmap bl = Thumbs.blur(art, 3);
        if (bl == null) {
            musicCard.setBackground(musicDefaultBg);
            return;
        }
        musicCard.setBackground(new ArtBg(bl, dp(28), pal.dark, pal.dark ? 0x40FFFFFF : 0x22000000, dp(1)));
    }

    private void updateMediaProgress() {
        if (mediaProgress == null) return;
        if (useOwn()) {
            int d = PlayerService.duration();
            int pos = PlayerService.position();
            if (d <= 0) {
                mediaProgress.setProgress(0);
                tvPos.setText("");
                tvDur.setText("");
            } else {
                mediaProgress.setProgress((int) (pos * 1000L / d));
                tvPos.setText(fmt(pos));
                tvDur.setText(fmt(d));
            }
            return;
        }
        if (media.controller == null || media.duration <= 0) {
            mediaProgress.setProgress(0);
            tvPos.setText("");
            tvDur.setText("");
            return;
        }
        long pos = media.position();
        mediaProgress.setProgress((int) (pos * 1000 / media.duration));
        tvPos.setText(fmt(pos));
        tvDur.setText(fmt(media.duration));
    }

    private void openNotificationAccess() {
        try {
            startActivity(new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS));
        } catch (Exception e) {
            Toast.makeText(this, "Open Settings \u203A Notification access", Toast.LENGTH_LONG).show();
        }
    }

    // ================================================================ speed
    private boolean hasLocationPermission() {
        return Build.VERSION.SDK_INT < 23
                || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void maybeRequestLocation() {
        if (hasLocationPermission() || askedPermissionThisSession) return;
        boolean needs = Prefs.b(this, "showSpeed", true) || !Prefs.b(this, "wxManual", false);
        if (!needs) return;
        askedPermissionThisSession = true;
        if (Build.VERSION.SDK_INT >= 23) {
            requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOC);
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        startSpeedIfNeeded();
        refreshWeather(true);
    }

    private void startSpeedIfNeeded() {
        if ((Prefs.b(this, "showSpeed", true) || carPageEnabled()) && hasLocationPermission()) speedProvider.start();
    }

    @Override
    public void onSpeed() {
        updateSpeedUi();
        if (NavState.active) updateHomeNav();
    }

    private void updateSpeedUi() {
        if (carPage != null) {
            carPage.setSpeed(hasLocationPermission() && speedProvider.fresh() ? speedProvider.speedMs : 0f,
                    Prefs.b(this, "speedMph", false));
        }
        if (tvSpeed == null) return;
        boolean mph = Prefs.b(this, "speedMph", false);
        tvSpeedUnit.setText(mph ? "mph" : "km/h");
        if (!hasLocationPermission()) {
            tvSpeed.setText("--");
            tvHeading.setText("");
            tvGps.setText("Location permission needed");
            return;
        }
        if (speedProvider.fresh()) {
            float v = speedProvider.speedMs * (mph ? 2.23694f : 3.6f);
            tvSpeed.setText(String.valueOf(Math.round(v)));
            tvHeading.setText(speedProvider.hasBearing && speedProvider.speedMs > 1f
                    ? COMPASS[((int) ((speedProvider.bearing + 22.5f) / 45f)) % 8] : "");
            tvGps.setText("GPS locked");
        } else {
            tvSpeed.setText("--");
            tvHeading.setText("");
            tvGps.setText("Waiting for GPS\u2026");
        }
    }

    // ============================================================== weather
    private double[] weatherCoords() {
        if (Prefs.b(this, "wxManual", false)) {
            try {
                return new double[]{Double.parseDouble(Prefs.s(this, "wxLat", "0")),
                        Double.parseDouble(Prefs.s(this, "wxLon", "0"))};
            } catch (Exception e) {
                return null;
            }
        }
        if (!hasLocationPermission()) return null;
        try {
            LocationManager lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);
            Location best = null;
            for (String p : lm.getProviders(true)) {
                Location l = lm.getLastKnownLocation(p);
                if (l != null && (best == null || l.getTime() > best.getTime())) best = l;
            }
            if (best != null) return new double[]{best.getLatitude(), best.getLongitude()};
        } catch (SecurityException ignored) {
        }
        return null;
    }

    private void refreshWeather(boolean force) {
        if (tvWxTemp == null || weatherLoading) return;
        final boolean f = Prefs.b(this, "wxF", false);
        final double[] xy = weatherCoords();
        if (xy == null) {
            tvWxIcon.setText("\uD83D\uDCCD");
            tvWxTemp.setText("");
            tvWxDesc.setText(hasLocationPermission() ? "Finding your location\u2026"
                    : "Set a city in Settings or allow location");
            tvWxExtra.setText("");
            wxForecast.removeAllViews();
            tvWxPlace.setText("");
            return;
        }
        final String key = String.format(Locale.US, "%.2f,%.2f,%s", xy[0], xy[1], f ? "F" : "C");
        final android.content.SharedPreferences cache = Prefs.cache(this);
        String cachedJson = cache.getString("json", null);
        long age = System.currentTimeMillis() - cache.getLong("time", 0);
        boolean sameKey = key.equals(cache.getString("key", ""));
        if (cachedJson != null && sameKey) {
            try {
                renderWeather(WeatherClient.parse(cachedJson), false);
            } catch (Exception ignored) {
            }
        }
        if (!force && sameKey && age < 30L * 60 * 1000) return;
        weatherLoading = true;
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    String json = WeatherClient.http(WeatherClient.forecastUrl(xy[0], xy[1], f));
                    final WeatherClient.Weather w = WeatherClient.parse(json);
                    cache.edit().putString("json", json).putLong("time", System.currentTimeMillis())
                            .putString("key", key).apply();
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            weatherLoading = false;
                            renderWeather(w, false);
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            weatherLoading = false;
                            if (tvWxExtra != null && tvWxDesc != null
                                    && tvWxDesc.getText().toString().startsWith("Loading")) {
                                tvWxDesc.setText("Weather unavailable");
                                tvWxExtra.setText("Check your internet connection");
                            }
                        }
                    });
                }
            }
        }).start();
    }

    private void renderWeather(WeatherClient.Weather w, boolean stale) {
        if (tvWxTemp == null) return;
        boolean f = Prefs.b(this, "wxF", false);
        String deg = "\u00B0" + (f ? "F" : "C");
        tvWxIcon.setText(WeatherClient.emoji(w.code, w.day));
        tvWxTemp.setText(w.temp + deg);
        tvWxDesc.setText(WeatherClient.describe(w.code));
        tvWxExtra.setText("Feels " + w.feels + "\u00B0  \u00B7  Wind " + w.wind + (f ? " mph" : " km/h"));
        tvWxPlace.setText(Prefs.b(this, "wxManual", false) ? Prefs.s(this, "wxName", "") : "Current location");
        wxForecast.removeAllViews();
        for (WeatherClient.Day d : w.days) {
            LinearLayout col = new LinearLayout(this);
            col.setOrientation(LinearLayout.VERTICAL);
            col.setGravity(Gravity.CENTER);
            col.setPadding(dp(10), 0, dp(10), 0);
            TextView a = Ui.text(this, d.label, 12, pal.sub);
            a.setGravity(Gravity.CENTER);
            TextView b = Ui.text(this, WeatherClient.emoji(d.code, true), 20, pal.text);
            b.setGravity(Gravity.CENTER);
            TextView c = Ui.text(this, d.hi + "\u00B0 / " + d.lo + "\u00B0", 12, pal.text);
            c.setGravity(Gravity.CENTER);
            col.addView(a);
            col.addView(b);
            col.addView(c);
            wxForecast.addView(col);
        }
    }
}
