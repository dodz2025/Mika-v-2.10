package com.mika.launcher;

import android.app.Activity;
import android.content.Context;
import android.os.Build;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.widget.TextView;

final class Ui {
    private Ui() {
    }

    static int dp(Context c, int v) {
        return (int) (v * c.getResources().getDisplayMetrics().density + 0.5f);
    }

    static GradientDrawable pill(Context c, int color, int radiusDp) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(c, radiusDp));
        return g;
    }

    static TextView text(Context c, String s, int sp, int color) {
        TextView t = new TextView(c);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    static TextView button(Context c, String s, int sp, int bg, int fg) {
        TextView t = text(c, s, sp, fg);
        t.setGravity(Gravity.CENTER);
        t.setBackground(pill(c, bg, 18));
        t.setPadding(dp(c, 18), dp(c, 10), dp(c, 18), dp(c, 10));
        t.setClickable(true);
        return t;
    }

    /** Round icon button: coloured circle with a vector icon centred inside. */
    static android.widget.FrameLayout iconButton(Context c, int icon, int sizeDp, int iconDp, int bg, int fg) {
        android.widget.FrameLayout f = new android.widget.FrameLayout(c);
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(bg);
        f.setBackground(g);
        android.widget.ImageView iv = new android.widget.ImageView(c);
        iv.setImageDrawable(Icons.get(icon, fg));
        android.widget.FrameLayout.LayoutParams lp = new android.widget.FrameLayout.LayoutParams(dp(c, iconDp), dp(c, iconDp), Gravity.CENTER);
        f.addView(iv, lp);
        f.setTag(iv);
        f.setClickable(true);
        f.setMinimumWidth(dp(c, sizeDp));
        f.setMinimumHeight(dp(c, sizeDp));
        return f;
    }

    /** Swap the glyph (and colour) of a button made with iconButton(). */
    static void setIcon(View f, int icon, int fg) {
        Object t = f.getTag();
        if (t instanceof android.widget.ImageView) Icons.set((android.widget.ImageView) t, icon, fg);
    }

    /** Re-tint an iconButton(): oval background colour + glyph. */
    static void tintIcon(View f, int icon, int bg, int fg) {
        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        g.setColor(bg);
        f.setBackground(g);
        setIcon(f, icon, fg);
    }

    /** Glass card background: translucent fill, soft top-lit gradient and a hairline border. */
    static GradientDrawable glass(Context c, int fill, int border, int radiusDp) {
        GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{lighten(fill, 0.10f), fill});
        g.setCornerRadius(dp(c, radiusDp));
        g.setStroke(Math.max(1, dp(c, 1)), border);
        return g;
    }

    static int lighten(int color, float amt) {
        int a = (color >>> 24) & 0xFF;
        int r = (color >> 16) & 0xFF, gg = (color >> 8) & 0xFF, b = color & 0xFF;
        r += (255 - r) * amt;
        gg += (255 - gg) * amt;
        b += (255 - b) * amt;
        return (a << 24) | (r << 16) | (gg << 8) | b;
    }

    /**
     * Draws the window into the notch / rounded-corner areas so the picture fills the entire display
     * (without this, Android letterboxes one side in landscape, which shows up when mirroring the screen).
     */
    static void cutout(Activity a) {
        if (!Prefs.b(a, "fillScreen", true)) return;
        try {
            Window w = a.getWindow();
            if (Build.VERSION.SDK_INT >= 28) {
                WindowManager.LayoutParams lp = w.getAttributes();
                lp.layoutInDisplayCutoutMode = Build.VERSION.SDK_INT >= 30
                        ? WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                        : WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES;
                w.setAttributes(lp);
            }
            w.addFlags(WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN);
            w.setStatusBarColor(0);
            w.setNavigationBarColor(0);
            if (Build.VERSION.SDK_INT >= 30) w.setDecorFitsSystemWindows(false);
        } catch (Throwable ignored) {
        }
    }

    /** Full-screen immersive mode: no status/navigation bars, content edge to edge. */
    @SuppressWarnings("deprecation")
    static void immersive(Activity a) {
        cutout(a);
        a.getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                        | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN
                        | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }
}
