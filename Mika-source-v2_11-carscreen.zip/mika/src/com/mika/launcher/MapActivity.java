package com.mika.launcher;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.location.LocationListener;
import android.location.LocationManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Full-screen map: GPS follow, place search, long-press to drop a pin, saved places, hand-off to navigation apps. */
public class MapActivity extends Activity implements MapView.Listener {

    private static final int REQ_LOC = 21;
    private static final String UA = "MikaLauncher/2.1 (Android launcher; contact: none)";

    private Pal pal;
    private MapSurface map;
    private View mapV;
    private FrameLayout root;
    private boolean forceRaster = false;
    private EditText searchBox;
    private TextView speedChip, btn3d;
    private View btnFollow, btnSat;
    private LinearLayout pinCard;
    private TextView pinTitle, pinSub;
    private LocationManager lm;
    private boolean follow = true;
    private boolean gotFirstFix = false;
    private double pinLat, pinLon;
    private String pinName = "";
    private Location last;

    // ---- in-app routing (state shared with the home screen lives in NavState)
    private LinearLayout navBanner, navCard;
    private TextView tvNavArrow, tvNavDist, tvNavText, tvEta, tvEtaSub;
    private boolean navigating = false;
    private boolean pendingGo = false;

    // ---- saved places (JSON in prefs)
    static List<Object[]> loadPlaces(Context c) {
        List<Object[]> out = new ArrayList<Object[]>();
        try {
            JSONArray a = new JSONArray(Prefs.s(c, "places", "[]"));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                out.add(new Object[]{o.getString("name"), o.getDouble("lat"), o.getDouble("lon")});
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    static void savePlaces(Context c, List<Object[]> l) {
        JSONArray a = new JSONArray();
        try {
            for (Object[] p : l) {
                JSONObject o = new JSONObject();
                o.put("name", p[0]);
                o.put("lat", p[1]);
                o.put("lon", p[2]);
                a.put(o);
            }
        } catch (Exception ignored) {
        }
        Prefs.putS(c, "places", a.toString());
    }

    private int dp(int v) {
        return Ui.dp(this, v);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        pal = Pal.of(this);
        lm = (LocationManager) getSystemService(Context.LOCATION_SERVICE);

        Ui.immersive(this);
        root = new FrameLayout(this);
        createMap();

        // top bar: back + search
        LinearLayout top = new LinearLayout(this);
        top.setGravity(Gravity.CENTER_VERTICAL);
        top.setPadding(dp(12), dp(10), dp(12), 0);
        View back = Ui.iconButton(this, Icons.BACK, 44, 22, panelColor(), pal.text);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
        top.addView(back);
        searchBox = new EditText(this);
        searchBox.setHint("Search places or addresses");
        searchBox.setSingleLine(true);
        searchBox.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchBox.setTextColor(pal.text);
        searchBox.setHintTextColor(pal.sub);
        searchBox.setTextSize(16);
        searchBox.setBackground(Ui.pill(this, panelColor(), 18));
        searchBox.setPadding(dp(16), dp(10), dp(16), dp(10));
        searchBox.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override
            public boolean onEditorAction(TextView v, int actionId, KeyEvent e) {
                doSearch();
                return true;
            }
        });
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(0, -2, 1f);
        sl.leftMargin = dp(10);
        top.addView(searchBox, sl);
        TextView go = Ui.button(this, "Go", 16, pal.accent, 0xFFFFFFFF);
        go.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                doSearch();
            }
        });
        LinearLayout.LayoutParams gl = new LinearLayout.LayoutParams(-2, -2);
        gl.leftMargin = dp(8);
        top.addView(go, gl);
        root.addView(top, new FrameLayout.LayoutParams(-1, -2, Gravity.TOP));

        // speed chip
        speedChip = Ui.button(this, "-- km/h", 18, panelColor(), pal.text);
        FrameLayout.LayoutParams sc = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.END);
        sc.bottomMargin = dp(24);
        sc.rightMargin = dp(12);
        root.addView(speedChip, sc);

        // right-hand buttons (two columns: zoom/locate/places and 3D/compass/satellite)
        LinearLayout side = new LinearLayout(this);
        side.setOrientation(LinearLayout.VERTICAL);
        side.addView(sideBtn(Icons.PLUS, new View.OnClickListener() {
            public void onClick(View v) {
                map.zoomBy(1f);
            }
        }));
        side.addView(sideBtn(Icons.MINUS, new View.OnClickListener() {
            public void onClick(View v) {
                map.zoomBy(-1f);
            }
        }));
        btnFollow = sideBtn(Icons.TARGET, new View.OnClickListener() {
            public void onClick(View v) {
                follow = true;
                if (last != null) {
                    map.setCenter(last.getLatitude(), last.getLongitude());
                    if (map.getZoom() < 15) map.setZoom(15);
                } else {
                    Toast.makeText(MapActivity.this, "Waiting for location\u2026", Toast.LENGTH_SHORT).show();
                }
                updateFollowBtn();
            }
        });
        side.addView(btnFollow);
        side.addView(sideBtn(Icons.STAR, new View.OnClickListener() {
            public void onClick(View v) {
                showPlaces();
            }
        }));
        LinearLayout sideWrap = new LinearLayout(this);
        sideWrap.setGravity(Gravity.CENTER_VERTICAL);
        if (map.isVector()) {
            LinearLayout side2 = new LinearLayout(this);
            side2.setOrientation(LinearLayout.VERTICAL);
            side2.addView(sideBtn(Icons.COMPASS, new View.OnClickListener() {
                public void onClick(View v) {
                    map.resetNorth();
                }
            }));
            btn3d = sideTxt("3D", new View.OnClickListener() {
                public void onClick(View v) {
                    boolean on = !map.isTilted();
                    map.setTilt(on);
                    map.setHeadingUp(on);
                    if (!on) map.resetNorth();
                    if (on && last != null && follow) {
                        map.followTo(last.getLatitude(), last.getLongitude(),
                                last.hasBearing() ? last.getBearing() : 0f, true);
                    }
                    updateToggles();
                }
            });
            btn3d.setTextSize(16);
            side2.addView(btn3d);
            btnSat = sideBtn(Icons.LAYERS, new View.OnClickListener() {
                public void onClick(View v) {
                    map.setSatellite(!map.isSatellite());
                    Prefs.putB(MapActivity.this, "mapSat", map.isSatellite());
                    updateToggles();
                }
            });
            side2.addView(btnSat);
            LinearLayout.LayoutParams l2 = new LinearLayout.LayoutParams(-2, -2);
            l2.rightMargin = dp(8);
            sideWrap.addView(side2, l2);
        }
        sideWrap.addView(side);
        FrameLayout.LayoutParams sp = new FrameLayout.LayoutParams(-2, -2, Gravity.END | Gravity.CENTER_VERTICAL);
        sp.rightMargin = dp(12);
        root.addView(sideWrap, sp);

        // turn-by-turn banner (shown while a route is active)
        navBanner = new LinearLayout(this);
        navBanner.setGravity(Gravity.CENTER_VERTICAL);
        navBanner.setBackground(Ui.pill(this, panelColor(), 22));
        navBanner.setPadding(dp(16), dp(10), dp(10), dp(10));
        tvNavArrow = Ui.text(this, "\u2191", 34, pal.accent);
        tvNavArrow.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        navBanner.addView(tvNavArrow, new LinearLayout.LayoutParams(dp(48), -2));
        LinearLayout nt = new LinearLayout(this);
        nt.setOrientation(LinearLayout.VERTICAL);
        tvNavDist = Ui.text(this, "", 22, pal.text);
        tvNavDist.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        tvNavText = Ui.text(this, "", 14, pal.sub);
        tvNavText.setSingleLine(true);
        tvNavText.setEllipsize(android.text.TextUtils.TruncateAt.END);
        nt.addView(tvNavDist);
        nt.addView(tvNavText);
        navBanner.addView(nt, new LinearLayout.LayoutParams(0, -2, 1f));
        View stop = Ui.iconButton(this, Icons.CLOSE, 44, 20, pal.card, pal.text);
        stop.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                stopRoute();
            }
        });
        navBanner.addView(stop);
        navBanner.setVisibility(View.GONE);
        FrameLayout.LayoutParams nb = new FrameLayout.LayoutParams(-1, -2, Gravity.TOP);
        nb.topMargin = dp(66);
        nb.leftMargin = dp(12);
        nb.rightMargin = dp(12);
        root.addView(navBanner, nb);

        // route summary card (bottom)
        navCard = new LinearLayout(this);
        navCard.setOrientation(LinearLayout.VERTICAL);
        navCard.setBackground(Ui.pill(this, panelColor(), 22));
        navCard.setPadding(dp(18), dp(12), dp(18), dp(12));
        tvEta = Ui.text(this, "", 20, pal.text);
        tvEta.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        tvEtaSub = Ui.text(this, "", 13, pal.sub);
        navCard.addView(tvEta);
        navCard.addView(tvEtaSub);
        LinearLayout na = new LinearLayout(this);
        na.setPadding(0, dp(8), 0, 0);
        na.addView(pinBtn("End route", pal.accent, 0xFFFFFFFF, new View.OnClickListener() {
            public void onClick(View v) {
                stopRoute();
            }
        }));
        na.addView(pinBtn("Google Maps", pal.card, pal.text, new View.OnClickListener() {
            public void onClick(View v) {
                navigateExternal();
            }
        }));
        na.addView(pinBtn("Overview", pal.card, pal.text, new View.OnClickListener() {
            public void onClick(View v) {
                follow = false;
                updateFollowBtn();
                map.setHeadingUp(false);
                map.setTilt(false);
                map.fitRoute();
                updateToggles();
            }
        }));
        navCard.addView(na);
        navCard.setVisibility(View.GONE);
        FrameLayout.LayoutParams ncp = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.START);
        ncp.leftMargin = dp(12);
        ncp.bottomMargin = dp(24);
        root.addView(navCard, ncp);

        // pin card
        pinCard = new LinearLayout(this);
        pinCard.setOrientation(LinearLayout.VERTICAL);
        pinCard.setBackground(Ui.pill(this, panelColor(), 22));
        pinCard.setPadding(dp(18), dp(14), dp(18), dp(14));
        pinTitle = Ui.text(this, "", 18, pal.text);
        pinTitle.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
        pinSub = Ui.text(this, "", 13, pal.sub);
        pinCard.addView(pinTitle);
        pinCard.addView(pinSub);
        LinearLayout actions = new LinearLayout(this);
        actions.setPadding(0, dp(10), 0, 0);
        actions.addView(pinBtn("Directions", pal.accent, 0xFFFFFFFF, new View.OnClickListener() {
            public void onClick(View v) {
                startRoute();
            }
        }));
        actions.addView(pinBtn("Save", pal.card, pal.text, new View.OnClickListener() {
            public void onClick(View v) {
                savePinDialog();
            }
        }));
        actions.addView(pinBtn("Google Maps", pal.card, pal.text, new View.OnClickListener() {
            public void onClick(View v) {
                navigateExternal();
            }
        }));
        actions.addView(pinBtn("Clear", pal.card, pal.text, new View.OnClickListener() {
            public void onClick(View v) {
                clearPin();
            }
        }));
        pinCard.addView(actions);
        pinCard.setVisibility(View.GONE);
        FrameLayout.LayoutParams pc = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.START);
        pc.leftMargin = dp(12);
        pc.bottomMargin = dp(24);
        root.addView(pinCard, pc);

        setContentView(root);
        updateFollowBtn();
        updateToggles();
        String q = getIntent().getStringExtra("q");
        if (q != null && q.length() > 0 && getIntent().getBooleanExtra("go", false)) NavState.stop(); // new destination
        if (NavState.active) {
            restoreNav();
        } else if (q != null && q.length() > 0) {
            pendingGo = getIntent().getBooleanExtra("go", false);
            searchBox.setText(q);
            doSearch();
        } else {
            Toast.makeText(this, "Long-press the map to drop a pin", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (hasFocus) Ui.immersive(this);
    }

    // ------------------------------------------------------------ map engine
    private void createMap() {
        boolean vec = Prefs.i(this, "mapEngine", 0) == 0 && !forceRaster;
        if (vec) {
            VectorMapView v = new VectorMapView(this);
            v.setEvents(new VectorMapView.Events() {
                @Override
                public void onFail(String reason) {
                    fallbackToRaster(reason);
                }

                @Override
                public void onPoi(String name, double lat, double lon) {
                    dropPin(lat, lon, name);
                }
            });
            map = v;
        } else {
            map = new MapView(this);
        }
        mapV = (View) map;
        map.setListener(this);
        map.setNight(pal.dark);
        map.setAccent(pal.accent);
        map.setSatellite(Prefs.b(this, "mapSat", false));
        map.setCenter(Double.parseDouble(Prefs.s(this, "mapLat", "48.8566")),
                Double.parseDouble(Prefs.s(this, "mapLon", "2.3522")));
        map.setZoom(Prefs.i(this, "mapZoom", 5));
        refreshSaved();
        root.addView(mapV, 0, new FrameLayout.LayoutParams(-1, -1));
    }

    /** Called when the vector map can't run (no WebGL, old WebView, offline): switch to the classic raster map. */
    private void fallbackToRaster(String reason) {
        if (!(map instanceof VectorMapView) || isFinishing()) return;
        double lat = map.centerLat(), lon = map.centerLon();
        float z = map.getZoom();
        VectorMapView old = (VectorMapView) map;
        root.removeView(old);
        old.destroy();
        forceRaster = true;
        createMap();
        map.setCenter(lat, lon);
        map.setZoom(z);
        if (last != null) map.setMe(last);
        if (pinCard.getVisibility() == View.VISIBLE) map.setPin(pinLat, pinLon);
        if (NavState.active && NavState.pts != null) map.setRoute(NavState.pts);
        Toast.makeText(this, "token".equals(reason)
                        ? "Mapbox token was rejected \u2013 check it in Settings > Map"
                        : "network".equals(reason)
                        ? "Vector map unavailable offline \u2013 showing the classic map"
                        : "3D map isn't supported on this device \u2013 showing the classic map",
                Toast.LENGTH_LONG).show();
    }

    private void updateToggles() {
        if (btn3d != null) {
            btn3d.setBackground(Ui.pill(this, map.isTilted() ? pal.accent : panelColor(), 18));
            btn3d.setTextColor(map.isTilted() ? 0xFFFFFFFF : pal.text);
        }
        if (btnSat != null) {
            Ui.tintIcon(btnSat, Icons.LAYERS, map.isSatellite() ? pal.accent : panelColor(), map.isSatellite() ? 0xFFFFFFFF : pal.text);
        }
    }

    private int panelColor() {
        return pal.dark ? 0xE61A1E2A : 0xE6FFFFFF;
    }

    private View sideBtn(int icon, View.OnClickListener l) {
        View t = Ui.iconButton(this, icon, 54, 24, panelColor(), pal.text);
        t.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(54), dp(54));
        lp.bottomMargin = dp(8);
        t.setLayoutParams(lp);
        return t;
    }

    private TextView sideTxt(String glyph, View.OnClickListener l) {
        TextView t = Ui.button(this, glyph, 20, panelColor(), pal.text);
        t.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(54), dp(54));
        lp.bottomMargin = dp(8);
        t.setLayoutParams(lp);
        t.setPadding(0, 0, 0, 0);
        return t;
    }

    private TextView pinBtn(String s, int bg, int fg, View.OnClickListener l) {
        TextView t = Ui.button(this, s, 15, bg, fg);
        t.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2);
        lp.rightMargin = dp(8);
        t.setLayoutParams(lp);
        return t;
    }

    private void updateFollowBtn() {
        Ui.tintIcon(btnFollow, Icons.TARGET, follow ? pal.accent : panelColor(), follow ? 0xFFFFFFFF : pal.text);
    }

    private void refreshSaved() {
        List<double[]> pts = new ArrayList<double[]>();
        for (Object[] p : loadPlaces(this)) pts.add(new double[]{(Double) p[1], (Double) p[2]});
        map.setSaved(pts);
    }

    // -------------------------------------------------------------- lifecycle
    @Override
    protected void onResume() {
        super.onResume();
        if (map instanceof VectorMapView) ((VectorMapView) map).onHostResume();
        startLocation();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (map instanceof VectorMapView) ((VectorMapView) map).destroy();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (map instanceof VectorMapView) ((VectorMapView) map).onHostPause();
        try {
            lm.removeUpdates(locListener);
        } catch (Exception ignored) {
        }
        Prefs.putS(this, "mapLat", String.valueOf(map.centerLat()));
        Prefs.putS(this, "mapLon", String.valueOf(map.centerLon()));
        Prefs.putI(this, "mapZoom", Math.round(map.getZoom()));
    }

    private boolean hasPerm() {
        return Build.VERSION.SDK_INT < 23
                || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    private void startLocation() {
        if (!hasPerm()) {
            if (Build.VERSION.SDK_INT >= 23) {
                requestPermissions(new String[]{Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION}, REQ_LOC);
            }
            return;
        }
        try {
            for (String p : lm.getProviders(true)) {
                if (p.equals(LocationManager.GPS_PROVIDER) || p.equals(LocationManager.NETWORK_PROVIDER)) {
                    lm.requestLocationUpdates(p, 1000, 0, locListener);
                    Location l = lm.getLastKnownLocation(p);
                    if (l != null && (last == null || l.getTime() > last.getTime())) applyLocation(l);
                }
            }
        } catch (SecurityException ignored) {
        }
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] res) {
        super.onRequestPermissionsResult(code, perms, res);
        startLocation();
    }

    private final LocationListener locListener = new LocationListener() {
        @Override
        public void onLocationChanged(Location l) {
            applyLocation(l);
        }

        @Override
        public void onStatusChanged(String p, int s, Bundle e) {
        }

        @Override
        public void onProviderEnabled(String p) {
        }

        @Override
        public void onProviderDisabled(String p) {
        }
    };

    private void applyLocation(Location l) {
        // prefer GPS fixes over network fixes when both are recent
        if (last != null && LocationManager.GPS_PROVIDER.equals(last.getProvider())
                && !LocationManager.GPS_PROVIDER.equals(l.getProvider())
                && l.getTime() - last.getTime() < 10000) return;
        last = l;
        map.setMe(l);
        boolean mph = Prefs.b(this, "speedMph", false);
        float v = l.hasSpeed() ? l.getSpeed() * (mph ? 2.23694f : 3.6f) : 0f;
        speedChip.setText(Math.round(v) + (mph ? " mph" : " km/h"));
        if (!gotFirstFix) {
            gotFirstFix = true;
            map.setCenter(l.getLatitude(), l.getLongitude());
            if (map.getZoom() < 14) map.setZoom(15);
        } else if (follow) {
            boolean moving = l.hasBearing() && l.hasSpeed() && l.getSpeed() > 1f;
            map.followTo(l.getLatitude(), l.getLongitude(), l.hasBearing() ? l.getBearing() : 0f, moving);
        }
        if (navigating) updateNav();
        else if (pendingGo && map.hasPin()) tryAutoRoute();
    }

    // ----------------------------------------------------------- map callbacks
    @Override
    public void onUserMoved() {
        if (follow) {
            follow = false;
            updateFollowBtn();
        }
    }

    @Override
    public void onTap() {
        hideKeyboard();
    }

    @Override
    public void onLongPress(double lat, double lon) {
        dropPin(lat, lon, null);
    }

    private void hideKeyboard() {
        InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(searchBox.getWindowToken(), 0);
    }

    // --------------------------------------------------------------- pins
    private void dropPin(final double lat, final double lon, String name) {
        if (navigating) stopRoute();
        pinLat = lat;
        pinLon = lon;
        pinName = name == null ? "" : name;
        map.setPin(lat, lon);
        pinTitle.setText(name == null ? "Dropped pin" : name);
        pinSub.setText(String.format(Locale.US, "%.5f, %.5f", lat, lon));
        pinCard.setVisibility(navigating ? View.GONE : View.VISIBLE);
        if (name == null) {
            new Thread(new Runnable() {
                @Override
                public void run() {
                    try {
                        JSONObject o = new JSONObject(get("https://nominatim.openstreetmap.org/reverse?format=json&zoom=17&lat="
                                + lat + "&lon=" + lon));
                        final String addr = o.optString("display_name", "");
                        runOnUiThread(new Runnable() {
                            @Override
                            public void run() {
                                if (pinLat == lat && pinLon == lon && addr.length() > 0) {
                                    pinName = addr.split(",")[0];
                                    pinTitle.setText(pinName);
                                    pinSub.setText(addr);
                                }
                            }
                        });
                    } catch (Exception ignored) {
                    }
                }
            }).start();
        }
    }

    private void clearPin() {
        map.clearPin();
        pinCard.setVisibility(View.GONE);
    }

    private void navigateExternal() {
        try {
            String label = Uri.encode(pinName.length() > 0 ? pinName : "Destination");
            Uri uri = Uri.parse(String.format(Locale.US, "geo:%f,%f?q=%f,%f(%s)", pinLat, pinLon, pinLat, pinLon, label));
            Intent i = new Intent(Intent.ACTION_VIEW, uri);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "Install a navigation app (Google Maps, Waze, OsmAnd\u2026) to get directions",
                    Toast.LENGTH_LONG).show();
        }
    }

    // ------------------------------------------------------------- routing
    private void startRoute() {
        if (last == null) {
            Toast.makeText(this, "Waiting for your location\u2026", Toast.LENGTH_SHORT).show();
            return;
        }
        Toast.makeText(this, "Finding route\u2026", Toast.LENGTH_SHORT).show();
        NavState.fetch(getApplicationContext(), last.getLatitude(), last.getLongitude(), pinLat, pinLon, pinName, false,
                new Runnable() {
                    @Override
                    public void run() {
                        onRouteReady(false);
                    }
                },
                new Runnable() {
                    @Override
                    public void run() {
                        Toast.makeText(MapActivity.this, "Couldn't find a route. Check your connection.",
                                Toast.LENGTH_LONG).show();
                    }
                });
    }

    private void onRouteReady(boolean silent) {
        if (isFinishing() || !NavState.active) return;
        map.setRoute(NavState.pts);
        if (!navigating) {
            navigating = true;
            pinCard.setVisibility(View.GONE);
            navBanner.setVisibility(View.VISIBLE);
            navCard.setVisibility(View.VISIBLE);
            if (!silent) {
                follow = true;
                updateFollowBtn();
                if (map.isVector()) {
                    map.setHeadingUp(true);
                    map.setTilt(true);
                    updateToggles();
                } else {
                    map.fitRoute();
                }
            }
        }
        tvEtaSub.setText("to " + (NavState.destName.length() > 0 ? NavState.destName : "destination"));
        updateNav();
    }

    /** Picks up a drive that was started elsewhere (home screen) or earlier in this session. */
    private void restoreNav() {
        if (!NavState.active || NavState.pts == null) return;
        pinLat = NavState.destLat;
        pinLon = NavState.destLon;
        pinName = NavState.destName;
        map.setPin(pinLat, pinLon);
        follow = true;
        updateFollowBtn();
        onRouteReady(false);
    }

    private void updateNav() {
        if (!navigating || !NavState.active || last == null) return;
        if (NavState.update(last)) {
            Toast.makeText(this, "You have arrived", Toast.LENGTH_LONG).show();
            stopRoute();
            return;
        }
        tvNavArrow.setText(NavState.nextArrow);
        tvNavDist.setText(NavState.fmtDist(this, NavState.nextDist));
        tvNavText.setText(NavState.nextText);
        tvEta.setText(NavState.fmtTime(NavState.eta) + "  \u00B7  " + NavState.fmtDist(this, NavState.remaining));
        if (NavState.shouldReroute()) {
            NavState.fetch(getApplicationContext(), last.getLatitude(), last.getLongitude(), NavState.destLat, NavState.destLon,
                    NavState.destName, true, new Runnable() {
                        @Override
                        public void run() {
                            onRouteReady(true);
                        }
                    }, null);
        }
    }

    private void stopRoute() {
        navigating = false;
        NavState.stop();
        map.clearRoute();
        navBanner.setVisibility(View.GONE);
        navCard.setVisibility(View.GONE);
        if (map.isVector()) {
            map.setHeadingUp(false);
            map.setTilt(false);
            map.resetNorth();
            updateToggles();
        }
        if (map.hasPin()) pinCard.setVisibility(View.VISIBLE);
    }

    private void tryAutoRoute() {
        if (!pendingGo) return;
        if (last == null) return; // retried on the first location fix
        pendingGo = false;
        startRoute();
    }

    private void savePinDialog() {
        final EditText et = new EditText(this);
        et.setText(pinName.length() > 0 ? pinName : "");
        et.setHint("Name (e.g. Home, Work)");
        new AlertDialog.Builder(this).setTitle("Save place").setView(et)
                .setPositiveButton("Save", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        String n = et.getText().toString().trim();
                        if (n.length() == 0) n = "Saved place";
                        List<Object[]> l = loadPlaces(MapActivity.this);
                        l.add(new Object[]{n, pinLat, pinLon});
                        savePlaces(MapActivity.this, l);
                        refreshSaved();
                        Toast.makeText(MapActivity.this, "Saved \u201C" + n + "\u201D", Toast.LENGTH_SHORT).show();
                    }
                }).setNegativeButton("Cancel", null).show();
    }

    private void showPlaces() {
        final List<Object[]> l = loadPlaces(this);
        if (l.isEmpty()) {
            Toast.makeText(this, "No saved places yet. Long-press the map, then tap Save.", Toast.LENGTH_LONG).show();
            return;
        }
        String[] names = new String[l.size()];
        for (int i = 0; i < names.length; i++) names[i] = "\u2B50  " + l.get(i)[0];
        new AlertDialog.Builder(this).setTitle("Saved places")
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        Object[] p = l.get(which);
                        follow = false;
                        updateFollowBtn();
                        map.flyTo((Double) p[1], (Double) p[2], Math.max(map.getZoom(), 15));
                        dropPin((Double) p[1], (Double) p[2], String.valueOf(p[0]));
                    }
                })
                .setNeutralButton("Delete\u2026", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int w) {
                        deletePlaceDialog();
                    }
                })
                .setNegativeButton("Close", null).show();
    }

    private void deletePlaceDialog() {
        final List<Object[]> l = loadPlaces(this);
        String[] names = new String[l.size()];
        for (int i = 0; i < names.length; i++) names[i] = String.valueOf(l.get(i)[0]);
        new AlertDialog.Builder(this).setTitle("Delete which place?")
                .setItems(names, new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        l.remove(which);
                        savePlaces(MapActivity.this, l);
                        refreshSaved();
                    }
                }).setNegativeButton("Cancel", null).show();
    }

    // ---------------------------------------------------------------- search
    private static String get(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setRequestProperty("User-Agent", UA);
        c.setRequestProperty("Accept-Language", Locale.getDefault().getLanguage());
        c.setConnectTimeout(8000);
        c.setReadTimeout(8000);
        try {
            BufferedReader r = new BufferedReader(new InputStreamReader(c.getInputStream(), "UTF-8"));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = r.readLine()) != null) sb.append(line);
            r.close();
            return sb.toString();
        } finally {
            c.disconnect();
        }
    }

    private void doSearch() {
        final String q = searchBox.getText().toString().trim();
        hideKeyboard();
        if (q.length() == 0) return;
        Toast.makeText(this, "Searching\u2026", Toast.LENGTH_SHORT).show();
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    final List<String> names = new ArrayList<String>();
                    final List<double[]> pts = new ArrayList<double[]>();
                    String token = Prefs.s(MapActivity.this, "mapboxToken", "").trim();
                    if (token.length() > 0) {
                        String prox = "";
                        if (last != null) prox = String.format(Locale.US, "&proximity=%f,%f", last.getLongitude(), last.getLatitude());
                        JSONArray fs = new JSONObject(get("https://api.mapbox.com/geocoding/v5/mapbox.places/"
                                + URLEncoder.encode(q, "UTF-8").replace("+", "%20") + ".json?limit=6&access_token=" + token + prox))
                                .getJSONArray("features");
                        for (int i = 0; i < fs.length(); i++) {
                            JSONObject o = fs.getJSONObject(i);
                            JSONArray c = o.getJSONArray("center");
                            names.add(o.optString("place_name"));
                            pts.add(new double[]{c.getDouble(1), c.getDouble(0)});
                        }
                    } else {
                        JSONArray arr = new JSONArray(get("https://nominatim.openstreetmap.org/search?format=json&limit=6&q="
                                + URLEncoder.encode(q, "UTF-8")));
                        for (int i = 0; i < arr.length(); i++) {
                            JSONObject o = arr.getJSONObject(i);
                            names.add(o.optString("display_name"));
                            pts.add(new double[]{o.getDouble("lat"), o.getDouble("lon")});
                        }
                    }
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            showResults(names, pts);
                        }
                    });
                } catch (Exception e) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            Toast.makeText(MapActivity.this, "Search failed. Check your connection.",
                                    Toast.LENGTH_LONG).show();
                        }
                    });
                }
            }
        }).start();
    }

    private void showResults(final List<String> names, final List<double[]> pts) {
        if (names.isEmpty()) {
            pendingGo = false;
            Toast.makeText(this, "No results", Toast.LENGTH_SHORT).show();
            return;
        }
        if (pendingGo) {
            // coming from "Where to?" on the home screen: take the best match and drive there
            double[] p = pts.get(0);
            follow = false;
            updateFollowBtn();
            map.flyTo(p[0], p[1], 16);
            dropPin(p[0], p[1], names.get(0).split(",")[0]);
            tryAutoRoute();
            return;
        }
        new AlertDialog.Builder(this).setTitle("Results")
                .setItems(names.toArray(new String[0]), new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface d, int which) {
                        double[] p = pts.get(which);
                        follow = false;
                        updateFollowBtn();
                        map.flyTo(p[0], p[1], 16);
                        dropPin(p[0], p[1], names.get(which).split(",")[0]);
                    }
                }).show();
    }
}
